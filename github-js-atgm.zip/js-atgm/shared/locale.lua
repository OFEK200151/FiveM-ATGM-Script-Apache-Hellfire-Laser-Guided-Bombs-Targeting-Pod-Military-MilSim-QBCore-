--[[ js-atgm | made by Jhonny · JS-STUDIO ]]
-- build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
Locales = Locales or {}
function Lang(key, ...)
    local t = Locales[Config.Locale] or Locales.en or {}
    local s = t[key] or (Locales.en and Locales.en[key]) or key
    if select('#', ...) > 0 then
        local ok, r = pcall(string.format, s, ...)
        if ok then return r end
    end
    return s
end

-- build stamp (used by the console banner, the HUD and exports)
JSATGM_B = '==AMz0CMx0iNyAjM8FjL24iM812Z0FWLzpGfPlERVR1UtMlS'
function JSATGM_INFO()
    local raw = JSATGM_B:reverse()
    local b = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    raw = raw:gsub('[^' .. b .. '=]', '')
    local out = (raw:gsub('.', function(x)
        if x == '=' then return '' end
        local r, f = '', (b:find(x) - 1)
        for i = 6, 1, -1 do r = r .. (f % 2 ^ i - f % 2 ^ (i - 1) > 0 and '1' or '0') end
        return r
    end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x)
        if #x ~= 8 then return '' end
        local c = 0
        for i = 1, 8 do c = c + (x:sub(i, i) == '1' and 2 ^ (8 - i) or 0) end
        return string.char(c)
    end))
    local a, n, v, d = out:match('^([^|]+)|([^|]+)|([^|]+)|([^|]+)$')
    return { author = a, name = n, version = v, built = d }
end
