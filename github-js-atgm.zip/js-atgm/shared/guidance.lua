--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     Flight model of the weapons, without game natives (so it can be tested on its own).
       missiles  motor (boost / sustain), drag, gravity on the climb, turn rate from a g limit,
                 lead on moving targets, flight profiles: direct / lofted (climb, then dive = top attack)
       bombs     gravity, drag, limited lift (glide), steering within a g limit that grows with speed
     G.Step(M, dt, aim, aimVel) moves M.pos / M.vel; aim = guidance point or nil (unguided). ]]
GD = {}
local G = 9.81
local sqrt, min, max, acos, sin = math.sqrt, math.min, math.max, math.acos, math.sin

local function v3(x, y, z) return vector3(x, y, z) end
local function len(v) return sqrt(v.x * v.x + v.y * v.y + v.z * v.z) end
local function norm(v) local l = len(v) if l < 1e-9 then return v3(0.0, 0.0, 0.0) end return v / l end
local function dot(a, b) return a.x * b.x + a.y * b.y + a.z * b.z end
local function clamp(x, a, b) if x < a then return a elseif x > b then return b end return x end

--- rotate unit a towards unit b by at most ang radians
local function turn(a, b, ang)
    local c = clamp(dot(a, b), -1.0, 1.0)
    local th = acos(c)
    if th <= ang or th < 1e-6 then return b end
    local s = sin(th)
    if s < 1e-4 then
        -- b is (almost) straight behind: the turn plane is undefined, so turn through the vertical plane
        -- of a (or sideways if a points straight up / down) instead of dividing by ~0
        local p = v3(-a.x * a.z, -a.y * a.z, a.x * a.x + a.y * a.y)       -- "up" across a
        if len(p) < 1e-3 then p = v3(1.0, 0.0, 0.0) end
        p = norm(p)
        return norm(a * math.cos(ang) + p * sin(ang))
    end
    local t = ang / th
    return norm(a * (sin((1 - t) * th) / s) + b * (sin(t * th) / s))
end
GD.turn = turn

local function bomb(W) return W.kind == 'lgb' or W.kind == 'gpsb' end
GD.IsBomb = bomb

--- where the weapon steers this instant (lead + flight profile)
function GD.AimPoint(M, aim, aimVel)
    local W = M.W
    local p = aim
    local spd = max(len(M.vel), 50.0)
    if aimVel and len(aimVel) > 0.5 then
        local tgo = clamp(len(aim - M.pos) / spd, 0.0, 12.0)
        local lead = aimVel * tgo
        local ll = len(lead)
        if ll > 80.0 then lead = lead * (80.0 / ll) end          -- a dragged laser point is not a 100 m/s car
        p = p + lead
    end
    if bomb(W) then
        -- gravity bias: aim above the target by the sag the wings cannot hold up during the time to go
        local tgo = clamp(len(aim - M.pos) / spd, 0.0, 60.0)
        local q = clamp((spd / 220.0) ^ 2, M.assist and 0.7 or 0.05, 1.0)
        local sag = max(0.0, G - (M.assist and 1.1 or (W.glide or 0.1)) * G * q)
        p = p + v3(0.0, 0.0, 0.5 * sag * tgo * tgo * 0.9)
        return p
    end
    if not bomb(W) and M.profile ~= 'lofted' then
        -- direct: a shallow arc over the ground on the way (does not scrape hills / dunes), straight in at the end
        local d = aim - M.pos
        local hd = sqrt(d.x * d.x + d.y * d.y)
        if hd > 400.0 then p = v3(p.x, p.y, p.z + min((hd - 400.0) * 0.05, 60.0)) end
    end
    if not bomb(W) and M.profile == 'lofted' then
        -- climb to the loft height above the target, then push over into a steep dive (top attack)
        local d = aim - M.pos
        local hd = sqrt(d.x * d.x + d.y * d.y)
        local H = W.loftAlt or W.cruiseAlt or 300.0
        local radius = spd * spd / ((W.turn or 20.0) * G)
        local diveAt = H / 0.84 + radius * 0.6                       -- ~40 deg dive + room to turn into it
        if hd > diveAt and not M.diving then
            p = v3(p.x, p.y, p.z + H)
        else
            M.diving = true
        end
    end
    return p
end

--- loitering munition: fly to the point, circle above it until told to strike, then dive onto it
local function stepLoiter(M, dt, aim, aimVel)
    local W = M.W
    local spd = len(M.vel)
    local dir = spd > 1e-3 and M.vel / spd or v3(0.0, 1.0, 0.0)
    -- runs out of endurance: it strikes the point rather than falling somewhere
    if (W.endurance or 0) > 0 and M.t > W.endurance and M.phase ~= 'strike' then M.phase = 'strike' end
    local want, rate
    if not aim then
        want, rate = dir, 0.0
        spd = spd + clamp(W.speed - spd, -8.0 * dt, 8.0 * dt)
    elseif M.phase == 'strike' then
        -- dive: straight at the point (leading a moving vehicle), gravity speeds it up
        local p = aim
        if aimVel and len(aimVel) > 0.5 then
            local lead = aimVel * clamp(len(aim - M.pos) / max(spd, 30.0), 0.0, 8.0)
            if len(lead) > 60.0 then lead = lead * (60.0 / len(lead)) end
            p = p + lead
        end
        -- first over the point, then tip over: an almost vertical dive (top of the target)
        local dx, dy = p.x - M.pos.x, p.y - M.pos.y
        local hd = sqrt(dx * dx + dy * dy)
        local pullR = spd * spd / ((W.diveTurn or 7.0) * G)
        if not M.diving and hd > max(25.0, pullR * 1.1) and M.pos.z - p.z > 80.0 then
            want = norm(v3(dx, dy, 0.0))
            spd = spd + clamp(W.speed - spd, -8.0 * dt, 8.0 * dt)
        else
            M.diving = true
            want = norm(p - M.pos)
            spd = min(spd + ((W.accel or 15.0) + G * max(0.0, -dir.z)) * dt, W.diveSpeed or 100.0)
        end
        rate = (W.diveTurn or 7.0) * G / max(spd, 20.0)
    else
        -- orbit: a circle of loiterRadius, loiterAlt above the point; the circle follows the point
        local H, R = W.loiterAlt or 400.0, W.loiterRadius or 300.0
        local cx, cy, cz = aim.x, aim.y, aim.z + H
        local rx, ry = M.pos.x - cx, M.pos.y - cy
        local d = sqrt(rx * rx + ry * ry)
        local hx, hy
        if d > R * 1.6 then
            M.phase = 'transit'
            hx, hy = -rx / d, -ry / d                                -- head for the circle
        else
            M.phase = 'loiter'
            local nx, ny = (d > 1.0) and rx / d or 1.0, (d > 1.0) and ry / d or 0.0
            local k = clamp((R - d) / R, -1.0, 1.0) * 1.5           -- back onto the circle
            hx, hy = -ny + nx * k, nx + ny * k                       -- tangent (counter-clockwise) + correction
            local hl = sqrt(hx * hx + hy * hy)
            hx, hy = hx / hl, hy / hl
        end
        local vz = clamp((cz - M.pos.z) * 0.15, -(W.climb or 6.0), W.climb or 6.0)
        want = norm(v3(hx * W.speed, hy * W.speed, vz))
        spd = spd + clamp(W.speed - spd, -8.0 * dt, 8.0 * dt)
        rate = (W.turn or 1.5) * G / max(spd, 20.0)
    end
    dir = turn(dir, want, rate * dt)
    M.vel = dir * spd
    M.pos = M.pos + M.vel * dt
end

function GD.Step(M, dt, aim, aimVel)
    local W = M.W
    M.t = (M.t or 0.0) + dt
    if W.kind == 'loiter' then return stepLoiter(M, dt, aim, aimVel) end
    if bomb(W) then
        local v = M.vel
        local spd = len(v)
        local dir = spd > 1e-3 and v / spd or v3(0.0, 0.0, -1.0)
        -- gravity + drag
        local a = v3(0.0, 0.0, -G) - v * (spd * (W.dragK or 0.00007))
        -- the first moment after release the fins are still locked: it falls clear of the aircraft first
        if aim and M.t > (W.rail or 0.8) then
            local want = norm(GD.AimPoint(M, aim, aimVel) - M.pos)
            local q = clamp((spd / 220.0) ^ 2, M.assist and 0.7 or 0.05, 1.0)   -- fins / wings need airspeed
            local gv = v3(0.0, 0.0, -G)
            -- fin force: turn the flight path onto the line to the target and hold it there against gravity
            local tau = clamp(len(aim - M.pos) / max(spd, 50.0) * 0.2, 0.25, 1.2)   -- tighter at the end
            local F = (want * spd - v) / tau - (gv - dir * dot(gv, dir))
            F = F - dir * dot(F, dir)                                -- only across the flight path
            local lift = (W.glide or 0.1) * G * q                    -- how much it can hold itself up (glide)
            local amax = (W.turn or 3.0) * G * q
            if M.assist then
                -- released outside its reach (Config.Rules.ReleaseEnvelope = 'warn'): the kit holds it up and
                -- keeps its speed so it still gets to the point instead of falling short
                lift, amax = G * 1.1, max(amax, 2.5 * G)
                if spd < 200.0 then a = a + dir * (spd * spd * (W.dragK or 0.00007) + 4.0) end
            end
            if F.z > lift then F = v3(F.x, F.y, lift) end
            local fl = len(F)
            if fl > amax then
                if M.assist then
                    -- holding itself up comes first, turning gets what is left (no sinking in a turn)
                    local fz = min(F.z, amax)
                    local h = v3(F.x, F.y, 0.0)
                    local room = sqrt(max(0.0, amax * amax - fz * fz))
                    local hl = len(h)
                    if hl > room then h = h * (room / hl) end
                    F = v3(h.x, h.y, fz)
                else
                    F = F * (amax / fl)
                end
            end
            a = a + F
        end
        M.vel = v + a * dt
    else
        -- motor
        local spd = len(M.vel)
        local dir = spd > 1e-3 and M.vel / spd or v3(0.0, 1.0, 0.0)
        if M.t < (W.burn or 2.5) then
            spd = min(spd + (W.accel or 200.0) * dt, W.speed)
        elseif W.sustain then
            spd = spd + clamp(W.speed - spd, -40.0 * dt, 40.0 * dt)
        else
            spd = spd - ((W.drag or 0.0001) * spd * spd + G * dir.z) * dt
        end
        spd = max(spd, 40.0)
        if aim and M.t > (W.rail or 0.4) then
            -- off the rail it flies straight along the launch line first, then turns onto its course;
            -- the turn is limited by the g it can pull and by how fast the fins / seeker can swing it
            local want = norm(GD.AimPoint(M, aim, aimVel) - M.pos)
            local rate = min((W.turn or 20.0) * G / spd, math.rad(W.maxRate or 45.0))
            local ease = min(1.0, (M.t - (W.rail or 0.4)) / 0.6)    -- the turn builds up, no snap
            dir = turn(dir, want, rate * ease * dt)
        elseif not aim then
            dir = norm(dir + v3(0.0, 0.0, -G / spd * dt))            -- no guidance: it just falls away
        end
        M.vel = dir * spd
    end
    M.pos = M.pos + M.vel * dt
end

-- ---------------------------------------------------------------------
-- model orientation: the nose of the model along the flight path, whatever axis the model was made along
-- ---------------------------------------------------------------------
local rad, deg, cos, asin, atan = math.rad, math.deg, math.cos, math.asin, math.atan
local function mul(A, B)
    local R = {}
    for i = 1, 3 do
        R[i] = {}
        for j = 1, 3 do R[i][j] = A[i][1] * B[1][j] + A[i][2] * B[2][j] + A[i][3] * B[3][j] end
    end
    return R
end
local function Rx(a) local c, s = cos(a), sin(a) return { { 1, 0, 0 }, { 0, c, -s }, { 0, s, c } } end
local function Ry(a) local c, s = cos(a), sin(a) return { { c, 0, s }, { 0, 1, 0 }, { -s, 0, c } } end
local function Rz(a) local c, s = cos(a), sin(a) return { { c, -s, 0 }, { s, c, 0 }, { 0, 0, 1 } } end
GD.Rx, GD.Ry, GD.Rz, GD.mul = Rx, Ry, Rz, mul

--- the turn that brings the model's nose onto +Y (the game's "forward"):
---   axis 'x' / 'y' / 'z' = the long axis of the model, flip = the nose points the other way,
---   rot = extra correction in degrees { x = pitch, y = roll, z = yaw } (Config: weapon.rot)
function GD.ModelOffset(axis, flip, rot)
    local R
    if axis == 'x' then R = Rz(rad(90.0))            -- +X -> +Y
    elseif axis == 'z' then R = Rx(rad(-90.0))       -- +Z -> +Y
    else R = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } } end
    if flip then R = mul(Rz(rad(180.0)), R) end
    if rot then R = mul(mul(Rz(rad(rot.z or 0.0)), mul(Rx(rad(rot.x or 0.0)), Ry(rad(rot.y or 0.0)))), R) end
    return R
end

--- entity rotation (rotation order 2: R = Rz(z) Rx(x) Ry(y)) that points the model's nose along pitch / yaw
--- @return x, y, z in degrees for SetEntityRotation(ent, x, y, z, 2)
function GD.ModelRot(pitch, yaw, off)
    local R = mul(mul(Rz(rad(yaw)), Rx(rad(pitch))), off)
    local x = asin(clamp(R[3][2], -1.0, 1.0))
    local y = atan(-R[3][1], R[3][3])
    local z = atan(-R[1][2], R[2][2])
    if math.abs(R[3][2]) > 0.9999 then                       -- straight up / down: roll and yaw are one
        y = 0.0
        z = atan(R[2][1], R[1][1])
    end
    return deg(x), deg(y), deg(z)
end

--- rough time to go (s) for the HUD
function GD.TimeToGo(M, aim)
    if not aim then return nil end
    local spd = max(len(M.vel), 30.0)
    return len(aim - M.pos) / spd
end
