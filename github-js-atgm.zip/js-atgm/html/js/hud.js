/* js-atgm | made by Jhonny · JS-STUDIO · build 2.6.1 · 2026-10-30 · (c) all rights reserved - targeting pod symbology, target data dialog, motor sound */
(() => {
  'use strict';
  const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'js-atgm';
  const $ = (id) => document.getElementById(id);
  // posts to Lua; resolves with Lua's answer (or null if there was none)
  const post = (n, d) => fetch(`https://${RES}/${n}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d || {}) })
    .then((r) => r.json()).catch(() => null);

  // ------------------------------------------------------------ world -> symbology coordinates
  // The symbology is drawn in a 1920x1080 box that covers the screen (slice): on 21:9 the top and bottom of the
  // box are cut off, on 4:3 the sides. The game gives screen positions 0..1 of the real screen, so they are
  // mapped through the part of the box that is actually visible.
  let VW = 1920, VH = 1080, OX = 0, OY = 0;
  function view() {
    const w = window.innerWidth || 1920, h = window.innerHeight || 1080;
    const k = Math.max(w / 1920, h / 1080);
    VW = w / k; VH = h / k; OX = (1920 - VW) / 2; OY = (1080 - VH) / 2;
  }
  view();
  window.addEventListener('resize', view);
  const sx = (x) => OX + x * VW;
  const sy = (y) => OY + y * VH;
  const sw = (w) => w * VH * (16 / 9);      // a size given as a part of the screen height
  const NS = 'http://www.w3.org/2000/svg';
  let S = {};
  const T = (k, f) => S[k] || f || k;
  const fmt = (v) => (v == null ? '----' : String(Math.round(v)).padStart(4, '0'));

  // ------------------------------------------------------------ heading tape
  const tape = $('tapeTicks');
  for (let d = -360; d <= 720; d += 5) {
    const x = d * 6;
    const l = document.createElementNS(NS, 'line');
    l.setAttribute('x1', x); l.setAttribute('x2', x);
    l.setAttribute('y1', d % 10 === 0 ? 0 : 8); l.setAttribute('y2', 14);
    l.setAttribute('class', 'tk'); tape.appendChild(l);
    if (d % 30 === 0) {
      const t = document.createElementNS(NS, 'text');
      const h = ((d % 360) + 360) % 360;
      t.textContent = h === 0 ? 'N' : h === 90 ? 'E' : h === 180 ? 'S' : h === 270 ? 'W' : String(h / 10).padStart(2, '0');
      t.setAttribute('x', x); t.setAttribute('y', -6); t.setAttribute('class', 't c s'); tape.appendChild(t);
    }
  }

  // ------------------------------------------------------------ HUD
  const hud = $('hud');
  let lastBoxes = '';
  function frame(d) {
    hud.classList.toggle('ir', d.sensor === 'IR');
    hud.classList.toggle('nvs', d.sensor === 'NVS');
    hud.classList.toggle('seek', !!d.seeker);
    // camera azimuth = aircraft heading + gimbal azimuth (GTA: positive = left)
    const camH = ((d.hdg - d.az) % 360 + 360) % 360;
    $('tapeTicks').setAttribute('transform', `translate(${-camH * 6} 0)`);
    $('hdgV').textContent = String(Math.round(camH) % 360).padStart(3, '0');
    // gimbal box: x = azimuth (right = right), y = elevation
    const [az, up, dn] = d.lim;
    const gx = (-d.az / az) * 90, gy = d.el >= 0 ? (-d.el / up) * 40 : (d.el / dn) * 40;
    $('gimLos').setAttribute('x', gx - 7); $('gimLos').setAttribute('y', gy - 7);
    // field of view gate
    const g = { WFOV: 1, MFOV: 0.72, NFOV: 0.5, ZOOM: 0.36 }[d.fov] || 1;
    $('gate').setAttribute('transform', `scale(${g})`);
    $('laserMark').classList.toggle('hidden', !d.lasing);
    // the point
    const pt = $('pt');
    pt.classList.toggle('hidden', d.pt == null);
    if (d.pt != null) pt.setAttribute('r', (d.pt * VH / 1080).toFixed(1));
    $('ptRing').classList.toggle('hidden', !d.ptv);
    if (d.ptv) $('ptRing').setAttribute('r', (Math.max(d.pt || 8, 8) + 14).toFixed(1));
    // weapons in the air: where each one is (white) and the point it is going to (blue)
    let mk = '';
    (d.marks || []).forEach((m) => {
      if (m.ax != null) {
        const ax = sx(m.ax), ay = sy(m.ay);
        if (Math.hypot(ax - 960, ay - 540) > 14) mk += `<path class="mk-a" d="M${ax} ${ay - 14} L${ax + 14} ${ay} L${ax} ${ay + 14} L${ax - 14} ${ay} Z"/>`;
      }
      if (m.mx != null) {
        const x = sx(m.mx), y = sy(m.my);
        mk += `<circle class="mk-m" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7"/><text class="mk-t" x="${(x + 12).toFixed(1)}" y="${(y - 10).toFixed(1)}">${esc(m.w)}${m.ph ? ' ' + m.ph : ''}${m.tof != null ? ' ' + m.tof : ''}</text>`;
      }
    });
    $('marks').innerHTML = mk;

    // marked targets: corner brackets on the ground with their number; green = a weapon is on its way
    let tm = '';
    const mmss = (v) => (v == null ? '--' : `${Math.floor(v / 60)}:${String(Math.max(0, v) % 60).padStart(2, '0')}`);
    (d.tl || []).forEach((t) => {
      if (t.x == null) return;
      const x = sx(t.x), y = sy(t.y), r = t.nx ? 22 : 18, c = r * 0.45;
      const cls = `tm${t.st !== 'free' ? ' fly' : ''}${t.nx ? ' nx' : ''}`;
      tm += `<path class="${cls}" d="M${x - r} ${y - r + c} V${y - r} H${x - r + c} M${x + r - c} ${y - r} H${x + r} V${y - r + c} M${x + r} ${y + r - c} V${y + r} H${x + r - c} M${x - r + c} ${y + r} H${x - r} V${y + r - c}"/>`;
      tm += `<text class="tm-t${t.st !== 'free' ? ' fly' : ''}" x="${(x + r + 6).toFixed(1)}" y="${(y - r + 4).toFixed(1)}">T${t.n}${t.st === 'fly' ? ' ' + esc(t.w || '') + ' ' + mmss(t.tof) : ''}</text>`;
    });
    $('tmarks').innerHTML = tm;
    const tgl = d.tl || [];
    $('tlist').innerHTML = tgl.length ? `<div class="tl-h">TGT ${tgl.length}</div>` + tgl.map((t) =>
      `<div class="tl ${t.st === 'free' ? 'free' : ''} ${t.nx ? 'nx' : ''}">T${t.n} ${t.d != null ? (t.d >= 1000 ? (t.d / 1000).toFixed(1) + 'KM' : t.d + 'M') : ''} ${t.st === 'fly' ? esc(t.w || '') + ' ' + mmss(t.tof) : (t.st === 'pend' ? '...' : '')}</div>`).join('') : '';

    $('sensor').textContent = d.sensor;
    $('fov').textContent = `${d.fov}  ${d.fovDeg < 10 ? d.fovDeg.toFixed(1) : Math.round(d.fovDeg)}°`;
    $('track').classList.toggle('hidden', !d.track);
    $('track').textContent = d.track === 'VT' ? 'VEH TRK' : 'PT TRK';
    const la = $('laser');
    la.classList.toggle('on', !!d.lasing);
    la.textContent = d.lasing ? `LASE ${d.code}` : `${d.latched ? 'LSR ARM' : 'LSR'} ${d.code}`;
    $('range').textContent = d.lrange != null ? `L ${fmt(d.lrange)}` : (d.range != null ? `N ${fmt(d.range)}` : 'N ----');
    $('lst').classList.toggle('hidden', !d.lst);
    $('lst').textContent = `LST ${d.code}`;

    $('alt').textContent = d.alt; $('agl').textContent = d.agl; $('kts').textContent = d.kts; $('podN').textContent = d.pod;

    const tg = $('tgt');
    let tl = d.tgt ? `TGT ${d.tgt.x} / ${d.tgt.y}<br>EL ${d.tgt.z}  ${esc(d.tgt.zone || '')}` : 'TGT ---- / ----';
    if (d.tgt && d.tgt.brg != null) tl += `<br>BRG ${String(d.tgt.brg).padStart(3, '0')}  GR ${d.tgt.gr >= 1000 ? (d.tgt.gr / 1000).toFixed(1) + 'KM' : d.tgt.gr + 'M'}`;
    if (d.gps) tl += `<br>CRD ${d.gps.x} / ${d.gps.y}`;
    tg.innerHTML = tl;

    $('wlist').innerHTML = (d.weapons || []).map((w) => `<span class="${w.s ? 'sel' : ''} ${w.n <= 0 ? 'empty' : ''}">${esc(w.k)} ${w.n}</span>`).join('');
    $('wlabel').textContent = d.wlabel + (d.profile ? `  ${d.profile === 'lofted' ? 'LOFT' : 'DIR'}` : '');
    const ws = $('wstate');
    ws.className = d.ready ? (d.warn ? 'wrn' : 'rdy') : 'no';
    ws.textContent = d.ready ? (d.warn ? `RDY  ${d.warn}` : 'RDY') : (d.why || '');
    const hms = (s) => `${Math.floor(s / 3600)}:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
    $('flying').innerHTML = (d.flying || []).filter((m) => !m.mk).map((m) => {
      if (m.ph) return `<div>${esc(m.w)} ${m.ph}${m.left != null ? ' ' + hms(m.left) : ''}${m.tof != null ? ' TOF ' + m.tof : ''}${m.ph !== 'STRIKE' ? ' <span class="k">X STRIKE</span>' : ''}</div>`;
      return `<div>${m.mk ? 'T' + m.mk + ' ' : ''}${esc(m.w)} ${m.loal ? 'LOAL ' : ''}TOF ${m.tof != null ? m.tof : '--'}</div>`;
    }).join('');

    const ms = $('msg');
    ms.className = d.msg ? d.msg.l : '';
    ms.textContent = d.msg ? d.msg.t : '';

    // target boxes
    const b = (d.boxes || []).map((x) => {
      const w = sw(x.w), h = w * 0.62, cx = sx(x.x), cy = sy(x.y);
      return `<rect class="bx${x.t ? ' trk' : ''}${x.p ? ' ped' : ''}" x="${(cx - w / 2).toFixed(1)}" y="${(cy - h / 2).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}"/>`;
    }).join('');
    if (b !== lastBoxes) { $('boxes').innerHTML = b; lastBoxes = b; }

    // far contacts (the game does not have them here; positions come from the server): heat spots + a cue box
    let ht = '';
    (d.ct || []).forEach((c) => {
      const cx = sx(c.x), cy = sy(c.y);
      const w = Math.max(3, c.w * VH), h = Math.max(5, c.h * VH);
      if (c.k === 'ped') {
        ht += `<rect class="ht" x="${(cx - w / 2).toFixed(1)}" y="${(cy - h / 2).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="${(w / 2).toFixed(1)}"/>`;
      } else {
        ht += `<rect class="ht" x="${(cx - w / 2).toFixed(1)}" y="${(cy - h / 2).toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="${(Math.min(w, h) * 0.3).toFixed(1)}"/>`;
      }
      const bw = Math.max(w, h) + 14;
      ht += `<rect class="ht-c${c.t ? ' trk' : ''}" x="${(cx - bw / 2).toFixed(1)}" y="${(cy - bw / 2).toFixed(1)}" width="${bw.toFixed(1)}" height="${bw.toFixed(1)}"/>`;
    });
    $('heat').innerHTML = ht;

    // missile seeker (Spike NLOS)
    const sk = $('seeker');
    sk.classList.toggle('hidden', !d.seeker);
    if (d.seeker) {
      $('skW').textContent = d.seeker.short || 'SPK';
      $('skR').textContent = d.seeker.range != null ? `R ${fmt(d.seeker.range)}` : 'R ----';
      $('skT').textContent = d.seeker.tof != null ? `TOF ${Math.round(d.seeker.tof)}` : (d.seeker.ph || '');
      $('skA').textContent = d.seeker.alt != null ? `ALT ${Math.round(d.seeker.alt)}` : '';
    }
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

  // ------------------------------------------------------------ dialog
  const dlg = $('dlg');
  function applyStrings() {
    document.querySelectorAll('[data-t]').forEach((el) => { el.textContent = T(el.dataset.t, el.textContent); });
  }
  function openDialog(d) {
    $('codes').innerHTML = (d.codes || []).map((c) => `<button data-act="code" data-code="${c}" class="${c === d.code ? 'on' : ''}">${c}</button>`).join('');
    $('points').innerHTML = (d.points || []).map((p, i) =>
      `<div class="pt"><span>P${i + 1}  ${p.x} / ${p.y}  EL ${p.z}  ${esc(p.zone || '')}</span><button data-act="use" data-i="${i + 1}" class="small">${esc(T('d_use', 'Use'))}</button></div>`).join('');
    if (d.gps) { $('ix').value = d.gps.x; $('iy').value = d.gps.y; $('iz').value = d.gps.z; }
    showErr('');
    dlg.classList.remove('off');
    setTimeout(() => $('ix').focus(), 30);
  }
  const err = $('dErr');
  function showErr(t) { err.textContent = t || ''; err.classList.toggle('hidden', !t); }
  function hideDialog() { dlg.classList.add('off'); showErr(''); }
  // a coordinate the game can use: a finite number on the map
  const okNum = (v) => v !== '' && Number.isFinite(Number(v)) && Math.abs(Number(v)) <= 10000;
  let busy = false;
  async function act(msg) {
    if (busy) return;
    busy = true;
    const r = await post('dlg', msg);
    busy = false;
    // Lua says whether the dialog closes (it releases the mouse at the same moment)
    if (r && r.close) hideDialog();
    else showErr(r && r.err ? r.err : '');
  }
  dlg.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const a = b.dataset.act;
    const msg = { act: a };
    if (a === 'set') {
      const x = $('ix').value.trim(), y = $('iy').value.trim(), z = $('iz').value.trim();
      if (!okNum(x) || !okNum(y) || (z !== '' && !Number.isFinite(Number(z)))) { showErr(T('d_bad', 'Enter X and Y')); return; }
      msg.x = Number(x); msg.y = Number(y); msg.z = z === '' ? null : Number(z);
    }
    if (a === 'code') {
      msg.code = Number(b.dataset.code);
      dlg.querySelectorAll('#codes button').forEach((x) => x.classList.toggle('on', x === b));
    }
    if (a === 'use') msg.i = Number(b.dataset.i);
    act(msg);
  });
  document.addEventListener('keydown', (e) => {
    if (dlg.classList.contains('off')) return;
    if (e.key === 'Escape') { hideDialog(); busy = false; post('dlg', { act: 'close' }); }
    if (e.key === 'Enter') { dlg.querySelector('[data-act="set"]').click(); }
  });

  // ------------------------------------------------------------ sound (synthesised: no audio files)
  let ac = null, noise = null;
  const voices = {};
  function audio() {
    if (ac) return ac;
    try {
      ac = new (window.AudioContext || window.webkitAudioContext)();
      const len = ac.sampleRate * 2;
      noise = ac.createBuffer(1, len, ac.sampleRate);
      const ch = noise.getChannelData(0);
      let b = 0;
      for (let i = 0; i < len; i++) { b = 0.97 * b + 0.03 * (Math.random() * 2 - 1); ch[i] = b * 6; }
    } catch (e) { ac = null; }
    return ac;
  }
  function voice(id) {
    if (voices[id]) return voices[id];
    const a = audio(); if (!a) return null;
    const src = a.createBufferSource(); src.buffer = noise; src.loop = true;
    const bp = a.createBiquadFilter(); bp.type = 'lowpass'; bp.frequency.value = 900;
    const g = a.createGain(); g.gain.value = 0;
    const p = a.createStereoPanner();
    src.connect(bp); bp.connect(g); g.connect(p); p.connect(a.destination); src.start();
    return (voices[id] = { src, g, p });
  }
  function snd(m) {
    if (m.vol == null) {
      const v = voices[m.id];
      if (v) { try { v.src.stop(); } catch (e) { /* stopped */ } delete voices[m.id]; }
      return;
    }
    const v = voice(m.id); if (!v) return;
    const t = ac.currentTime;
    v.g.gain.setTargetAtTime(Math.min(0.6, m.vol * 0.6), t, 0.08);
    v.p.pan.setTargetAtTime(m.pan || 0, t, 0.08);
  }
  function launch(bomb) {
    const a = audio(); if (!a) return;
    const src = a.createBufferSource(); src.buffer = noise;
    const f = a.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = bomb ? 300 : 1400; f.Q.value = 0.7;
    const g = a.createGain(); const t = a.currentTime;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(bomb ? 0.25 : 0.9, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + (bomb ? 0.5 : 1.6));
    if (!bomb) f.frequency.exponentialRampToValueAtTime(400, t + 1.6);
    src.connect(f); f.connect(g); g.connect(a.destination); src.start(); src.stop(t + 1.7);
  }

  // ------------------------------------------------------------ impact flash
  function impact(m) {
    const fl = $('flash');
    fl.classList.remove('on'); void fl.offsetWidth; fl.classList.add('on');
    if (m.x == null) return;
    const g = document.createElementNS(NS, 'g');
    g.setAttribute('transform', `translate(${sx(m.x).toFixed(1)} ${sy(m.y).toFixed(1)})`);
    g.innerHTML = '<circle class="imp" r="10"/><text class="t c imp-t" y="-46">IMPACT</text>';
    $('sym').appendChild(g);
    setTimeout(() => g.remove(), 1600);
  }

  // ------------------------------------------------------------ messages
  window.addEventListener('message', (e) => {
    const m = e.data || {};
    switch (m.a) {
      case 'hud': frame(m); break;
      case 'show':
        clearTimeout(window.__off);
        if (m.on) {
          hud.classList.remove('off', 'closing');
          if (m.boot > 0) {
            hud.style.setProperty('--boot', `${m.boot}ms`);
            $('bootPod').textContent = m.label || 'POD';
            hud.classList.remove('boot'); void hud.offsetWidth; hud.classList.add('boot');
            window.__boot = setTimeout(() => hud.classList.remove('boot'), m.boot + 50);
          }
        } else if (!hud.classList.contains('off')) {
          hud.classList.remove('boot');
          hud.classList.add('closing');
          window.__off = setTimeout(() => { hud.classList.add('off'); hud.classList.remove('closing'); }, 230);
        }
        if (m.b) { $('bootB').textContent = `${m.b.author || ''} ${m.b.name || ''} ${m.b.version || ''}`; document.body.dataset.b = btoa(`${m.b.author}|${m.b.name}|${m.b.version}|${m.b.built}`); }
        if (m.keys) $('keys').innerHTML = m.keys.map((k) => `<b>${esc(k[0])}</b>${esc(k[1])}`).join('');
        if (m.strings) {
          S = m.strings; applyStrings();
          const rtl = /[֐-׿]/.test(S.d_title || '');
          document.querySelector('.panel').dir = rtl ? 'rtl' : 'ltr';
        }
        if (!m.on) hideDialog();
        break;
      case 'dialog': openDialog(m); break;
      case 'help': {
        const h = $('help');
        h.classList.toggle('off', !m.on);
        if (m.on) {
          $('hTitle').textContent = m.title || '';
          $('hSteps').innerHTML = (m.steps || []).map((t) => `<li>${esc(t)}</li>`).join('');
          $('hRows').innerHTML = (m.rows || []).map((r) => `<b>${esc(r[0])}</b><span>${esc(r[1])}</span>`).join('');
          $('hFoot').textContent = m.foot || '';
          const rtl = /[\u0590-\u05FF]/.test(m.title || '');
          h.querySelector('.panel').dir = rtl ? 'rtl' : 'ltr';
        }
        break;
      }
      case 'dialogClose': hideDialog(); break;
      case 'snd': snd(m); break;
      case 'launch': launch(m.bomb); break;
      case 'impact': impact(m); break;
      default: break;
    }
  });
})();
