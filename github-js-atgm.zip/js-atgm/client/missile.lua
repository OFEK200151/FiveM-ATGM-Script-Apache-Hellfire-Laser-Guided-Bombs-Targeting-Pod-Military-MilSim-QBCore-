--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     Missiles and bombs in the world.
       own      simulated here (shared/guidance.lua), every frame: guidance source (laser spot with code,
                coordinate, tracked vehicle, seeker), swept collision, proximity fuze, arming distance,
                explosion credited to the shooter, armour kill. ~8 position reports a second to the server.
       remote   other players' missiles near us: a local model that follows their reports (dead reckoning),
                with smoke trail and motor sound.
     The loop sleeps when nothing flies. ]]
Missile = {}
local C = Config
local own, remote = {}, {}
local count = 0
local rail = 0
local armourSet = {}
for _, m in ipairs(C.Armour) do armourSet[joaat(m)] = true end

-- ---------------------------------------------------------------------
-- model + effects
-- ---------------------------------------------------------------------
--- how each model lies: its long axis is the body of the missile / bomb (models are not all made along
--- the same axis, which made them fly sideways or standing up). Config: weapon.axis / flip / rot to override.
local shapes = {}          -- model hash -> { off = rotation matrix, tail = {x,y,z} }
local function shape(h, W)
    local key = h .. ':' .. (W.axis or '') .. ':' .. tostring(W.flip) .. ':' .. tostring(W.rot)
    if shapes[key] then return shapes[key] end
    local mn, mx = GetModelDimensions(h)
    local sx, sy, sz = mx.x - mn.x, mx.y - mn.y, mx.z - mn.z
    local axis = W.axis
    if not axis then
        axis = 'y'
        if sx > sy * 1.15 and sx >= sz then axis = 'x' elseif sz > sy * 1.15 and sz > sx then axis = 'z' end
    end
    local len = ({ x = sx, y = sy, z = sz })[axis] or 1.0
    local back = (W.flip and 1.0 or -1.0) * len * 0.5            -- the tail end (where the smoke comes out)
    local t = { off = GD.ModelOffset(axis, W.flip, W.rot), axis = axis,
                tail = { axis == 'x' and back or 0.0, axis == 'y' and back or 0.0, axis == 'z' and back or 0.0 } }
    shapes[key] = t
    return t
end
Missile.Shape = shape

local function prop(W, at)
    local h = U.model(W.model) or U.model(C.FallbackModel)
    if not h then return nil end
    local o = CreateObjectNoOffset(h, at.x, at.y, at.z, false, false, false)
    SetEntityCollision(o, false, false)
    FreezeEntityPosition(o, true)            -- no physics: it is placed every frame; gravity would drag the model down
    SetEntityHasGravity(o, false)
    SetEntityLodDist(o, 2000)
    local sh = shape(h, W)
    SetModelAsNoLongerNeeded(h)
    return o, sh
end

local function trail(W, ent, sh)
    if not W.trail or not ent then return nil end
    if not U.ptfx('scr_ar_planes') then return nil end
    U.useAsset('scr_ar_planes')
    local t = sh and sh.tail or { 0.0, -0.6, 0.0 }
    return StartParticleFxLoopedOnEntity('scr_ar_trail_smoke', ent, t[1], t[2], t[3], 0.0, 0.0, 0.0, 0.55, false, false, false)
end

--- put the model where the weapon is, nose along the flight path
local function place(o, pos, vel)
    local ent = o.ent
    if not ent or not DoesEntityExist(ent) then return end
    SetEntityCoordsNoOffset(ent, pos.x, pos.y, pos.z, false, false, false)
    if #vel > 0.5 and o.shape then
        local p, y = U.rot(U.norm(vel))
        local rx, ry, rz = GD.ModelRot(p, y, o.shape.off)
        SetEntityRotation(ent, rx, ry, rz, 2, true)
    end
end

--- the model is loaded in the background: the weapon flies (and is simulated) from the first frame,
--- the model and its smoke trail appear as soon as the game has loaded them
local function dress(o, alive)
    CreateThread(function()
        local ent, sh = prop(o.W, o.drawn or o.pos)
        if not alive() then if ent then DeleteObject(ent) end return end
        o.ent, o.shape = ent, sh
        place(o, o.drawn or o.pos, o.vel)
        o.fx = trail(o.W, ent, sh)
    end)
end

local function remove(o)
    o.gone = true
    if o.mark then Pod.MarkDone(o.mark, o.hit == true) o.mark = nil end
    if o.fx then StopParticleFxLooped(o.fx, false) end
    if o.ent and DoesEntityExist(o.ent) then DeleteObject(o.ent) end
    Hud.Sound(o.sid, nil)
end

-- ---------------------------------------------------------------------
-- launch
-- ---------------------------------------------------------------------
--- where the weapon leaves the aircraft: alternating left / right rails or pylons
function Missile.LaunchPoint(veh, W)
    local mn, mx = GetModelDimensions(GetEntityModel(veh))
    local side = (rail % 2 == 0) and 1.0 or -1.0
    if GD.IsBomb(W) then
        return GetOffsetFromEntityInWorldCoords(veh, side * mx.x * 0.3, 0.2, mn.z * 0.85)
    end
    return GetOffsetFromEntityInWorldCoords(veh, side * mx.x * 0.42, mx.y * 0.15, mn.z * 0.45)
end

function Missile.Start(id, key, spec)
    local W = C.Weapons[key]
    local veh = spec.veh
    if not DoesEntityExist(veh) then return TriggerServerEvent('js-atgm:done', id, nil) end
    local from = Missile.LaunchPoint(veh, W)
    rail = rail + 1
    local vv = GetEntityVelocity(veh)
    local fwd = GetEntityForwardVector(veh)
    local vel
    if GD.IsBomb(W) then
        vel = vv + vector3(0.0, 0.0, -3.0)                         -- ejected from the rack
    else
        vel = vv + fwd * 30.0                                      -- off the rail along the nose
    end
    local M = {
        id = id, key = key, W = W, pos = from, vel = vel, t = 0.0, launch = from, veh = veh,
        profile = spec.profile or 'direct', mode = spec.mode, code = spec.code, ent = nil,
        tpos = spec.pos, tent = spec.ent, tcid = spec.cid, loal = spec.loal, seen = spec.loal and -99.0 or 0.0, coords = spec.coords,
        sendT = 0.0, sid = 'm' .. id,
        assist = spec.warn ~= nil,          -- released outside its reach: the kit makes sure it gets there
        mark = spec.mark,                   -- a marked target (T1, T2 ...): it goes there whatever the pod does
    }
    own[id] = M
    count = count + 1
    dress(M, function() return own[id] == M end)
    Hud.Launch(GD.IsBomb(W))
end

--- an own weapon with a camera in the air (latest): Spike NLOS / loitering munition, for the seeker view
function Missile.Controllable()
    local best
    for id, M in pairs(own) do
        if (M.W.kind == 'fou' or M.W.kind == 'loiter') and (not best or id > best) then best = id end
    end
    return best
end

--- loitering munition: the latest one still circling leaves the circle and dives onto the point
function Missile.Strike()
    local best
    for id, M in pairs(own) do
        if M.W.kind == 'loiter' and M.phase ~= 'strike' and (not best or id > best) then best = id end
    end
    if not best then return false end
    own[best].phase = 'strike'
    return true
end

--- far contacts own weapons fly to (they must keep coming from the server)
function Missile.Cids()
    local out = {}
    for _, M in pairs(own) do
        local k = (M.mark and M.mark.cid) or M.tcid
        if k then out[#out + 1] = k end
    end
    return out
end

--- read-only view of an own weapon in the air (other resources / tests)
function Missile.Get(id) return own[id] end

--- any own weapon in the air
function Missile.Busy() return next(own) ~= nil end

--- an own laser guided weapon with this code is in the air (the laser keeps firing for it)
function Missile.NeedsLaser(code)
    for _, M in pairs(own) do
        if M.mode == 'laser' and M.code == code then return true end
    end
    return false
end

--- own weapons in the air, for the HUD (pos = where it is, aim = where it is going)
function Missile.List()
    local out = {}
    for id, M in pairs(own) do
        local ph, left = nil, nil
        if M.W.kind == 'loiter' then
            ph = (M.phase == 'strike' and 'STRIKE') or (M.phase == 'loiter' and 'LOITER') or 'TRANSIT'
            if (M.W.endurance or 0) > 0 and M.phase ~= 'strike' then left = math.max(0, math.floor(M.W.endurance - M.t)) end
        end
        out[#out + 1] = { id = id, w = M.W.short, ph = ph, left = left, mk = M.mark and M.mark.n or nil,
                          tof = (M.W.kind ~= 'loiter' or M.phase == 'strike') and M.aimNow and math.floor(GD.TimeToGo(M, M.aimNow) + 0.5) or nil,
                          lase = M.mode == 'laser' and (M.t - M.seen) < 1.0, loal = M.loal and M.seen < 0,
                          pos = M.pos, aim = M.aimNow }
    end
    table.sort(out, function(a, b) return a.id < b.id end)
    return out
end

-- ---------------------------------------------------------------------
-- impact
-- ---------------------------------------------------------------------
local function armourKill(ent, pos, id)
    local veh = (ent and ent ~= 0 and IsEntityAVehicle(ent)) and ent or nil
    if not veh then
        local best, bd = nil, 7.0
        for _, v in ipairs(GetGamePool('CVehicle')) do
            local d = #(GetEntityCoords(v) - pos)
            if d < bd then best, bd = v, d end
        end
        veh = best
    end
    if not veh or not armourSet[GetEntityModel(veh)] then return end
    if NetworkHasControlOfEntity(veh) then
        SetVehicleEngineHealth(veh, -4000.0)
        SetVehiclePetrolTankHealth(veh, -1000.0)
        ExplodeVehicle(veh, true, false)
    elseif NetworkGetEntityIsNetworked(veh) then
        TriggerServerEvent('js-atgm:armourHit', NetworkGetNetworkIdFromEntity(veh), id)
    end
end

RegisterNetEvent('js-atgm:killVehicle', function(netId)
    local veh = NetworkGetEntityFromNetworkId(netId)
    if veh == 0 or not DoesEntityExist(veh) or not NetworkHasControlOfEntity(veh) then return end
    if not armourSet[GetEntityModel(veh)] then return end
    SetVehicleEngineHealth(veh, -4000.0)
    SetVehiclePetrolTankHealth(veh, -1000.0)
    ExplodeVehicle(veh, true, false)
end)

--- a large blast effect at an impact (seen from far away through the pod)
function Missile.Blast(W, pos)
    if not C.Picture.ImpactFx then return end
    local s = (W.explosion or {}).fx or 0.5
    if s <= 0 or not U.ptfx('scr_xm_orbital') then return end
    U.useAsset('scr_xm_orbital')
    StartParticleFxNonLoopedAtCoord('scr_xm_orbital_blast', pos.x, pos.y, pos.z, 0.0, 0.0, 0.0, s, false, false, false)
end

local function impact(M, pos, ent, why)
    own[M.id] = nil
    count = count - 1
    local ped = PlayerPedId()
    local armed = #(pos - M.launch) >= (M.W.arm or 0.0)
    M.hit = armed and why ~= 'selfdestruct'
    local E = M.W.explosion or { type = 5, scale = 1.0 }
    if why == 'selfdestruct' then
        AddOwnedExplosion(ped, pos.x, pos.y, pos.z, 18, 0.4, true, false, 0.2)
        Pod.Message('m_selfdestruct', 'warn', 2.5)
    elseif armed then
        -- a penetrator goes off deep inside; the blast also breaks out at the hole it went in through
        local top = M.pen and M.pen.entry or pos
        AddOwnedExplosion(ped, pos.x, pos.y, pos.z, E.type, E.scale or 1.0, true, false, 1.0)
        if E.extra then AddOwnedExplosion(ped, top.x, top.y, top.z + 0.5, E.extra, (E.scale or 1.0) * 0.8, true, false, 0.6) end
        if (E.ring or 0) > 0 then
            -- one heavy charge: the shock wave wrecks a wide circle around the hole (not bomblets)
            local r = E.ringRadius or 10.0
            for i = 1, E.ring do
                local a = (i / E.ring) * math.pi * 2.0
                AddOwnedExplosion(ped, top.x + math.cos(a) * r, top.y + math.sin(a) * r, top.z + 0.5, E.ringType or 50, (E.scale or 1.0) * 0.5, i == 1, false, 0.0)
            end
            if M.pen then AddOwnedExplosion(ped, (top.x + pos.x) * 0.5, (top.y + pos.y) * 0.5, (top.z + pos.z) * 0.5, E.type, (E.scale or 1.0) * 0.7, false, false, 0.0) end
        end
        if M.W.armour then armourKill(M.pen and M.pen.ent or ent, top, M.id) end
        Missile.Blast(M.W, top)
        Hud.Impact(top)
        Pod.Message('m_impact', 'good', 2.0)
        pos = top                                        -- what the others see (the hole at the surface)
    else
        AddOwnedExplosion(ped, pos.x, pos.y, pos.z, 18, 0.2, true, false, 0.0)    -- not armed yet: a dud
    end
    TriggerServerEvent('js-atgm:done', M.id, { pos.x, pos.y, pos.z })
    remove(M)
end

-- ---------------------------------------------------------------------
-- guidance source of an own weapon this frame
-- ---------------------------------------------------------------------
local function guidance(M, dt)
    -- a marked target: its own target, given at release (the designation system keeps it; the pod is free to
    -- look at the next one). A marked vehicle is followed.
    if M.mark and Pod.seeker ~= M.id then
        local m = M.mark
        if m.ent and DoesEntityExist(m.ent) then
            M.tpos = GetEntityCoords(m.ent) + vector3(0.0, 0.0, IsEntityAPed(m.ent) and 0.2 or 0.4)
            return M.tpos, GetEntityVelocity(m.ent)
        end
        if m.cid then
            local p, v = Contacts.Pos(m.cid)
            if p then M.tpos = p return p, v end
        end
        M.tpos = m.pos
        return M.tpos, nil
    end
    if M.mode == 'laser' then
        M.losT = (M.losT or 0.0) - dt
        local spot = Pod.NearestSpot(M.code, M.tpos)
        if spot then
            -- the seeker must see the spot (checked 4x a second near the target; far away it is assumed)
            local visible = true
            if #(spot - M.pos) < 3500.0 then
                if M.losT <= 0.0 then
                    M.losT = 0.25
                    local hit, hp = U.ray(M.pos, spot + vector3(0.0, 0.0, 0.3), M.ent, 1 + 16)
                    M.losOk = not hit or #(hp - spot) < 4.0
                end
                visible = M.losOk ~= false
            end
            if visible then
                if M.prevSpot and M.t - (M.prevSpotT or 0) > 0.0 then
                    local v = (spot - M.prevSpot) / math.max(M.t - M.prevSpotT, 1e-3)
                    if #v < 60.0 then M.spotVel = M.spotVel and (M.spotVel * 0.8 + v * 0.2) or v end
                end
                M.prevSpot, M.prevSpotT = spot, M.t
                M.tpos, M.seen, M.loal = spot, M.t, false
            end
        end
        local mem = C.Laser.Memory or 0.0
        if mem <= 0.0 then
            -- never gives up: with no spot it keeps going to the last place it saw it (or where it was fired at)
            local fresh = M.seen >= 0.0 and M.t - M.seen < 0.6
            return M.tpos, fresh and M.spotVel or nil
        end
        if M.seen >= 0.0 then
            -- the seeker saw the spot: a short gap (smoke, a passing building) is bridged on the last known point
            if M.t - M.seen <= mem then
                M.lostMsg = false
                local fresh = M.t - M.seen < 0.6
                return M.tpos, fresh and M.spotVel or nil
            end
        elseif M.W.kind == 'sal' and #(M.tpos - M.pos) > (C.Laser.LoalAcquire or 1500.0) then
            -- LOAL missile before it has seen the spot: flies to the release point by itself
            return M.tpos, nil
        end
        -- no spot: a laser seeker has nothing to steer by - it goes on unguided until a spot shows up again
        if not M.lostMsg then M.lostMsg = true Pod.Message('m_laser_lost', 'bad', 2.0) end
        return nil, nil
    end
    -- Spike NLOS: while the operator watches through the pod (not the seeker), it goes where the pod marks
    -- Spike / loitering munition / datalink bomb (released at the pod point): go where the pod point is now
    local follows = M.W.kind == 'fou' or M.W.kind == 'loiter' or (M.W.datalink and not M.coords)
    if follows and Pod.seeker ~= M.id and Pod.track then
        if Pod.track.ent and DoesEntityExist(Pod.track.ent) then M.mode, M.tent, M.tcid = 'entity', Pod.track.ent, Pod.track.cid
        elseif Pod.track.cid then M.mode, M.tent, M.tcid = 'entity', nil, Pod.track.cid
        else M.mode, M.tent, M.tcid, M.tpos = 'point', nil, nil, Pod.track.pos end
    end
    if M.mode == 'entity' then
        if M.tent and DoesEntityExist(M.tent) then
            M.tpos = GetEntityCoords(M.tent) + vector3(0.0, 0.0, IsEntityAPed(M.tent) and 0.2 or 0.4)
            return M.tpos, GetEntityVelocity(M.tent)
        end
        if M.tcid then
            local p, v, e = Contacts.Pos(M.tcid)
            if e then M.tent = e end
            if p then M.tpos = p return p, v end
        end
        return M.tpos, nil
    end
    return M.tpos, nil
end

--- something was hit: a penetrator (bunker buster) keeps going in and goes off after `penetrate` metres
local function contact(M, hp, he)
    if M.W.penetrate and not M.pen and #(hp - M.launch) >= (M.W.arm or 0.0) then
        M.pen = { entry = hp, left = M.W.penetrate, ent = he }
        M.pos = hp
        return
    end
    return impact(M, hp, he)
end

--- inside the target: no collisions, it slows down, then the delayed fuze sets it off
local function stepPen(M, dt)
    local spd = #M.vel
    local dir = spd > 1e-3 and M.vel / spd or vector3(0.0, 0.0, -1.0)
    local step = math.min(M.pen.left, math.max(spd * 0.4, 60.0) * dt)
    M.pos = M.pos + dir * step
    M.pen.left = M.pen.left - step
    place(M, M.pos, M.vel)
    if M.pen.left <= 0.01 then return impact(M, M.pos, M.pen.ent) end
end

local function stepOwn(M, dt)
    if M.pen then return stepPen(M, dt) end
    local prev = M.pos
    local aim, aimVel = guidance(M, dt)
    M.aimNow = aim or M.tpos
    GD.Step(M, dt, aim, aimVel)
    local armed = #(M.pos - M.launch) >= (M.W.arm or 0.0)
    -- swept hit test along this frame's path (the aircraft is ignored for the first 1.5 s)
    -- map, vehicles, peds, objects, glass (not bushes and tree leaves: those do not stop a missile)
    local ignore = M.t < 1.5 and M.veh or M.ent
    local hit, hp, he = U.ray(prev, M.pos, ignore, 1 + 2 + 4 + 8 + 16 + 64)
    if hit and not (he == M.veh and M.t < 1.5) then return contact(M, hp, he) end
    -- the ground: real ground where it is loaded; the height map (with a margin) where it is not
    M.gT = (M.gT or 0.0) - dt
    if M.gT <= 0.0 then
        M.gT = 0.1
        local ok, gz = GetGroundZFor_3dCoord(M.pos.x, M.pos.y, M.pos.z + 5.0, false)
        if ok then
            M.gz = gz
        else
            local floor = U.hmBottom(M.pos.x, M.pos.y)
            M.gz = (floor and floor > -100.0) and (floor - 6.0) or nil
        end
    end
    if M.gz and M.pos.z < M.gz - 0.5 then
        return contact(M, vector3(M.pos.x, M.pos.y, M.gz), 0)
    end
    -- proximity fuze / arrival
    if armed and aim and not M.W.penetrate then             -- a penetrator only goes off after it went in
        local d = #(M.pos - aim)
        -- vehicle: fuze at the closest pass (within 4 m), or right on it
        if M.mode == 'entity' and d < 4.0 and (d < 1.5 or (M.lastD and d > M.lastD)) then return impact(M, M.pos, M.tent or 0) end
        if M.mode ~= 'entity' and d < 1.5 then return impact(M, M.pos, M.tent or 0) end
        M.lastD = d
    end
    if (M.W.maxTime or 0) > 0 and M.t > M.W.maxTime then return impact(M, M.pos, 0, 'selfdestruct') end
    place(M, M.pos, M.vel)
    -- report to the server (others draw it)
    M.sendT = M.sendT - dt
    if M.sendT <= 0.0 then
        M.sendT = 0.12
        local p, v = M.pos, M.vel
        TriggerServerEvent('js-atgm:upd', M.id, { math.floor(p.x * 10) / 10, math.floor(p.y * 10) / 10, math.floor(p.z * 10) / 10,
            math.floor(v.x), math.floor(v.y), math.floor(v.z) })
    end
end

-- ---------------------------------------------------------------------
-- Spike NLOS seeker view: the operator sees through the missile and moves its aim point
-- ---------------------------------------------------------------------
function Missile.SeekerFrame(id, cam, dyaw, dpitch, fov)
    local M = own[id]
    if not M then return false end
    local fwd = U.norm(M.vel)
    if not M.seek then
        local p, y = U.rot(U.norm((M.tpos or (M.pos + fwd * 100.0)) - M.pos))
        M.seek = { pitch = p, yaw = y }
    end
    M.seek.pitch = U.clamp(M.seek.pitch + dpitch, -89.0, 60.0)
    M.seek.yaw = M.seek.yaw + dyaw
    -- seeker gimbal around the flight path (Spike: +-35 deg; the loitering munition looks down and around)
    local G = M.W.seeker or { az = 35.0, up = 35.0, down = -35.0 }
    local fp, fy = U.rot(fwd)
    local ry = U.clamp(U.wrap180(M.seek.yaw - fy), -G.az, G.az)
    local rp = U.clamp(M.seek.pitch - fp, G.down, G.up)
    M.seek.yaw, M.seek.pitch = fy + ry, U.clamp(fp + rp, -89.5, 89.5)
    local pos = M.pos + fwd * 1.2
    SetCamCoord(cam, pos.x, pos.y, pos.z)
    SetCamRot(cam, M.seek.pitch, 0.0, M.seek.yaw, 2)
    SetCamFov(cam, math.min(fov, 24.0))
    if C.Picture.MoveFocus then
        SetFocusPosAndVel(M.pos.x, M.pos.y, M.pos.z, M.vel.x, M.vel.y, M.vel.z)
        Pod.focusSet, Pod.worldMoved = true, true
        local vp = GetEntityCoords(PlayerPedId())
        RequestCollisionAtCoord(vp.x, vp.y, vp.z)
    end
    -- "update": where the seeker cross is, the missile goes (a vehicle under the cross is locked)
    -- the operator steers it himself: its mark is free again for another weapon
    if M.mark and (dyaw ~= 0.0 or dpitch ~= 0.0) then Pod.MarkDone(M.mark, false) M.mark = nil end
    if (dyaw ~= 0.0 or dpitch ~= 0.0 or not M.seekSet) and not M.mark then
        local hit, hp, he = U.sight(pos, U.dir(M.seek.pitch, M.seek.yaw), 9000.0, M.ent)
        if hit then
            M.seekSet = true
            if he and he ~= 0 and IsEntityAVehicle(he) then M.mode, M.tent, M.tpos = 'entity', he, GetEntityCoords(he)
            else M.mode, M.tent, M.tpos = 'point', nil, hp end
        end
    end
    Missile.seekInfo = { id = id, range = M.tpos and #(M.tpos - M.pos) or nil,
                         tof = (M.W.kind ~= 'loiter' or M.phase == 'strike') and M.tpos and GD.TimeToGo(M, M.tpos) or nil,
                         ph = M.W.kind == 'loiter' and (M.phase == 'strike' and 'STRIKE' or 'LOITER') or nil,
                         alt = M.pos.z - U.hmTop(M.pos.x, M.pos.y), short = M.W.short }
    return true
end

-- ---------------------------------------------------------------------
-- other players' missiles
-- ---------------------------------------------------------------------
RegisterNetEvent('js-atgm:remote', function(id, key, p)
    local W = C.Weapons[key]
    if not W or type(p) ~= 'table' then return end
    local R = remote[id]
    local pos, vel = vector3(p[1] + 0.0, p[2] + 0.0, p[3] + 0.0), vector3(p[4] + 0.0, p[5] + 0.0, p[6] + 0.0)
    if not R then
        R = { id = id, W = W, sid = 'r' .. id, pos = pos, vel = vel, at = GetGameTimer() }
        remote[id] = R                                   -- before loading the model (updates keep coming)
        count = count + 1
        dress(R, function() return remote[id] == R end)
    end
    R.pos, R.vel, R.at = pos, vel, GetGameTimer()
end)

-- the server gave up on one of our missiles (no reports for a long time, e.g. the game froze): it is gone
RegisterNetEvent('js-atgm:cancel', function(id)
    local M = own[tonumber(id) or -1]
    if not M then return end
    own[M.id] = nil
    count = count - 1
    remove(M)
    Pod.Message('m_lost', 'bad', 2.5)
end)

RegisterNetEvent('js-atgm:remoteEnd', function(id, p)
    local R = remote[id]
    if R then
        remote[id] = nil
        count = count - 1
        remove(R)
    end
    -- the blast effect for those who watched it come in (the game explosion alone is hard to see from far)
    if type(p) == 'table' and R then Missile.Blast(R.W, vector3(p.x or p[1], p.y or p[2], p.z or p[3])) end
end)

-- ---------------------------------------------------------------------
-- loop (only while something flies)
-- ---------------------------------------------------------------------
CreateThread(function()
    local last = GetGameTimer()
    local sndT = 0.0
    while true do
        if count <= 0 then
            count = 0
            Wait(250)
            last = GetGameTimer()
        else
            Wait(0)
            local now = GetGameTimer()
            -- real time passes even when a frame is slow: a long frame is flown in steps of at most 50 ms
            -- (up to 0.5 s; a longer freeze is not caught up), so weapons do not slow down with the frame rate
            local real = math.min((now - last) / 1000.0, 0.5)
            last = now
            local n = math.max(1, math.ceil(real / 0.05 - 1e-6))
            local dt = real / n
            for id, M in pairs(own) do
                for _ = 1, n do
                    if own[id] ~= M then break end
                    local ok, err = pcall(stepOwn, M, dt)
                    if not ok then
                        print(('^1[js-atgm] missile %s error: %s^7'):format(tostring(id), tostring(err)))
                        if own[id] then own[id] = nil count = count - 1 remove(M) TriggerServerEvent('js-atgm:done', id, nil) end
                        break
                    end
                end
            end
            for _, R in pairs(remote) do
                local age = math.min((now - R.at) / 1000.0, 0.4)
                local p = R.pos + R.vel * age
                if R.W.kind == 'lgb' or R.W.kind == 'gpsb' then p = p + vector3(0.0, 0.0, -4.9 * age * age) end
                place(R, p, R.vel)
                R.drawn = p
                if now - R.at > 4000 then remote[R.id] = nil count = count - 1 remove(R) end
            end
            -- motor sound from where we listen (10 Hz)
            sndT = sndT - dt
            if sndT <= 0.0 then
                sndT = 0.1
                local ear = GetFinalRenderedCamCoord()
                local camR = GetFinalRenderedCamRot(2)
                local function snd(o, p)
                    if GD.IsBomb(o.W) then return Hud.Sound(o.sid, nil) end
                    local d = #(p - ear)
                    local vol = math.max(0.0, 1.0 - d / 1400.0) ^ 2
                    local rel = U.wrap180(select(2, U.rot(U.norm(p - ear))) - camR.z)
                    Hud.Sound(o.sid, vol, U.clamp(-rel / 90.0, -1.0, 1.0))
                end
                for _, M in pairs(own) do snd(M, M.pos) end
                for _, R in pairs(remote) do if R.drawn then snd(R, R.drawn) end end
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, M in pairs(own) do remove(M) end
    for _, R in pairs(remote) do remove(R) end
end)
