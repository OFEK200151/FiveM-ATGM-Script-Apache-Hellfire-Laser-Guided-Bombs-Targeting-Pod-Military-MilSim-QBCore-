--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     The targeting pod (AH-64 TADS / LITENING style) and everything the operator does through it:
       gimbal camera with limits, WFOV..NFOV + zoom, DTV (gray) / IR (thermal), inertial stabilisation,
       point track (geo-stabilised) and vehicle track, laser rangefinder / designator with PRF codes,
       weapon selection, launch checks and release.
     Nothing runs every frame unless the pod is open; outside an armed aircraft one check every 750 ms. ]]
Pod = { on = false }
local S = Pod
local C = Config
local SENSORS = (C.Picture and C.Picture.Sensors) or { 'DTV', 'IR' }

-- ---------------------------------------------------------------------
-- where am I: an armed aircraft, in a weapons seat?
-- ---------------------------------------------------------------------
local platforms = {}
for name, P in pairs(C.Platforms) do platforms[joaat(name)] = { name = name, P = P } end

local function seatOk(veh, ped, P)
    for _, s in ipairs(P.seats or { -1 }) do
        if GetPedInVehicleSeat(veh, s) == ped then return true end
    end
    return false
end

--- platform, vehicle of the local player (nil when not in a weapons seat)
function Pod.Platform()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return nil end
    local p = platforms[GetEntityModel(veh)]
    if not p or not seatOk(veh, ped, p.P) then return nil end
    return p.P, veh, p.name
end

-- ---------------------------------------------------------------------
-- state
-- ---------------------------------------------------------------------
S.laser = { held = false, latched = false, code = C.Laser.DefaultCode, spot = nil, sent = 0, sentPos = nil, used = 0.0 }
S.profile = {}             -- weapon -> profile index
S.points = {}              -- stored coordinates (max 6)
S.marks = {}               -- marked targets: { n, pos, ent, w = weapon id flying to it, wshort, pend = request }
S.gps = nil                -- entered target coordinate (vector3)
S.msg = nil                -- { text, level, untilT }

function Pod.Message(key, level, secs)
    S.msg = { text = Lang(key), level = level or 'warn', untilT = GetGameTimer() + (secs or 2.0) * 1000 }
end

function Pod.Ammo()
    if not S.veh or not DoesEntityExist(S.veh) then return {} end
    local a = Entity(S.veh).state.atgm
    return type(a) == 'table' and a or (S.P and S.P.loadout or {})
end

function Pod.Weapon() return S.weapon and C.Weapons[S.weapon] or nil end
function Pod.ProfileName(w)
    local W = C.Weapons[w or S.weapon or '']
    if not W or not W.profiles then return nil end
    return W.profiles[S.profile[w or S.weapon] or 1]
end

-- ---------------------------------------------------------------------
-- open / close
-- ---------------------------------------------------------------------
local function mountPos()
    local m = S.P.mount
    if not m then
        -- under the nose: front of the model, below the centre line
        local mn, mx = GetModelDimensions(GetEntityModel(S.veh))
        m = vector3(0.0, mx.y * 0.82, mn.z * 0.55)
        S.P.mount = m
    end
    return GetOffsetFromEntityInWorldCoords(S.veh, m.x, m.y, m.z)
end
Pod.MountPos = function() return S.veh and mountPos() end

-- ---------------------------------------------------------------------
-- other HUDs: off while the pod is open, back when it closes
-- ---------------------------------------------------------------------
-- the game's first-person "push-in" screen effects (see Pod.Close)
local PUSH_FX = { 'CamPushInNeutral', 'CamPushInMichael', 'CamPushInFranklin', 'CamPushInTrevor' }
local hudWasRadar
local function otherHuds(open)
    local H = C.HideHud or {}
    if H.Game ~= false then
        if open then hudWasRadar = not IsRadarHidden() DisplayRadar(false)
        elseif hudWasRadar ~= nil then DisplayRadar(hudWasRadar) hudWasRadar = nil end
    end
    for res, R in pairs(H.Resources or {}) do
        if GetResourceState(res) == 'started' then
            if R.export then
                pcall(function() exports[res][R.export](exports[res], open) end)
            elseif R.event then
                TriggerEvent(R.event, open)
            end
        end
    end
    LocalPlayer.state:set('atgmPod', open, false)
    TriggerEvent('js-atgm:pod', open)
end
Pod.OtherHuds = otherHuds

local function applySensor()
    SetNightvision(false)
    SetSeethrough(false)
    ClearTimecycleModifier()
    local s = SENSORS[S.sensor]
    if s == 'DTV' then
        if C.Picture.Day ~= 'color' then                                -- real pod TV: black & white
            SetTimecycleModifier(C.Picture.GrayFilter or 'CAMERA_BW')
            SetTimecycleModifierStrength(C.Picture.GrayStrength or 1.0)
        elseif C.Picture.DayFilter then
            SetTimecycleModifier('heliGunCam')
            SetTimecycleModifierStrength(0.25)
        end
    elseif s == 'IR' then
        SetSeethrough(true)
    elseif s == 'NVS' then
        SetNightvision(true)
    end
end

function Pod.Open()
    if S.on then return end
    local P, veh = Pod.Platform()
    if not P then return end                       -- not in an armed aircraft: the key does nothing (other scripts may use it)
    if not U.jobOk() then return U.notify(Lang('n_no_job'), 'error') end
    S.P, S.veh, S.pdef = P, veh, C.Pods[P.pod] or C.Pods.tads
    S.weapons = U.weaponOrder(P.loadout or {})
    if not S.weapon or not P.loadout[S.weapon] then S.weapon = S.weapons[1] end
    S.fovI = S.fovI or 1
    S.fov = S.pdef.fov[S.fovI] or S.pdef.fov[1]
    if not S.sensor or S.sensor > #SENSORS then S.sensor = 1 end
    S.yaw, S.pitch = GetEntityRotation(veh, 2).z, S.P.pod == 'pod' and -35.0 or -12.0
    -- the point stays while you are in this aircraft: reopening the pod looks at it again
    if S.track and S.trackVeh == veh then
        if S.track.ent and not DoesEntityExist(S.track.ent) then S.track = { pos = S.track.pos } end
        S.pitch, S.yaw = U.rot(U.norm(S.track.pos - mountPos()))
    else
        S.track = nil
        if S.trackVeh ~= veh then
            local keep = {}
            for _, m in ipairs(S.marks) do if m.w then keep[#keep + 1] = m end end
            S.marks = keep
        end
    end
    S.trackVeh = veh
    S.seeker, S.gimbalT, S.lastSight, S.lar = nil, 0.0, nil, nil
    if S.oldCam then DestroyCam(S.oldCam, false) S.oldCam = nil end
    -- the pod camera starts where it will be; the game glides from your view into it
    S.cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    local m = mountPos()
    SetCamCoord(S.cam, m.x, m.y, m.z)
    SetCamRot(S.cam, S.pitch, 0.0, S.yaw, 2)
    SetCamFov(S.cam, S.fov)
    SetCamFarClip(S.cam, math.max(C.Picture.FarClip or 9000.0, (S.pdef.maxRange or 9000.0) + 1000.0))
    SetCamActive(S.cam, true)
    S.hdAt = nil
    local tin = (C.Transition and C.Transition.In) or 0
    RenderScriptCams(true, tin > 0, tin, true, true)
    local now = GetGameTimer()
    S.bootUntil = now + tin
    S.sensorAt = now + math.floor(tin * 0.75)        -- picture filter once the glide is nearly done
    S.sensorSet = false
    S.on = true
    otherHuds(true)
    TriggerServerEvent('js-atgm:hello')
    Hud.Show(true, tin)
end

--- still gliding into the pod (no firing yet)
function Pod.Booting() return S.on and GetGameTimer() < (S.bootUntil or 0) end

--- the world was loaded somewhere else (around the target): give it back to the player at once - collision
--- right under him and a quick load of the scene around him, so nobody stands in an empty, flat world
local recovering = false
local function restoreWorld()
    ClearFocus()
    S.focusSet = false
    if S.freeCam then NetworkSetInFreeCamMode(false) S.freeCam = false end
    if not S.worldMoved or recovering then return end
    S.worldMoved = false
    recovering = true
    CreateThread(function()
        local ped = PlayerPedId()
        local p = GetEntityCoords(ped)
        local started = NewLoadSceneStartSphere and NewLoadSceneStartSphere(p.x, p.y, p.z, 250.0, 0)
        local t0 = GetGameTimer()
        while GetGameTimer() - t0 < 8000 do
            p = GetEntityCoords(PlayerPedId())
            RequestCollisionAtCoord(p.x, p.y, p.z)
            if started and IsNewLoadSceneLoaded() and GetGameTimer() - t0 > 1000 then break end
            Wait(0)
        end
        if started then NewLoadSceneStop() end
        recovering = false
    end)
end
Pod.RestoreWorld = restoreWorld

function Pod.Close()
    if not S.on then return end
    S.on = false
    S.laser.held, S.laser.latched = false, false
    S.laser.range = nil
    if not (C.Laser.Auto and S.track and Missile.NeedsLaser(S.laser.code)) then S.laser.spot = nil end
    Pod.SendLaser(nil)                                    -- nobody else is lased for while the pod is closed
    -- glide back to your own view, then remove the pod camera.
    -- In the cockpit (first person) the game plays its own "push-in" flash / blur when a script camera hands
    -- back to the first-person view (the story-mode switch look): there the hand-back is instant and that
    -- effect is stopped for the next frames.
    local fp = GetFollowVehicleCamViewMode() == 4
    local tout = fp and 0 or ((C.Transition and C.Transition.Out) or 0)
    RenderScriptCams(false, tout > 0, tout, true, true)
    if fp then
        CreateThread(function()
            local stopAt = GetGameTimer() + 1500
            while GetGameTimer() < stopAt and not S.on do
                for i = 1, #PUSH_FX do
                    if AnimpostfxIsRunning(PUSH_FX[i]) then AnimpostfxStop(PUSH_FX[i]) end
                end
                Wait(0)
            end
        end)
    end
    if S.cam then
        local cam = S.cam
        S.cam, S.oldCam = nil, cam
        SetTimeout(tout + 100, function()
            if S.oldCam == cam then DestroyCam(cam, false) S.oldCam = nil end
        end)
    end
    SetNightvision(false)
    SetSeethrough(false)
    ClearTimecycleModifier()
    if S.focusSet or S.worldMoved or S.freeCam then restoreWorld() end
    S.close = false
    Contacts.Look(nil, 0, Pod.NeededIds())
    Contacts.Proxies(false)
    if S.hdAt then ClearHdArea() end
    S.hdAt = nil
    S.seeker = nil                                     -- the point (S.track) stays
    Hud.CloseDialog()                                  -- never leave the mouse captured by an open dialog
    Hud.Show(false)
    otherHuds(false)
end

-- ---------------------------------------------------------------------
-- laser: shared with everyone (by code) through the server
-- ---------------------------------------------------------------------
function Pod.SendLaser(spot)
    local now = GetGameTimer()
    if not spot then
        if S.laser.sentPos then TriggerServerEvent('js-atgm:laser', false) S.laser.sentPos = nil end
        return
    end
    local moved = not S.laser.sentPos or #(spot - S.laser.sentPos) > 0.75
    if now - S.laser.sent >= C.Laser.Publish * 1000 and (moved or now - S.laser.sent > 1000) then
        S.laser.sent, S.laser.sentPos = now, spot
        TriggerServerEvent('js-atgm:laser', { spot.x, spot.y, spot.z, S.laser.code })
    end
end

-- other players' lasers: the server sends them only to players in the same routing bucket, and only while
-- someone lases on purpose; a spot not refreshed for 2.5 s is gone (left the bucket, crashed, ...)
local others = {}          -- server id -> { pos, code, t }
RegisterNetEvent('js-atgm:laser', function(src, l)
    src = tonumber(src)
    if not src then return end
    if type(l) ~= 'table' then others[src] = nil return end
    local x, y, z, c = tonumber(l[1]), tonumber(l[2]), tonumber(l[3]), tonumber(l[4])
    if not (x and y and z and c) then return end
    others[src] = { pos = vector3(x, y, z), code = c, t = GetGameTimer() }
end)

--- laser spots with a code: own spot first (no network delay), then everyone else's
function Pod.LaserSpots(code)
    local out = {}
    if S.laser.spot and S.laser.code == code then out[#out + 1] = S.laser.spot end
    local now = GetGameTimer()
    for src, l in pairs(others) do
        if now - l.t > 2500 then others[src] = nil
        elseif l.code == code then out[#out + 1] = l.pos end
    end
    return out
end

--- the spot of this code nearest to a point (nil = nobody lases with this code)
function Pod.NearestSpot(code, near)
    local best, bd
    for _, p in ipairs(Pod.LaserSpots(code)) do
        local d = near and #(p - near) or 0.0
        if not bd or d < bd then best, bd = p, d end
    end
    return best
end

-- ---------------------------------------------------------------------
-- the target the selected weapon would go to
-- ---------------------------------------------------------------------
--- @return spec { mode = 'laser'|'point'|'entity', pos, ent, code, loal } or nil, reason
function Pod.TargetFor(w, mark)
    local W = C.Weapons[w]
    local aim = S.aim
    if mark then
        -- a marked target: the weapon is given that target and goes there by itself (the pod is free)
        return { mode = (mark.ent or mark.cid) and 'entity' or 'point', pos = mark.pos, ent = mark.ent, cid = mark.cid, mark = mark, code = S.laser.code }
    end
    if W.kind == 'sal' or W.kind == 'lgb' then
        local spot = Pod.NearestSpot(S.laser.code, aim and aim.pos)
        if spot then return { mode = 'laser', pos = spot, code = S.laser.code } end
        if W.kind == 'lgb' or W.loal then
            if not (aim and aim.hit) then return nil, 'm_no_target' end
            return { mode = 'laser', pos = S.track and S.track.pos or aim.pos, code = S.laser.code, loal = true }
        end
        return nil, 'm_no_laser'
    elseif W.kind == 'fou' or W.kind == 'loiter' then
        if S.track and (S.track.ent or S.track.cid) then return { mode = 'entity', ent = S.track.ent, cid = S.track.cid, pos = S.track.pos } end
        if S.track then return { mode = 'point', pos = S.track.pos } end
        if aim and aim.hit then return { mode = 'point', pos = aim.pos } end
        return nil, 'm_no_target'
    else -- gps / gpsb
        if S.gps then return { mode = 'point', pos = S.gps, coords = true } end
        if S.track then return { mode = 'point', pos = S.track.pos } end
        if aim and aim.hit then return { mode = 'point', pos = aim.pos } end
        return nil, 'm_no_target'
    end
end

--- release envelope of a bomb (what the pilot's display shows): the bomb's whole fall is simulated from
--- here, now; only a release that reaches the point is allowed. Worked out 2x a second (~300 light steps).
local function bombReaches(W, spec)
    local now = GetGameTimer()
    local key = S.weapon
    if S.lar and S.lar.key == key and now - S.lar.t < 500 and #(S.lar.tp - spec.pos) < 5.0 then return S.lar.ok end
    local M = { W = W, pos = Missile.LaunchPoint(S.veh, W), vel = GetEntityVelocity(S.veh) + vector3(0.0, 0.0, -3.0), t = 0.0 }
    local tp, ok = spec.pos, false
    for _ = 1, 3000 do
        -- coarse steps for most of the fall, fine steps in the last seconds (the end decides the miss)
        local h = M.pos.z - tp.z
        local dt = (h < math.max(80.0, -M.vel.z * 4.0)) and 0.02 or 0.25
        GD.Step(M, dt, tp, nil)
        if M.pos.z <= tp.z + 1.0 then
            local dx, dy = M.pos.x - tp.x, M.pos.y - tp.y
            ok = math.sqrt(dx * dx + dy * dy) < 25.0
            break
        end
    end
    S.lar = { key = key, t = now, tp = tp, ok = ok }
    return ok
end

--- every launch condition; returns spec or nil, message key
function Pod.CanFire(mark)
    local W = Pod.Weapon()
    if not W then return nil, 'm_no_weapon' end
    if (Pod.Ammo()[S.weapon] or 0) <= 0 then return nil, 'm_empty' end
    if mark == nil then mark = Pod.NextMark() end
    if mark and W.kind == 'loiter' then mark = nil end              -- a loitering munition circles the pod point
    local spec, why = Pod.TargetFor(S.weapon, mark or nil)
    if not spec then return nil, why end
    local vp = GetEntityCoords(S.veh)
    local d = #(spec.pos - vp)
    local R = C.Rules or {}
    if R.MinRange ~= false and W.minRange and d < W.minRange then return nil, 'm_range_min' end
    if W.maxRange and d > W.maxRange then return nil, 'm_range_max' end
    local bomb = W.kind == 'lgb' or W.kind == 'gpsb'
    if bomb then
        if (W.minAlt or 0.0) > 0.0 and vp.z - U.groundZ(vp.x, vp.y) < W.minAlt then return nil, 'm_alt' end
        local mode = R.ReleaseEnvelope or 'block'
        if mode ~= 'off' and mode ~= false and not bombReaches(W, spec) then
            if mode == 'block' then return nil, 'm_reach' end
            spec.warn = 'm_reach_warn'                    -- released anyway; the HUD says it may fall short
        end
    elseif R.OffAxis and (W.offAxis or 180.0) < 180.0 then
        local f = U.flat(GetEntityForwardVector(S.veh))
        local to = U.flat(spec.pos - vp)
        local ang = math.deg(math.acos(U.clamp(U.dot(U.norm(f), U.norm(to)), -1.0, 1.0)))
        if ang > W.offAxis then return nil, 'm_off_axis' end
    end
    return spec
end

-- the launch waits for the server (ammo is server side). Every request has its own id, so a late or lost
-- answer can never start the wrong weapon; one request at a time (the server allows 1 launch a second anyway).
local requests = {}        -- request id -> { t, spec }
local reqId = 0
local WAIT_MS, LATE_MS, KEEP_MS = 1500, 3000, 15000

local function waiting()
    local now = GetGameTimer()
    for rid, r in pairs(requests) do
        if now - r.t > KEEP_MS then requests[rid] = nil
        elseif now - r.t < WAIT_MS then return true end
    end
    return false
end

--- one release: at the next marked target (if there are marks), else at the pod point
local function fireOne(mark)
    local spec, why = Pod.CanFire(mark)
    if not spec then Pod.Message(why, 'bad') return false end
    if waiting() then return false end
    local W = Pod.Weapon()
    spec.profile = Pod.ProfileName() or 'direct'
    spec.weapon = S.weapon
    spec.veh = S.veh
    reqId = reqId + 1
    requests[reqId] = { t = GetGameTimer(), spec = spec }
    if spec.mark then spec.mark.pend = reqId end
    local from = Missile.LaunchPoint(S.veh, W)
    local tp = spec.pos
    TriggerServerEvent('js-atgm:launch', { rid = reqId, w = S.weapon, pos = { x = from.x, y = from.y, z = from.z }, tgt = { x = tp.x, y = tp.y, z = tp.z } })
    return true
end

local rippling = false
function Pod.Fire()
    if not S.on or S.seeker or Pod.Booting() or rippling then return end
    local T = C.Targets or {}
    local W = Pod.Weapon()
    local first = Pod.NextMark()
    if not first or not T.Ripple or (W and W.kind == 'loiter') then
        fireOne(nil)
        return
    end
    -- ripple: one weapon on every marked target that has none yet, one after the other
    rippling = true
    CreateThread(function()
        local n = 0
        while S.on and not S.seeker do
            local m = Pod.NextMark()
            if not m then break end
            local t0 = GetGameTimer()
            while waiting() and GetGameTimer() - t0 < 3000 do Wait(50) end
            if not fireOne(m) then break end
            n = n + 1
            -- wait for the answer (or give up on it), then the release interval
            local t1 = GetGameTimer()
            while m.pend and GetGameTimer() - t1 < 3000 do Wait(50) end
            if not m.w then break end
            Wait(math.floor((T.Interval or 0.6) * 1000))
        end
        rippling = false
        if n > 1 then Pod.Message('m_ripple', 'good', 2.0) end
    end)
end

-- ---------------------------------------------------------------------
-- marked targets (several targets, one weapon each - like a jet's pre-planned targets)
-- ---------------------------------------------------------------------
local function markHere()
    local p = (S.track and S.track.pos) or (S.aim and S.aim.hit and S.aim.pos)
    if not p then return nil end
    local ent, cid = S.track and S.track.ent or nil, S.track and S.track.cid or nil
    if not ent and not cid then
        -- a vehicle / person right under the point (or a far contact): the mark rides with it
        ent, cid = Pod.TargetAt(p)
    end
    return p, ent, cid
end

--- the next marked target that has no weapon going to it yet (lowest number first)
function Pod.NextMark()
    local best
    for _, m in ipairs(S.marks) do
        if not m.w and not m.pend and (not best or m.n < best.n) then best = m end
    end
    return best
end

function Pod.Mark()
    if not S.on or S.seeker then return end
    local p, ent, cid = markHere()
    if not p then return Pod.Message('m_no_target', 'bad') end
    local T = C.Targets or {}
    -- on an existing mark (no weapon going there): take it off
    for i, m in ipairs(S.marks) do
        if not m.w and not m.pend and (#(m.pos - p) < (T.Pick or 20.0) or (ent and m.ent == ent) or (cid and m.cid == cid)) then
            table.remove(S.marks, i)
            S.msg = { text = Lang('m_unmarked', m.n), level = 'warn', untilT = GetGameTimer() + 1500 }
            return
        end
    end
    if #S.marks >= (T.Max or 8) then return Pod.Message('m_marks_full', 'bad') end
    local used = {}
    for _, m in ipairs(S.marks) do used[m.n] = true end
    local n = 1
    while used[n] do n = n + 1 end
    S.marks[#S.marks + 1] = { n = n, pos = Pod.ThingPos(ent, cid) or p, ent = ent, cid = cid }
    table.sort(S.marks, function(a, b) return a.n < b.n end)
    S.msg = { text = Lang('m_marked', n), level = 'good', untilT = GetGameTimer() + 1500 }
end

--- look at the next marked target (the pod point jumps there)
function Pod.CycleMark()
    if not S.on or S.seeker or #S.marks == 0 then return end
    local cur = S.cycleN or 0
    local pick = S.marks[1]
    for _, m in ipairs(S.marks) do if m.n > cur then pick = m break end end
    S.cycleN = pick.n
    S.track = { pos = pick.pos, ent = (pick.ent and DoesEntityExist(pick.ent)) and pick.ent or nil, cid = pick.cid }
    S.lastSight = nil
    S.msg = { text = ('T%d'):format(pick.n), level = 'good', untilT = GetGameTimer() + 1000 }
end

--- clear the marks that have no weapon going to them
function Pod.ClearMarks()
    local keep = {}
    for _, m in ipairs(S.marks) do if m.w or m.pend then keep[#keep + 1] = m end end
    local n = #S.marks - #keep
    S.marks = keep
    if n > 0 then Pod.Message('m_marks_clear', 'warn', 1.5) end
end

--- a weapon flying to a mark is gone: hit -> the mark is done, else the target is free again
function Pod.MarkDone(mark, hit)
    for i, m in ipairs(S.marks) do
        if m == mark then
            if hit and (C.Targets or {}).ClearOnHit ~= false then table.remove(S.marks, i)
            else m.w, m.wshort = nil, nil end
            return
        end
    end
end

local function updateMarks()
    for _, m in ipairs(S.marks) do
        if m.ent or m.cid then
            local p, e = Pod.ThingPos(m.ent, m.cid)
            if p then m.pos, m.ent = p, e else m.ent = nil end
        end
    end
end

--- contacts that must keep coming from the server: locked, marked, or a weapon flies to them
function Pod.NeededIds()
    local ids, seen = {}, {}
    local function add(k) if k and not seen[k] and #ids < 10 then seen[k] = true ids[#ids + 1] = k end end
    if S.track then add(S.track.cid) end
    for _, m in ipairs(S.marks) do add(m.cid) end
    for _, k in ipairs(Missile.Cids()) do add(k) end
    return ids
end
Pod.UpdateMarks = updateMarks

RegisterNetEvent('js-atgm:launchOk', function(id, w, left, rid)
    local r = requests[tonumber(rid) or -1]
    requests[tonumber(rid) or -1] = nil
    -- an answer that comes too late (the operator already sees "no answer") or to a request we do not have:
    -- the server counted a launch, so it is ended at once instead of flying from a stale position
    if r and GetGameTimer() - r.t > LATE_MS then r = nil Pod.Message('m_late', 'bad', 2.0) end
    if r and r.spec.mark then r.spec.mark.pend = nil end
    if not r or r.spec.weapon ~= w or not DoesEntityExist(r.spec.veh) then
        return TriggerServerEvent('js-atgm:done', id, nil)
    end
    if r.spec.mark then r.spec.mark.w, r.spec.mark.wshort = id, C.Weapons[w].short end
    Missile.Start(id, w, r.spec)
    local W = C.Weapons[w]
    Pod.Message((W.kind == 'lgb' or W.kind == 'gpsb') and 'm_release' or (r.spec.loal and 'm_loal' or 'm_launch'), 'good', 2.0)
end)

RegisterNetEvent('js-atgm:launchNo', function(why, rid)
    rid = tonumber(rid)
    if rid then
        if not requests[rid] then return end           -- an answer to a request that is already forgotten
        if requests[rid].spec.mark then requests[rid].spec.mark.pend = nil end
        requests[rid] = nil
    end
    Pod.Message(({ empty = 'm_empty', rate = 'm_rate', busy = 'm_busy', range = 'm_range_max', job = 'm_no_weapon',
                   seat = 'm_no_weapon' })[why] or 'm_no_weapon', 'bad')
end)

-- ---------------------------------------------------------------------
-- tracking
-- ---------------------------------------------------------------------
--- the point: a fixed spot on the ground in the middle of the picture. It only moves when you move it.
--- Space locks it onto the vehicle it is on (it then rides with the vehicle); Space again leaves it there.
--- what is under the point: a vehicle, a person (player or not), or a far contact the game does not have
--- @return entity or nil, contact key or nil
local function targetAt(p)
    local aim = S.aim
    -- a stand-in is not the target itself: the far contact it shows is
    local function pick(e) local k = Contacts.KeyOf(e) if k then return nil, k end return e, nil end
    if aim and aim.ent and aim.ent ~= 0 and aim.ent ~= S.veh and (IsEntityAVehicle(aim.ent) or IsEntityAPed(aim.ent)) then
        return pick(aim.ent)
    end
    local best, bd = nil, 6.0
    for _, v in ipairs(GetGamePool('CVehicle')) do
        if v ~= S.veh then
            local d = #(GetEntityCoords(v) - p)
            if d < bd then best, bd = v, d end
        end
    end
    if best then return pick(best) end
    local me = PlayerPedId()
    bd = 3.0
    for _, ped in ipairs(GetGamePool('CPed')) do
        if ped ~= me and not IsPedInAnyVehicle(ped, false) then
            local d = #(GetEntityCoords(ped) - p)
            if d < bd then best, bd = ped, d end
        end
    end
    if best then return pick(best) end
    return nil, Contacts.Near(p, 9.0)
end
Pod.TargetAt = targetAt

--- the position of a locked / marked thing (entity, else far contact), nil if it is gone
local function thingPos(ent, cid)
    if ent and DoesEntityExist(ent) then
        return GetEntityCoords(ent) + vector3(0.0, 0.0, IsEntityAPed(ent) and 0.2 or 0.4), ent
    end
    if cid then
        local p, _, e = Contacts.Pos(cid)
        return p, e
    end
    return nil, nil
end
Pod.ThingPos = thingPos

--- reset: the point is dropped, the camera goes back to straight ahead and a new point is put where it looks
function Pod.Reset()
    if not S.on or S.seeker then return end
    S.track = nil
    S.yaw, S.pitch = GetEntityRotation(S.veh, 2).z, S.P.pod == 'pod' and -35.0 or -12.0
    S.gimbalT, S.lastSight, S.snapT, S.holdT = 0.0, nil, 0.0, 0.0
    Pod.Message('m_reset', 'good', 1.5)
end

function Pod.Track()
    if not S.on then return end
    if S.track and (S.track.ent or S.track.cid) then
        S.track = { pos = S.track.pos }                   -- unlock: the point stays where the target was
        return
    end
    local p = (S.track and S.track.pos) or (S.aim and S.aim.hit and S.aim.pos)
    if not p then return Pod.Message('m_no_target', 'bad') end
    local e, cid = targetAt(p)
    if not e and not cid then return Pod.Message('m_no_vehicle', 'warn') end
    local tp = thingPos(e, cid) or p
    S.track = { ent = e, cid = cid, pos = tp }
end

-- ---------------------------------------------------------------------
-- per frame
-- ---------------------------------------------------------------------
local BLOCK = { 0, 26, 79, 80, 1, 2, 14, 15, 16, 17, 24, 25, 37, 44, 45, 68, 69, 70, 91, 92, 99, 100, 106, 114, 115, 140, 141, 142, 143, 257, 263, 264, 330, 331, 241, 242, 81, 82, 85, 172, 173, 174, 175 }

local function input(dt)
    for i = 1, #BLOCK do DisableControlAction(0, BLOCK[i], true) end
    HideHudComponentThisFrame(14)              -- reticle
    if (C.HideHud or {}).Game ~= false then HideHudAndRadarThisFrame() end
    -- slew rate scales with the field of view: the same key press crosses the same part of the picture
    local k = (S.pdef.slew or 1.0) * S.fov
    local A = C.Aim or {}
    local mx, my = 0.0, 0.0
    if A.Mouse then mx, my = GetDisabledControlNormal(0, 1), GetDisabledControlNormal(0, 2) end
    local ax, ay = 0.0, 0.0
    if A.Arrows ~= false then
        if IsDisabledControlPressed(0, 174) then ax = ax - 1.0 end      -- left
        if IsDisabledControlPressed(0, 175) then ax = ax + 1.0 end      -- right
        if IsDisabledControlPressed(0, 172) then ay = ay - 1.0 end      -- up
        if IsDisabledControlPressed(0, 173) then ay = ay + 1.0 end      -- down
    end
    -- arrows: slow and precise when you tap, faster the longer you hold
    if ax ~= 0.0 or ay ~= 0.0 then S.holdT = (S.holdT or 0.0) + dt else S.holdT = 0.0 end
    local slow, fast = A.Speed or 0.25, A.Fast or 1.0
    local rate = slow + (fast - slow) * U.clamp((S.holdT - 0.25) / 1.25, 0.0, 1.0)
    local dyaw = -(mx * 0.6 + ax * dt * rate) * k
    local dpitch = -(my * 0.6 + ay * dt * rate) * k
    -- zoom: wheel = continuous, Z = next field of view
    local f = S.fov
    if IsDisabledControlJustPressed(0, 241) then f = f / 1.25 end
    if IsDisabledControlJustPressed(0, 242) then f = f * 1.25 end
    local fl = S.pdef.fov
    S.fov = U.clamp(f, fl[#fl], fl[1])
    return dyaw, dpitch
end

local function gimbal(pitch, yaw)
    local vr = GetEntityRotation(S.veh, 2)
    local rel = U.wrap180(yaw - vr.z)
    local relP = pitch - vr.x
    -- a pod that looks down past the vertical (LITENING: to -155) sees behind and below the aircraft:
    -- "azimuth 180, elevation -40" is the same look as "azimuth 0, elevation -140"
    if math.abs(rel) > S.pdef.az and S.pdef.elDown < -90.0 then
        local rel2, relP2 = U.wrap180(rel + 180.0), -180.0 - relP
        if math.abs(rel2) <= S.pdef.az and relP2 >= S.pdef.elDown then return pitch, yaw, false, rel2, relP2 end
    end
    local cRel = U.clamp(rel, -S.pdef.az, S.pdef.az)
    local cP = U.clamp(relP, S.pdef.elDown, S.pdef.elUp)
    local limited = cRel ~= rel or cP ~= relP
    return cP + vr.x, U.wrap180(cRel + vr.z), limited, cRel, cP
end

local laserTime = 0.0
local function frame(dt)
    local ped = PlayerPedId()
    if not DoesEntityExist(S.veh) or GetVehiclePedIsIn(ped, false) ~= S.veh or not seatOk(S.veh, ped, S.P) or IsEntityDead(ped)
        or IsEntityDead(S.veh) or IsVehicleDriveable(S.veh, false) == false then
        return Pod.Close()                                 -- (a wrecked aircraft has no pod)
    end
    local dyaw, dpitch = input(dt)
    local cam = mountPos()
    -- far detail: GTA picks detail by distance, not by zoom; at 2 deg field of view a building 3 km away
    -- fills the screen, so the detail distance is scaled up with the zoom (with the close-up picture the camera
    -- is near the target anyway: no boost needed, lighter on the PC)
    local lod = S.close and 1.25 or math.min(C.Picture.LodMax, C.Picture.LodBoost * math.max(1.0, S.pdef.fov[1] / S.fov))
    OverrideLodscaleThisFrame(lod)

    -- seeker view (Spike NLOS): the picture comes from the missile, the pod waits
    if S.seeker then
        local ok = Missile.SeekerFrame(S.seeker, S.cam, dyaw, dpitch, S.fov)
        if not ok then S.seeker = nil end
        Hud.Frame(dt)
        return
    end

    updateMarks()
    -- where the camera looks: the track, or the operator's slew (inertially stabilised: world angles)
    if S.track and (S.track.ent or S.track.cid) then
        -- a locked target: the real one while the game has it, else the far contact from the server
        local tp, e = thingPos(S.track.ent, S.track.cid)
        if tp then
            S.track.pos, S.track.ent = tp, e
        else
            S.track = { pos = S.track.pos }
            Pod.Message('m_track_point', 'warn', 2.5)
        end
    end
    if S.track and (S.track.ent or S.track.cid) and (math.abs(dyaw) + math.abs(dpitch)) > S.fov * 0.25 then
        S.track = { pos = S.track.pos }                   -- a big move takes the point off the target
    end
    if S.track and (dyaw ~= 0.0 or dpitch ~= 0.0) and not S.track.ent and not S.track.cid then
        -- moving the mouse moves the point over the ground (the camera follows it)
        local np, ny = U.rot(U.norm(S.track.pos - cam))
        local d = U.dir(np + dpitch, ny + dyaw)
        local hit, p = U.sight(cam, d, S.pdef.maxRange, S.veh)
        if hit then S.track.pos = p end
    end
    local pitch, yaw
    if S.track then
        pitch, yaw = U.rot(U.norm(S.track.pos - cam))
    else
        pitch, yaw = S.pitch + dpitch, S.yaw + dyaw
    end
    local limited, relAz, relEl
    pitch, yaw, limited, relAz, relEl = gimbal(U.clamp(pitch, -89.5, 89.5), yaw)
    S.pitch, S.yaw, S.relAz, S.relEl = pitch, yaw, relAz, relEl
    if limited then
        S.gimbalT = S.gimbalT + dt
        Pod.Message('m_gimbal', 'warn', 0.3)
        -- the point stayed out of the pod's reach: a new one is put where the camera can look - but never while
        -- an own weapon is in the air (it would be sent somewhere else); then the laser is just masked
        if S.track and S.gimbalT > 1.5 and not Missile.Busy() then S.track = nil S.gimbalT = 0.0 Pod.Message('m_track_lost', 'bad') end
    else
        S.gimbalT = 0.0
    end
    -- line of sight: what the cross is on
    local dir = U.dir(pitch, yaw)

    -- far away: the picture is taken from a point ON the line of sight, closer to the target, with a wider lens
    -- that shows exactly the same part of the ground. The game then loads and draws the target area in full
    -- detail (buildings, props, people) and the network sends the players there - like a real pod's optics.
    -- The camera glides (never jumps) between its places: its offset from the point is smoothed, and the lens
    -- always shows the same width of ground at the point - so zooming / moving the point looks like the optics
    -- working, not like a camera flying around.
    local Pp = C.Picture
    local point = S.track and S.track.pos or nil
    local R = point and #(point - cam) or nil
    local want, close = nil, false                    -- wanted camera offset from the point
    if (Pp.CloseUp or 0) > 0 and R and R > Pp.CloseUp + 50.0 and not limited then
        local half = math.tan(math.rad(S.fov * 0.5))
        local D = math.max(Pp.CloseUp, R * half / math.tan(math.rad((Pp.CloseFov or 70.0) * 0.5)))
        if D < R - 40.0 then
            want, close = -dir * D, true
            S.closeD = D
        end
    end
    local rpos, rfov = cam, S.fov
    if point and (close or S.camOff) then
        local target = want or (cam - point)
        local k = math.min(1.0, dt * (Pp.Glide or 5.0))
        S.camOff = S.camOff and (S.camOff + (target - S.camOff) * k) or target
        if not close and #(S.camOff - target) < 2.0 then
            S.camOff = nil                             -- back on the pod: exactly there (never behind the aircraft)
        else
            rpos = point + S.camOff
            local width = R * math.tan(math.rad(S.fov * 0.5))
            rfov = U.clamp(math.deg(2.0 * math.atan(width / math.max(#S.camOff, 1.0))), 0.5, 100.0)
        end
    else
        S.camOff = nil
    end
    S.close = close
    SetCamCoord(S.cam, rpos.x, rpos.y, rpos.z)
    if rpos ~= cam and point then
        local cp, cy = U.rot(U.norm(point - rpos))
        SetCamRot(S.cam, cp, 0.0, cy, 2)
    else
        SetCamRot(S.cam, pitch, 0.0, yaw, 2)
    end
    SetCamFov(S.cam, rfov)
    -- the network sends us the players around the camera too (only when it is near the target: zoomed in)
    local nf = Pp.NetworkFocus ~= false and close and (S.closeD or 1e9) <= 450.0
    if nf ~= (S.freeCam == true) then
        S.freeCam = nf
        NetworkSetInFreeCamMode(nf)
    end
    -- what is under the cross: every frame while there is no point / it is being moved, else 5x a second
    local hit, pos, ent
    S.sightT = (S.sightT or 0.0) - dt
    if not S.track or dyaw ~= 0.0 or dpitch ~= 0.0 or S.sightT <= 0.0 or not S.lastSight then
        S.sightT = 0.2
        hit, pos, ent = U.sight(cam, dir, S.pdef.maxRange, S.veh)
        S.lastSight = { hit, pos, ent }
    else
        hit, pos, ent = S.lastSight[1], S.lastSight[2], S.lastSight[3]
    end
    -- no point yet (just opened, or it was lost): it is put where the camera looks
    if not S.track and hit then S.track = { pos = pos } end
    -- a far point first sits on the rough height map; once the ground there is loaded it drops onto it
    S.snapT = (S.snapT or 0.0) - dt
    if S.track and not S.track.ent and not S.track.cid and S.snapT <= 0.0 then
        S.snapT = 0.5
        local p = S.track.pos
        local h, g = U.ray(p + vector3(0.0, 0.0, 40.0), p - vector3(0.0, 0.0, 60.0), S.veh, 1 + 16)
        if h and math.abs(g.z - p.z) > 0.3 then S.track.pos = vector3(p.x, p.y, g.z) end
    end
    if S.track then pos, hit = S.track.pos, true end
    S.aim = { hit = hit, pos = pos, ent = ent, range = hit and #(pos - cam) or nil, cam = cam, dir = dir }
    -- far contacts around what the picture shows (beyond what the game streams to us)
    if hit and S.aim.range > 300.0 then
        Contacts.Look(pos, S.aim.range * math.tan(math.rad(S.fov * 0.5)) * 1.9, Pod.NeededIds())
    else
        Contacts.Look(nil, 0, Pod.NeededIds())
    end
    Contacts.Proxies(true)

    -- the picture filter comes on at the end of the glide into the pod
    if not S.sensorSet and GetGameTimer() >= (S.sensorAt or 0) then S.sensorSet = true applySensor() end

    -- laser: by hand (hold / latch), or by itself on a marked point and while an own laser weapon flies
    local L = S.laser
    local auto = C.Laser.Auto and (S.track ~= nil or Missile.NeedsLaser(L.code))
    -- the laser cannot fire where the pod cannot look (gimbal limit = masked)
    local lasing = (L.held or L.latched or auto) and hit and not limited
    if lasing and C.Laser.Battery > 0 then
        laserTime = laserTime + dt
        if laserTime > C.Laser.Battery then lasing = false Pod.Message('m_laser_batt', 'bad', 0.5) end
    elseif not (L.held or L.latched) then
        laserTime = math.max(0.0, laserTime - dt * 0.5)
    end
    L.spot = lasing and pos or nil
    L.range = lasing and #(pos - cam) or nil
    -- shared with other players only when you lase on purpose (hold / L): the automatic laser is read by
    -- your own weapons directly, so it costs no network traffic at all
    Pod.SendLaser((L.held or L.latched) and L.spot or nil)

    -- load the world around the point instead of around you (always with the close-up picture; 'auto': in the
    -- air only). The ground under your own aircraft is kept solid.
    local mf = C.Picture.MoveFocus
    local agl = GetEntityHeightAboveGround(S.veh) or 0.0
    local vz = (GetEntityVelocity(S.veh) or vector3(0.0, 0.0, 0.0)).z
    local airborne = mf == true or (mf == 'auto' and (agl > 15.0 or (GetEntitySpeed(S.veh) or 0.0) > 8.0))
    -- low and falling fast, or badly damaged: the world stays around YOU (you are about to need it)
    local danger = (agl < 150.0 and vz < -12.0) or (GetVehicleEngineHealth(S.veh) or 1000.0) < 300.0
    if (mf ~= false) and (S.close or airborne) and not danger and hit and #(pos - cam) > 250.0 then
        SetFocusPosAndVel(pos.x, pos.y, pos.z, 0.0, 0.0, 0.0)
        S.focusSet, S.worldMoved = true, true
        local vp = GetEntityCoords(S.veh)
        RequestCollisionAtCoord(vp.x, vp.y, vp.z)        -- the ground under our own aircraft stays solid
    elseif S.focusSet then
        restoreWorld()
    end
    if (C.Picture.HdRadius or 0) > 0 and hit and (not S.hdAt or #(S.hdAt - pos) > C.Picture.HdRadius * 0.4) then
        S.hdAt = pos
        SetHdArea(pos.x, pos.y, pos.z, C.Picture.HdRadius)
    end
    Hud.Frame(dt)
end

CreateThread(function()
    local last = GetGameTimer()
    local hinted = nil
    while true do
        if S.on then
            Wait(0)
            local now = GetGameTimer()
            local dt = math.min((now - last) / 1000.0, 0.1)
            last = now
            local ok, err = pcall(frame, dt)
            if not ok and now - (S.errT or 0) > 5000 then
                S.errT = now
                print('^1[js-atgm] pod error: ' .. tostring(err) .. '^7')
            end
        else
            -- idle: wake quickly when the pod opens; look for an armed aircraft every 750 ms
            local t0 = GetGameTimer()
            while not S.on and GetGameTimer() - t0 < 750 do
                Wait(100)
                if not S.on then
                    Pod.Background()
                    -- safety: whatever closed the pod (crash, death, another script), the world comes back to you
                    if (S.focusSet or S.worldMoved or S.freeCam) and not S.seeker then restoreWorld() end
                end
            end
            last = GetGameTimer()
            if not S.on then
                -- in an armed aircraft: say once which key opens the pod
                local P, veh = Pod.Platform()
                if P and hinted ~= veh then
                    hinted = veh
                    U.notify(('[%s] %s - %s'):format(C.Keys.pod, (C.Pods[P.pod] or {}).label or 'POD', P.label or ''), 'primary')
                elseif not P then
                    hinted = nil
                end
            end
        end
    end
end)

-- ---------------------------------------------------------------------
-- keys
-- ---------------------------------------------------------------------
local function key(name, label, def, down, up)
    RegisterCommand('+atgm_' .. name, function() if down then down() end end, false)
    RegisterCommand('-atgm_' .. name, function() if up then up() end end, false)
    RegisterKeyMapping('+atgm_' .. name, 'ATGM: ' .. label, def:match('^MOUSE_') and 'MOUSE_BUTTON' or 'keyboard', def)
end

key('pod', Lang('k_pod'), C.Keys.pod, function() if S.on then Pod.Close() else Pod.Open() end end)
key('fire', Lang('k_fire'), C.Keys.fire, function() if S.on then Pod.Fire() end end)
key('laser', Lang('k_laser'), C.Keys.laser, function() if S.on then S.laser.held = true end end, function() S.laser.held = false end)
key('laseron', Lang('k_laseron'), C.Keys.laserOn, function() if S.on then S.laser.latched = not S.laser.latched end end)
key('track', Lang('k_track'), C.Keys.track, function() if S.on and not S.seeker then Pod.Track() end end)
key('reset', Lang('k_reset'), C.Keys.reset or 'R', function() if S.on then Pod.Reset() end end)
key('mark', Lang('k_mark'), C.Keys.mark or 'E', function() if S.on then Pod.Mark() end end)
key('nexttgt', Lang('k_next'), C.Keys.nextTarget or 'TAB', function() if S.on then Pod.CycleMark() end end)
key('cleartgt', Lang('k_clear'), C.Keys.clearTargets or 'DELETE', function() if S.on then Pod.ClearMarks() end end)
key('help', Lang('k_help'), C.Keys.help or 'H', function() if S.on then Hud.Help() end end)
key('weapon', Lang('k_weapon'), C.Keys.weapon, function()
    if not S.on or not S.weapons or #S.weapons == 0 then return end
    local i = 1
    for k, w in ipairs(S.weapons) do if w == S.weapon then i = k end end
    S.weapon = S.weapons[i % #S.weapons + 1]
end)
key('zoom', Lang('k_zoom'), C.Keys.zoom, function()
    if not S.on then return end
    local fl = S.pdef.fov
    local i = 1
    for k, f in ipairs(fl) do if S.fov <= f + 0.01 then i = k end end
    S.fovI = i % #fl + 1
    S.fov = fl[S.fovI]
end)
key('sensor', Lang('k_sensor'), C.Keys.sensor, function()
    if not S.on then return end
    S.sensor = S.sensor % #SENSORS + 1
    if S.sensorSet then applySensor() end
end)
key('profile', Lang('k_profile'), C.Keys.profile, function()
    local W = S.on and Pod.Weapon()
    if not W or not W.profiles then return end
    S.profile[S.weapon] = (S.profile[S.weapon] or 1) % #W.profiles + 1
end)
key('coords', Lang('k_coords'), C.Keys.coords, function() if S.on and not S.seeker then Hud.Dialog() end end)
key('strike', Lang('k_strike'), C.Keys.strike or 'X', function()
    if not Pod.Platform() then return end
    if Missile.Strike() then Pod.Message('m_strike', 'good', 2.0) end
end)
key('seeker', Lang('k_seeker'), C.Keys.seeker, function()
    if not S.on then return end
    if S.seeker then S.seeker = nil return end
    local id = Missile.Controllable()
    if id then S.seeker = id end
end)

function Pod.Sensor() return SENSORS[S.sensor or 1] end

--- pod closed: the point stays. While an own laser weapon is in the air the laser keeps it lit (10x a second),
--- so the weapon still goes there. Leaving the aircraft forgets the point.
function Pod.Background()
    if not S.track and #S.marks == 0 and not Missile.Busy() then return end
    local ped = PlayerPedId()
    if not S.veh or not DoesEntityExist(S.veh) or GetVehiclePedIsIn(ped, false) ~= S.veh or not seatOk(S.veh, ped, S.P) then
        S.track, S.trackVeh = nil, nil
        -- left the aircraft: the marks without a weapon are forgotten (weapons in the air keep theirs)
        local keep = {}
        for _, m in ipairs(S.marks) do if m.w then keep[#keep + 1] = m end end
        S.marks = keep
        if S.laser.spot then S.laser.spot = nil Pod.SendLaser(nil) end
        return
    end
    updateMarks()
    Contacts.Look(nil, 0, Pod.NeededIds())
    if not S.track then return end
    if S.track.ent or S.track.cid then
        local tp, e = thingPos(S.track.ent, S.track.cid)
        if tp then S.track.pos, S.track.ent = tp, e else S.track = { pos = S.track.pos } end
    end
    if C.Laser.Auto and Missile.NeedsLaser(S.laser.code) then
        -- own weapons read it directly (no network); masked when the pod cannot look there
        local p, y = U.rot(U.norm(S.track.pos - mountPos()))
        local _, _, limited = gimbal(p, y)
        S.laser.spot = (not limited) and S.track.pos or nil
    elseif S.laser.spot then
        S.laser.spot = nil
        Pod.SendLaser(nil)
    end
end

-- ---------------------------------------------------------------------
-- rearming: the server says go (/rearm at a rearm point); the crew waits in the aircraft, standing still
-- ---------------------------------------------------------------------
local rearmBusy = false
local function rearmStill(veh)
    local ped = PlayerPedId()
    return DoesEntityExist(veh) and GetVehiclePedIsIn(ped, false) == veh and not IsEntityDead(ped) and GetEntitySpeed(veh) <= 1.0
end

RegisterNetEvent('js-atgm:rearmGo', function(secs)
    secs = tonumber(secs) or 20
    if rearmBusy then return end
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh == 0 then return TriggerServerEvent('js-atgm:rearmCancel') end
    rearmBusy = true
    if S.on then Pod.Close() end
    local QB = U.QB()
    if QB and QB.Functions and QB.Functions.Progressbar then
        QB.Functions.Progressbar('js_atgm_rearm', Lang('n_rearming'), math.floor(secs * 1000), false, true,
            { disableMovement = true, disableCarMovement = true, disableMouse = false, disableCombat = true }, {}, {}, {},
            function()
                rearmBusy = false
                if rearmStill(veh) then TriggerServerEvent('js-atgm:rearmDone') else TriggerServerEvent('js-atgm:rearmCancel') end
            end,
            function()
                rearmBusy = false
                TriggerServerEvent('js-atgm:rearmCancel')
            end)
        return
    end
    -- no qb-core: a plain timer that stops if the aircraft moves or the crew gets out
    U.notify(Lang('n_rearming'), 'primary')
    CreateThread(function()
        local t0 = GetGameTimer()
        while GetGameTimer() - t0 < secs * 1000 do
            Wait(250)
            if not rearmStill(veh) then
                rearmBusy = false
                return TriggerServerEvent('js-atgm:rearmCancel')
            end
        end
        rearmBusy = false
        TriggerServerEvent('js-atgm:rearmDone')
    end)
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then Pod.Close() end
end)
