--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     Small helpers: vectors, GTA rotations, world probes, models, notifications. ]]
U = {}
local sin, cos, rad, deg, atan, asin, sqrt = math.sin, math.cos, math.rad, math.deg, math.atan, math.asin, math.sqrt
local QB
CreateThread(function()
    if GetResourceState('qb-core') == 'started' then
        local ok, core = pcall(function() return exports['qb-core']:GetCoreObject() end)
        if ok then QB = core end
    end
end)

function U.clamp(x, a, b) if x < a then return a elseif x > b then return b end return x end
function U.wrap180(a) a = (a + 180.0) % 360.0 if a < 0 then a = a + 360.0 end return a - 180.0 end
function U.norm(v) local l = #v if l < 1e-9 then return vector3(0.0, 0.0, 0.0) end return v / l end
function U.dot(a, b) return a.x * b.x + a.y * b.y + a.z * b.z end
function U.cross(a, b) return vector3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x) end
function U.flat(v) return vector3(v.x, v.y, 0.0) end

--- GTA rotation (pitch up +, heading CCW from north) -> unit direction
function U.dir(pitch, yaw)
    local p, y = rad(pitch), rad(yaw)
    return vector3(-sin(y) * cos(p), cos(y) * cos(p), sin(p))
end
--- unit direction -> pitch, heading
function U.rot(d)
    return deg(asin(U.clamp(d.z, -1.0, 1.0))), deg(atan(-d.x, d.y))
end

--- rotate unit vector a towards unit vector b by at most maxAngle (radians)
U.turn = GD.turn                              -- one implementation (shared/guidance.lua), safe for opposite directions

--- the QBCore object, if qb-core runs (nil otherwise)
function U.QB() return QB end

--- line probe: hit?, position, entity
function U.ray(a, b, ignore, flags)
    local h = StartExpensiveSynchronousShapeTestLosProbe(a.x, a.y, a.z, b.x, b.y, b.z, flags or -1, ignore or 0, 7)
    local _, hit, pos, _, ent = GetShapeTestResult(h)
    return hit == 1, pos, ent
end

--- the game's height map (works where collision is not streamed). Called by hash: the Lua names of these
--- two natives differ between FiveM builds (GET_HEIGHTMAP_TOP_Z_FOR_POSITION / _BOTTOM_)
function U.hmTop(x, y) return Citizen.InvokeNative(0x29C24BFBED8AB8FB, x + 0.0, y + 0.0, Citizen.ResultAsFloat()) end
function U.hmBottom(x, y) return Citizen.InvokeNative(0x336511A34F2E5185, x + 0.0, y + 0.0, Citizen.ResultAsFloat()) end

--- ground height even where collision is not streamed (height map)
function U.groundZ(x, y)
    local ok, z = GetGroundZFor_3dCoord(x, y, 1500.0, false)
    if ok and z then return z end
    return U.hmTop(x, y)
end

--- where a line of sight meets the world: real collision first, the height map beyond the streamed area
function U.sight(from, dir, maxRange, ignore)
    local hit, pos, ent = U.ray(from, from + dir * maxRange, ignore)
    if hit then return true, pos, ent end
    if dir.z >= -0.001 then return false, from + dir * maxRange, 0 end
    -- march over the height map (coarse, then refine)
    local step, d, last = 60.0, 0.0, 0.0
    while d < maxRange do
        d = d + step
        local p = from + dir * d
        if p.z <= U.hmTop(p.x, p.y) then
            local lo, hi = last, d
            for _ = 1, 10 do
                local m = (lo + hi) * 0.5
                local q = from + dir * m
                if q.z <= U.hmTop(q.x, q.y) then hi = m else lo = m end
            end
            local q = from + dir * hi
            return true, vector3(q.x, q.y, U.hmTop(q.x, q.y)), 0
        end
        last = d
    end
    return false, from + dir * maxRange, 0
end

function U.model(name)
    local h = type(name) == 'number' and name or joaat(name)
    if not IsModelInCdimage(h) then return nil end
    RequestModel(h)
    local t = GetGameTimer()
    while not HasModelLoaded(h) and GetGameTimer() - t < 3000 do Wait(0) end
    return HasModelLoaded(h) and h or nil
end

-- official names first, old aliases as a fallback (names differ between FiveM builds)
U.useAsset = UseParticleFxAsset or UseParticleFxAssetNextCall
U.labelText = GetFilenameForAudioConversation or GetLabelText

function U.ptfx(asset)
    if HasNamedPtfxAssetLoaded(asset) then return true end
    RequestNamedPtfxAsset(asset)
    local t = GetGameTimer()
    while not HasNamedPtfxAssetLoaded(asset) and GetGameTimer() - t < 1500 do Wait(0) end
    return HasNamedPtfxAssetLoaded(asset)
end

function U.notify(msg, typ)
    if QB then return QB.Functions.Notify(msg, typ or 'primary') end
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end
RegisterNetEvent('js-atgm:notify', function(msg, typ) U.notify(msg, typ) end)

function U.jobOk()
    if not Config.Jobs or not QB then return true end
    local pd = QB.Functions.GetPlayerData()
    local job = pd and pd.job
    if not job then return false end
    for _, j in ipairs(Config.Jobs) do
        if job.name == j and ((job.grade and job.grade.level) or 0) >= (Config.MinJobGrade or 0) then return true end
    end
    return false
end

--- weapons in a fixed, sensible order
local ORDER = { 'hellfire', 'maverick', 'spike', 'harop', 'gbu12', 'gbu39', 'jdam', 'gbu28' }
function U.weaponOrder(loadout)
    local out, seen = {}, {}
    for _, k in ipairs(ORDER) do if loadout[k] and Config.Weapons[k] then out[#out + 1] = k seen[k] = true end end
    local rest = {}
    for k in pairs(loadout) do if not seen[k] and Config.Weapons[k] then rest[#rest + 1] = k end end
    table.sort(rest)
    for _, k in ipairs(rest) do out[#out + 1] = k end
    return out
end
