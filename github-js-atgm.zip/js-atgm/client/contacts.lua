--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     Far contacts. The game only creates other players / vehicles within ~420 m of you (OneSync), so from
     altitude or far away the pod would show an empty world. While the pod looks somewhere, the server sends
     the players and vehicles around that spot (a few times a second, only to this pod, only near the point):
     they are shown as heat spots and can be locked and marked like real ones. As soon as the game has the
     real one (closer), the real one is used.
       key: 'p<server id>' = a player on foot, 'v<net id>' = a vehicle ]]
Contacts = {}
local list = {}            -- key -> { kind, pos, vel, occ, t }
local sent = { t = 0, pos = nil, r = 0, ids = '' }
local C = Config

--- the real entity of a contact, when the game has it here
function Contacts.Ent(key)
    if type(key) ~= 'string' then return nil end
    local kind, n = key:sub(1, 1), tonumber(key:sub(2))
    if not n then return nil end
    if kind == 'p' then
        local pl = GetPlayerFromServerId(n)
        if pl and pl ~= -1 then
            local ped = GetPlayerPed(pl)
            if ped ~= 0 and DoesEntityExist(ped) then
                local veh = GetVehiclePedIsIn(ped, false)
                return veh ~= 0 and veh or ped
            end
        end
    elseif kind == 'v' then
        if NetworkDoesNetworkIdExist(n) then
            local e = NetworkGetEntityFromNetworkId(n)
            if e ~= 0 and DoesEntityExist(e) then return e end
        end
    end
    return nil
end

--- where a contact is now (real entity if we have it, else the last report moved on by its speed)
function Contacts.Pos(key)
    local e = Contacts.Ent(key)
    if e then return GetEntityCoords(e) + vector3(0.0, 0.0, IsEntityAPed(e) and 0.2 or 0.4), GetEntityVelocity(e), e end
    local c = list[key]
    if not c then return nil end
    local dt = math.min((GetGameTimer() - c.t) / 1000.0, 1.5)
    return c.pos + c.vel * dt, c.vel, nil
end

-- ---------------------------------------------------------------------
-- stand-ins: a far contact shown as a real model at its place - only on this screen, no collision, frozen,
-- moved to the reported position every frame. Created while the pod is open, removed the moment the game
-- has the real one (or the contact is gone, or the pod closes).
-- ---------------------------------------------------------------------
local proxies, proxyOf = {}, {}            -- key -> { ent, ped }, entity -> key
local FREEMODE = { [joaat('mp_m_freemode_01')] = true, [joaat('mp_f_freemode_01')] = true }
local WALK = { 'move_m@generic', 'walk' }

--- the contact a stand-in entity stands for (nil = not a stand-in)
function Contacts.KeyOf(ent) return ent and proxyOf[ent] or nil end
function Contacts.HasProxy(key) return proxies[key] ~= nil end

local function dropProxy(key)
    local p = proxies[key]
    if not p then return end
    proxies[key] = nil
    proxyOf[p.ent] = nil
    if DoesEntityExist(p.ent) then
        SetEntityAsMissionEntity(p.ent, true, true)
        if p.ped then DeletePed(p.ent) else DeleteVehicle(p.ent) end
        if DoesEntityExist(p.ent) then DeleteEntity(p.ent) end
    end
end

local function ready(h)
    if not h or h == 0 or not IsModelInCdimage(h) then return false end
    if HasModelLoaded(h) then return true end
    RequestModel(h)                                     -- not waited for: it appears next frames
    return false
end

--- every frame while the pod is open (on = true); on = false removes them all
function Contacts.Proxies(on)
    local K = C.Contacts or {}
    if not on or K.Proxy == false or K.Enabled == false then
        for key in pairs(proxies) do dropProxy(key) end
        return
    end
    local now = GetGameTimer()
    local keep, n = {}, 0
    for key, c in pairs(list) do
        if now - c.t <= 2500 and n < (K.Max or 24) and not Contacts.Ent(key) then
            n = n + 1
            keep[key] = true
            local dt = math.min((now - c.t) / 1000.0, 1.5)
            local pos = c.pos + c.vel * dt
            local moving = (c.vel.x * c.vel.x + c.vel.y * c.vel.y) > 0.64
            local hd = moving and math.deg(math.atan(-c.vel.x, c.vel.y)) or c.h
            local p = proxies[key]
            if not p then
                local ped = c.kind == 'ped'
                local h = c.model
                if ped and (not h or FREEMODE[h]) then h = joaat(K.PedModel or 's_m_y_blackops_01') end
                if ready(h) then
                    local e = ped and CreatePed(4, h, pos.x, pos.y, pos.z, hd, false, false)
                                  or CreateVehicle(h, pos.x, pos.y, pos.z, hd, false, false)
                    SetModelAsNoLongerNeeded(h)
                    if e and e ~= 0 then
                        SetEntityAsMissionEntity(e, true, true)
                        SetEntityCollision(e, false, false)
                        FreezeEntityPosition(e, true)
                        SetEntityInvincible(e, true)
                        local lodD = (C.Picture and C.Picture.EntityLod) or 0.0
                        if lodD > 0 then SetEntityLodDist(e, math.floor(lodD)) end
                        if ped then
                            SetBlockingOfNonTemporaryEvents(e, true)
                            SetPedCanRagdoll(e, false)
                        else
                            SetVehicleEngineOn(e, c.occ > 0, true, true)
                        end
                        proxies[key] = { ent = e, ped = ped }
                        proxyOf[e] = key
                    end
                end
            else
                SetEntityCoordsNoOffset(p.ent, pos.x, pos.y, pos.z, false, false, false)
                SetEntityHeading(p.ent, hd)
                if p.ped then
                    -- walking when it moves
                    if moving and not IsEntityPlayingAnim(p.ent, WALK[1], WALK[2], 3) then
                        RequestAnimDict(WALK[1])
                        if HasAnimDictLoaded(WALK[1]) then TaskPlayAnim(p.ent, WALK[1], WALK[2], 4.0, 4.0, -1, 1, 0.0, false, false, false) end
                    elseif not moving and IsEntityPlayingAnim(p.ent, WALK[1], WALK[2], 3) then
                        ClearPedTasksImmediately(p.ent)
                    end
                end
            end
        end
    end
    for key in pairs(proxies) do if not keep[key] then dropProxy(key) end end
end

AddEventHandler('onResourceStop', function(r)
    if r == GetCurrentResourceName() then for key in pairs(proxies) do dropProxy(key) end end
end)

--- contacts that are only known from the server (the game does not draw them here)
function Contacts.Remote()
    local out, now = {}, GetGameTimer()
    for key, c in pairs(list) do
        if now - c.t > 2500 then list[key] = nil
        elseif not Contacts.Ent(key) then
            local dt = math.min((now - c.t) / 1000.0, 1.5)
            out[#out + 1] = { key = key, kind = c.kind, pos = c.pos + c.vel * dt, occ = c.occ }
        end
    end
    return out
end

--- the contact closest to a point (within r m), only server-known ones
function Contacts.Near(p, r)
    local best, bd
    for _, c in ipairs(Contacts.Remote()) do
        local d = #(c.pos - p)
        if d < (r or 10.0) and (not bd or d < bd) then best, bd = c.key, d end
    end
    return best
end

--- tell the server where the pod looks (radius = what is in the picture) and which contacts must keep coming
--- (locked / marked / a weapon flies to them). Throttled; nil pos + no ids = stop.
function Contacts.Look(pos, r, ids)
    local K = C.Contacts or {}
    if K.Enabled == false then return end
    local now = GetGameTimer()
    local idKey = table.concat(ids or {}, ',')
    if not pos and #(ids or {}) == 0 then
        if sent.on then sent.on = false TriggerServerEvent('js-atgm:look', false) end
        return
    end
    r = math.max(60.0, math.min(r or 300.0, K.Radius or 900.0))
    local since = now - sent.t
    if sent.on and since < 450 then return end           -- (a new start after a stop goes out at once)
    local moved = (pos == nil) ~= (sent.pos == nil) or (pos and sent.pos and #(pos - sent.pos) > 25.0)
    if sent.on and not moved and math.abs(r - sent.r) < sent.r * 0.2 and idKey == sent.ids and since < 2000 then return end
    sent.t, sent.pos, sent.r, sent.ids, sent.on = now, pos, r, idKey, true
    TriggerServerEvent('js-atgm:look', { p = pos and { pos.x, pos.y, pos.z } or nil, r = r, ids = ids or {} })
end

RegisterNetEvent('js-atgm:contacts', function(l)
    if type(l) ~= 'table' then return end
    local now = GetGameTimer()
    for _, c in ipairs(l) do
        if type(c) == 'table' and type(c[1]) == 'string' then
            local x, y, z = tonumber(c[3]), tonumber(c[4]), tonumber(c[5])
            if x and y and z then
                list[c[1]] = { kind = tostring(c[2] or 'veh'), pos = vector3(x, y, z),
                               vel = vector3(tonumber(c[6]) or 0.0, tonumber(c[7]) or 0.0, tonumber(c[8]) or 0.0),
                               occ = tonumber(c[9]) or 0, model = tonumber(c[10]), h = tonumber(c[11]) or 0.0, t = now }
            end
        end
    end
end)
