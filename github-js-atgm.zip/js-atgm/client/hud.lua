--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     HUD bridge: sends the symbology data to the page (30 a second while the pod is open), vehicle boxes
     in the picture, the target data dialog (coordinates, map waypoint, laser code, stored points),
     and motor / launch sounds. ]]
Hud = {}
local C = Config
local S = Pod
local hudT, boxT = 0.0, 0.0
local cand = {}            -- vehicles that may be in the picture (refreshed 3x a second)
local lodSet, lodN = {}, 0                    -- entities already set to be drawn from far

--- the key legend at the bottom of the picture (the keys from Config.Keys)
local function keyName(k)
    return ({ MOUSE_LEFT = 'LMB', MOUSE_RIGHT = 'RMB', SPACE = 'SPACE', DELETE = 'DEL' })[k] or k
end
local function legend()
    local K = C.Keys
    local aim = (C.Aim and C.Aim.Mouse) and 'ARROWS/MOUSE' or 'ARROWS'
    return { { aim, 'AIM' }, { keyName(K.reset or 'R'), 'RESET' }, { keyName(K.track), 'LOCK' },
             { keyName(K.mark or 'E'), 'MARK' }, { keyName(K.nextTarget or 'TAB'), 'NEXT' }, { keyName(K.clearTargets or 'DELETE'), 'CLR' },
             { keyName(K.fire), 'FIRE' },
             { keyName(K.weapon), 'WPN' }, { keyName(K.zoom), 'ZOOM' }, { keyName(K.profile), 'PROF' },
             { keyName(K.coords), 'DATA' }, { keyName(K.help or 'H'), 'HELP' }, { keyName(K.pod), 'EXIT' } }
end

local INFO = JSATGM_INFO()
exports('Info', function() return INFO end)

function Hud.Show(on, boot)
    if not on and helpOn then Hud.Help(false) end
    SendNUIMessage({ a = 'show', on = on, boot = boot or 0, label = on and S.pdef and S.pdef.label or nil, b = INFO,
                     strings = on and Locales[C.Locale] or nil, keys = on and legend() or nil })
end

--- own weapons on screen: where each one is and the point it is going to
local function marks(list)
    local out = {}
    for _, m in ipairs(list) do
        local r = { tof = m.tof, w = m.w, ph = m.ph }
        if m.pos then
            local ok, x, y = GetScreenCoordFromWorldCoord(m.pos.x, m.pos.y, m.pos.z)
            if ok then r.mx, r.my = x, y end
        end
        if m.aim then
            local ok, x, y = GetScreenCoordFromWorldCoord(m.aim.x, m.aim.y, m.aim.z)
            if ok then r.ax, r.ay = x, y end
        end
        out[#out + 1] = r
    end
    return out
end

--- impact: a flash on the HUD where it hit (if it is in the picture)
function Hud.Impact(pos)
    if not S.on then return end
    local ok, x, y = GetScreenCoordFromWorldCoord(pos.x, pos.y, pos.z)
    SendNUIMessage({ a = 'impact', x = ok and x or nil, y = ok and y or nil })
end

function Hud.Sound(id, vol, pan) SendNUIMessage({ a = 'snd', id = id, vol = vol, pan = pan }) end
function Hud.Launch(bomb) SendNUIMessage({ a = 'launch', bomb = bomb }) end

local function compass(h) return math.floor((360.0 - h) % 360.0 + 0.5) % 360 end

local function fovName(fov)
    local fl = S.pdef.fov
    local names = { 'WFOV', 'MFOV', 'NFOV', 'ZOOM' }
    local best, bd = 1, 1e9
    for i, f in ipairs(fl) do local d = math.abs(f - fov) if d < bd then best, bd = i, d end end
    return names[best] or 'ZOOM'
end

local function zone(p)
    local z = GetNameOfZone(p.x, p.y, p.z)
    local l = U.labelText(z)
    return (l and l ~= 'NULL') and l or z
end

--- boxes around vehicles in the picture (like an automatic target cue)
local function boxes(dt)
    local cam = S.aim and S.aim.cam
    if not cam then return {} end
    boxT = boxT - dt
    if boxT <= 0.0 then
        boxT = 0.33
        cand = {}
        local look = S.aim.dir
        local tanH = math.tan(math.rad(S.fov * 0.5)) * 1.9
        local me = PlayerPedId()
        local function consider(v, isPed)
            local to = GetEntityCoords(v) - cam
            local d = #to
            if d > 15.0 and d < S.pdef.maxRange then
                local along = U.dot(to, look)
                if along > 0 and #(to - look * along) < along * tanH then
                    -- only what the pod can actually see (not behind a hill or a building)
                    local vp = cam + to
                    local hit, hp, he = U.ray(cam, vp + vector3(0.0, 0.0, isPed and 0.3 or 0.6), S.veh, 1 + 2 + 16)
                    if not hit or he == v or #(hp - vp) < (isPed and 2.0 or 4.0) then cand[#cand + 1] = v end
                end
            end
        end
        for _, v in ipairs(GetGamePool('CVehicle')) do
            if v ~= S.veh then consider(v, false) end
            if #cand >= 16 then break end
        end
        -- people too (players and others on foot)
        for _, ped in ipairs(GetGamePool('CPed')) do
            if #cand >= 24 then break end
            if ped ~= me and not IsPedInAnyVehicle(ped, false) then consider(ped, true) end
        end
    end
    local out = {}
    local tr = S.track and S.track.ent
    local k = 1.0 / (2.0 * math.tan(math.rad(S.fov * 0.5)))
    local lodD = C.Picture.EntityLod or 0.0
    for _, v in ipairs(cand) do
        -- drawn from far away (the game drops people / cars from the picture long before the pod's range)
        if lodD > 0 and DoesEntityExist(v) and not lodSet[v] then
            if lodN > 400 then lodSet, lodN = {}, 0 end
            lodSet[v], lodN = true, lodN + 1
            SetEntityLodDist(v, math.floor(lodD))
        end
        if DoesEntityExist(v) and not IsEntityDead(v) then
            local p = GetEntityCoords(v)
            local ok, x, y = GetScreenCoordFromWorldCoord(p.x, p.y, p.z + 0.4)
            if ok then
                local isPed = IsEntityAPed(v)
                local w = U.clamp((isPed and 1.6 or 5.0) / #(p - cam) * k, isPed and 0.008 or 0.012, 0.2)
                out[#out + 1] = { x = x, y = y, w = w, t = v == tr, p = isPed or nil }
            end
        end
    end
    return out
end

--- far contacts (known from the server only): heat spots sized like the real thing would be
local SIZE = { ped = { 0.9, 1.7 }, veh = { 4.6, 2.2 }, air = { 14.0, 10.0 }, boat = { 8.0, 3.2 } }
local function contacts()
    local cam = S.aim and S.aim.cam
    if not cam or S.seeker then return {} end
    local k = 1.0 / (2.0 * math.tan(math.rad(S.fov * 0.5)))
    local trk = S.track and S.track.cid
    local out = {}
    for _, c in ipairs(Contacts.Remote()) do
        if Contacts.HasProxy(c.key) then goto continue end        -- its stand-in model is in the picture
        local ok, x, y = GetScreenCoordFromWorldCoord(c.pos.x, c.pos.y, c.pos.z + (c.kind == 'ped' and 0.9 or 0.8))
        if ok then
            local d = #(c.pos - cam)
            local sz = SIZE[c.kind] or SIZE.veh
            out[#out + 1] = { x = x, y = y, w = U.clamp(sz[1] / d * k, 0.004, 0.15), h = U.clamp(sz[2] / d * k, 0.006, 0.15),
                              k = c.kind, t = c.key == trk or nil, o = c.occ > 0 or nil }
        end
        if #out >= 32 then break end
        ::continue::
    end
    return out
end

function Hud.Frame(dt)
    hudT = hudT - dt
    if hudT > 0.0 then return end
    hudT = 1.0 / 30.0
    local veh = S.veh
    local vp = GetEntityCoords(veh)
    local vr = GetEntityRotation(veh, 2)
    local ammo = Pod.Ammo()
    local wl = {}
    for _, k in ipairs(S.weapons or {}) do
        local W = C.Weapons[k]
        wl[#wl + 1] = { k = W.short, n = ammo[k] or 0, s = k == S.weapon }
    end
    local W = Pod.Weapon()
    local okSpec, why = nil, nil
    if W and not S.seeker then okSpec, why = Pod.CanFire() end
    local msg = S.msg and GetGameTimer() < S.msg.untilT and S.msg or nil
    local aim = S.aim or {}
    local L = S.laser
    local lst = W and (W.kind == 'sal' or W.kind == 'lgb') and Pod.NearestSpot(L.code, aim.pos) ~= nil
    local flying = Missile.List()
    local d = {
        a = 'hud', pod = S.pdef.label, sensor = Pod.Sensor(), fov = fovName(S.fov), fovDeg = S.fov,
        hdg = compass(vr.z), az = S.relAz or 0.0, el = S.relEl or 0.0,
        lim = { S.pdef.az, S.pdef.elUp, S.pdef.elDown },
        range = aim.hit and aim.range or nil, lrange = L.range, lasing = L.spot ~= nil, latched = L.latched, code = L.code,
        track = S.track and (S.track.ent and 'VT' or 'PT') or nil,
        tgt = aim.hit and { x = math.floor(aim.pos.x), y = math.floor(aim.pos.y), z = math.floor(aim.pos.z), zone = zone(aim.pos),
                            -- bearing (from north, clockwise) and ground range from the aircraft
                            brg = math.floor((math.deg(math.atan(aim.pos.x - vp.x, aim.pos.y - vp.y)) + 360.0) % 360.0),
                            gr = math.floor(math.sqrt((aim.pos.x - vp.x) ^ 2 + (aim.pos.y - vp.y) ^ 2)) } or nil,
        alt = math.floor(vp.z), agl = math.floor(vp.z - U.groundZ(vp.x, vp.y)), kts = math.floor(GetEntitySpeed(veh) * 1.944),
        weapons = wl, wlabel = W and W.label or '-', profile = Pod.ProfileName(), ready = okSpec ~= nil,
        why = (not okSpec and why) and Lang(why) or nil, lst = lst,
        warn = (okSpec and okSpec.warn) and Lang(okSpec.warn) or nil,
        gps = S.gps and { x = math.floor(S.gps.x), y = math.floor(S.gps.y) } or nil,
        flying = nil, marks = S.seeker and {} or marks(flying), msg = msg and { t = msg.text, l = msg.level } or nil,
        boot = Pod.Booting(),
        -- the point (centre): drawn with a fixed size on the ground, so it grows when you zoom in
        pt = (aim.hit and aim.range) and U.clamp(1.6 / aim.range / (2.0 * math.tan(math.rad(S.fov * 0.5))) * 1920.0, 4.0, 46.0) or nil,
        ptv = S.track and (S.track.ent ~= nil or S.track.cid ~= nil),
        ct = contacts(),
        seeker = S.seeker and Missile.seekInfo or nil,
        boxes = S.seeker and {} or boxes(1.0 / 30.0),
    }
    -- the in-flight list for the text column (without the world positions)
    local fl, tofOf = {}, {}
    for i, f in ipairs(flying) do
        fl[i] = { w = f.w, tof = f.tof, lase = f.lase, loal = f.loal, ph = f.ph, left = f.left, mk = f.mk }
        if f.mk then tofOf[f.mk] = f.tof end
    end
    d.flying = fl
    -- marked targets: where each one is in the picture, and what is going to it
    local nxt = Pod.NextMark()
    local tl = {}
    local cam = aim.cam
    for _, m in ipairs(S.marks) do
        local r = { n = m.n, st = m.w and 'fly' or (m.pend and 'pend' or 'free'), w = m.wshort, tof = tofOf[m.n],
                    nx = nxt == m, d = cam and math.floor(#(m.pos - cam)) or nil }
        if not S.seeker then
            local ok, x, y = GetScreenCoordFromWorldCoord(m.pos.x, m.pos.y, m.pos.z)
            if ok then r.x, r.y = x, y end
        end
        tl[#tl + 1] = r
    end
    d.tl = tl
    SendNUIMessage(d)
end

-- ---------------------------------------------------------------------
-- help page (H): every key from Config.Keys and the steps, in the server's language
-- ---------------------------------------------------------------------
local helpOn = false
function Hud.Help(on)
    if on == nil then on = not helpOn end
    helpOn = on
    if not on then SendNUIMessage({ a = 'help', on = false }) return end
    local K = C.Keys
    local rows = {}
    local function row(k, key) rows[#rows + 1] = { keyName(k), Lang(key) } end
    row((C.Aim and C.Aim.Mouse) and 'ARROWS / MOUSE' or 'ARROWS', 'h_aim')
    row(K.track, 'k_track') row(K.reset or 'R', 'k_reset') row(K.zoom .. ' / WHEEL', 'k_zoom') row(K.sensor, 'k_sensor')
    row(K.fire, 'k_fire') row(K.weapon, 'k_weapon') row(K.profile, 'k_profile')
    row(K.mark or 'E', 'k_mark') row(K.nextTarget or 'TAB', 'k_next') row(K.clearTargets or 'DELETE', 'k_clear')
    row(K.laser, 'k_laser') row(K.laserOn, 'k_laseron') row(K.coords, 'k_coords')
    row(K.seeker, 'k_seeker') row(K.strike or 'X', 'k_strike') row(K.pod, 'k_pod')
    local steps = {}
    for i = 1, 6 do steps[i] = Lang('h_step' .. i) end
    SendNUIMessage({ a = 'help', on = true, title = Lang('h_title'), rows = rows, steps = steps, foot = Lang('h_foot') })
end
function Hud.HelpOpen() return helpOn end

-- ---------------------------------------------------------------------
-- target data dialog. Lua decides when it closes (the page only hides it when told), so the mouse is never
-- left captured: every answer says close or not, and closing the pod always releases the focus.
-- ---------------------------------------------------------------------
local dialogOpen = false

function Hud.Dialog()
    dialogOpen = true
    SetNuiFocus(true, true)
    local pts = {}
    for i, p in ipairs(S.points) do pts[i] = { x = math.floor(p.x), y = math.floor(p.y), z = math.floor(p.z), zone = zone(p) } end
    SendNUIMessage({ a = 'dialog', code = S.laser.code, codes = C.Laser.Codes, points = pts,
                     gps = S.gps and { x = math.floor(S.gps.x), y = math.floor(S.gps.y), z = math.floor(S.gps.z) } or nil })
end

function Hud.CloseDialog()
    if not dialogOpen then return end
    dialogOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ a = 'dialogClose' })
end
function Hud.DialogOpen() return dialogOpen end

local function setGps(p)
    S.gps = p
    Pod.Message('m_gps_set', 'good', 2.0)
end

--- one dialog action -> close?, error message key
local function dialogAct(d)
    if not S.on then return true end                       -- the pod closed meanwhile: just let go of the mouse
    local act = d.act
    if act == 'close' then return true
    elseif act == 'set' then
        local x, y = tonumber(d.x), tonumber(d.y)
        local ok = x and y and x == x and y == y and math.abs(x) <= 10000 and math.abs(y) <= 10000
        if not ok then return false, 'd_bad' end
        local z = tonumber(d.z)
        if not z or z ~= z or math.abs(z) > 3000 then z = U.groundZ(x, y) end
        setGps(vector3(x + 0.0, y + 0.0, z + 0.0))
        return true
    elseif act == 'waypoint' then
        local b = GetFirstBlipInfoId(8)
        if not DoesBlipExist(b) then return false, 'd_no_wp' end
        local c = GetBlipInfoIdCoord(b)
        setGps(vector3(c.x, c.y, U.groundZ(c.x, c.y)))
        return true
    elseif act == 'pod' then
        if not (S.aim and S.aim.hit) then return false, 'd_no_pt' end
        setGps(S.aim.pos)
        return true
    elseif act == 'clear' then
        S.gps = nil
        return true
    elseif act == 'code' then
        local c = tonumber(d.code)
        for _, v in ipairs(C.Laser.Codes) do if v == c then S.laser.code = c end end
        return false
    elseif act == 'store' then
        if not (S.aim and S.aim.hit) then return false, 'd_no_pt' end
        table.insert(S.points, 1, S.aim.pos)
        if #S.points > 6 then S.points[7] = nil end
        Hud.Dialog()                                         -- redraw the list
        return false
    elseif act == 'use' then
        local p = S.points[tonumber(d.i) or 0]
        if not p then return false, 'd_no_pt' end
        setGps(p)
        return true
    end
    return true                                              -- unknown action: close rather than hang
end

RegisterNUICallback('dlg', function(d, cb)
    local okCall, close, err = pcall(dialogAct, type(d) == 'table' and d or { act = 'close' })
    if not okCall then close, err = true, nil end
    if close then
        dialogOpen = false
        SetNuiFocus(false, false)
    end
    cb({ close = close and true or false, err = err and Lang(err) or nil })
end)
