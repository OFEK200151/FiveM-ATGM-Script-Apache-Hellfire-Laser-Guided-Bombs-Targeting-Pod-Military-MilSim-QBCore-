--[[ js-atgm | made by Jhonny · JS-STUDIO ]]
-- build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
Locales = Locales or {}
Locales.en = {
    n_no_job = 'You are not qualified on this weapons system',
    n_not_platform = 'You are not in a weapons seat of an armed aircraft',
    n_no_rearm_point = 'No rearm point here - land at an air base',
    n_stop_first = 'Stop the aircraft first',
    n_rearm_fail = 'Rearming interrupted',
    n_rearmed = 'Aircraft rearmed',
    n_rearming = 'Rearming...',
    k_pod = 'Targeting pod on / off', k_fire = 'Fire / release weapon', k_laser = 'Laser (hold)',
    k_laseron = 'Laser continuous on / off', k_track = 'Track target / point', k_weapon = 'Next weapon',
    k_zoom = 'Field of view', k_sensor = 'Picture (TV gray / IR thermal)', k_coords = 'Target coordinates / laser code',
    k_profile = 'Flight profile (direct / lofted)', k_seeker = 'Weapon camera view (Spike / HAROP)', k_strike = 'HAROP: strike the point',
    -- HUD messages (short, like real symbology)
    m_no_weapon = 'NO WEAPON', m_empty = 'NO AMMO', m_no_laser = 'NO LASER - LASE TARGET', m_no_target = 'NO TARGET',
    m_range_min = 'TOO CLOSE', m_range_max = 'OUT OF RANGE', m_off_axis = 'TURN TO TARGET', m_alt = 'CLIMB - TOO LOW',
    m_gimbal = 'GIMBAL LIMIT', m_launch = 'LAUNCH', m_release = 'RELEASE', m_impact = 'IMPACT', m_lost = 'MISSILE LOST',
    m_rate = 'WAIT', m_busy = 'TOO MANY IN FLIGHT', m_track_lost = 'TRACK LOST', m_loal = 'LOAL - LASE BEFORE IMPACT',
    m_gps_set = 'TGT COORD SET', m_strike = 'STRIKE', m_reach = 'OUT OF REACH - CLIMB / GET CLOSER', m_no_vehicle = 'NO VEHICLE ON THE POINT', m_selfdestruct = 'SELF DESTRUCT', m_laser_batt = 'LASER BATTERY',
    -- dialog
    d_title = 'Target data', d_x = 'X', d_y = 'Y', d_z = 'Altitude (empty = ground)', d_set = 'Set target',
    d_waypoint = 'Map waypoint', d_pod = 'Pod point', d_clear = 'Clear', d_close = 'Close', d_code = 'Laser code',
    d_points = 'Stored points', d_store = 'Store pod point', d_use = 'Use',
    m_reach_warn = 'MAY FALL SHORT - CLIMB / GET CLOSER',
    k_reset = 'Reset the point', m_reset = 'POINT RESET',
    m_laser_lost = 'NO LASER SPOT - BALLISTIC', m_track_point = 'VEHICLE OUT OF SIGHT - POINT TRACK', m_late = 'NO ANSWER - TRY AGAIN',
    d_bad = 'Enter X and Y (numbers within the map)', d_no_wp = 'No waypoint on the map', d_no_pt = 'The pod has no point',
}
Locales.en.k_mark = 'Mark a target (T1, T2 ...) / unmark'
Locales.en.k_next = 'Look at the next marked target'
Locales.en.k_clear = 'Clear the marked targets'
Locales.en.m_marked = 'T%d MARKED'
Locales.en.m_unmarked = 'T%d UNMARKED'
Locales.en.m_marks_full = 'TARGET LIST FULL'
Locales.en.m_marks_clear = 'TARGETS CLEARED'
Locales.en.m_ripple = 'RIPPLE COMPLETE'
Locales.en.k_help = 'Help page in the pod'
Locales.en.h_title = 'How to use the pod'
Locales.en.h_aim = 'Move the point and the camera (tap = precise, hold = fast)'
Locales.en.h_step1 = 'Put the point on the target with the arrows. Zoom with Z / the wheel.'
Locales.en.h_step2 = 'A vehicle or a person: SPACE locks on and the point rides with it. A far player shows as a figure / heat spot - lock on it too.'
Locales.en.h_step3 = 'Several targets: E marks T1, T2 ..., TAB moves between them, DEL clears.'
Locales.en.h_step4 = 'Q picks the weapon. RDY = ready. A red message = why not (range, altitude, no target).'
Locales.en.h_step5 = 'Fire: with marks, one weapon on each. Without, on the point. You can move the point while it flies.'
Locales.en.h_step6 = 'Next to each target and on the side: the weapon and time to impact. K = coordinates / map waypoint / laser code.'
Locales.en.h_foot = 'H closes this page'
