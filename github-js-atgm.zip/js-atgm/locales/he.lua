--[[ js-atgm | made by Jhonny · JS-STUDIO ]]
-- build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
Locales = Locales or {}
Locales.he = {
    n_no_job = 'אינך מוסמך על מערכת הנשק הזאת',
    n_not_platform = 'אתה לא במושב נשק של כלי טיס חמוש',
    n_no_rearm_point = 'אין כאן נקודת חימוש - נחת בבסיס',
    n_stop_first = 'עצור את כלי הטיס קודם',
    n_rearm_fail = 'החימוש הופסק',
    n_rearmed = 'כלי הטיס חומש',
    n_rearming = 'מחמש...',
    k_pod = 'תרמיל ההכוונה פתוח / סגור', k_fire = 'שיגור / שחרור חימוש', k_laser = 'לייזר (החזקה)',
    k_laseron = 'לייזר רציף פועל / כבוי', k_track = 'נעילה על מטרה / נקודה', k_weapon = 'החימוש הבא',
    k_zoom = 'שדה ראייה', k_sensor = 'תמונה (יום אפור / תרמי)', k_coords = 'נ.צ. מטרה / קוד לייזר',
    k_profile = 'מסלול טיסה (ישיר / מתקפה מלמעלה)', k_seeker = 'מצלמת החימוש (ספייק / הרופ)', k_strike = 'הרופ: תקיפת הנקודה',
    m_reach_warn = 'עלולה ליפול קצר - טפס / התקרב',
    k_reset = 'איפוס הנקודה', m_reset = 'הנקודה אופסה',
    m_laser_lost = 'אין נקודת לייזר - בליסטי', m_track_point = 'הרכב יצא מהטווח - נקודה נשארת', m_late = 'אין תשובה - נסה שוב',
    d_bad = 'הזן X ו-Y (מספרים בתוך המפה)', d_no_wp = 'אין נקודת ציון במפה', d_no_pt = 'לתרמיל אין נקודה',
}
Locales.he.d_title = 'נתוני מטרה'
Locales.he.d_x = 'X'
Locales.he.d_y = 'Y'
Locales.he.d_z = 'גובה (ריק = הקרקע)'
Locales.he.d_set = 'קבע מטרה'
Locales.he.d_waypoint = 'נקודת הציון במפה'
Locales.he.d_pod = 'הנקודה בתרמיל'
Locales.he.d_clear = 'נקה'
Locales.he.d_close = 'סגור'
Locales.he.d_code = 'קוד לייזר'
Locales.he.d_points = 'נקודות שמורות'
Locales.he.d_store = 'שמור את נקודת התרמיל'
Locales.he.d_use = 'השתמש'
Locales.he.k_mark = 'סימון מטרה (T1, T2 ...) / ביטול סימון'
Locales.he.k_next = 'מעבר למטרה המסומנת הבאה'
Locales.he.k_clear = 'ניקוי המטרות המסומנות'
Locales.he.m_marked = 'מטרה T%d סומנה'
Locales.he.m_unmarked = 'הסימון של T%d בוטל'
Locales.he.m_marks_full = 'רשימת המטרות מלאה'
Locales.he.m_marks_clear = 'המטרות נוקו'
Locales.he.m_ripple = 'שוחרר על כל המטרות'
Locales.he.k_help = 'דף עזרה בתרמיל'
Locales.he.h_title = 'איך משתמשים בתרמיל'
Locales.he.h_aim = 'הזזת הנקודה והמצלמה (לחיצה קצרה = מדויק, החזקה = מהר)'
Locales.he.h_step1 = 'מכוונים את הנקודה למטרה עם החצים. זום עם Z / גלגלת.'
Locales.he.h_step2 = 'רכב או אדם: SPACE נועל עליו והנקודה זזה איתו. שחקן רחוק מופיע כדמות / כתם חום - גם עליו נועלים.'
Locales.he.h_step3 = 'כמה מטרות: E מסמן T1, T2 ... , TAB עובר ביניהן, DEL מנקה.'
Locales.he.h_step4 = 'Q בוחר חימוש. RDY = אפשר לירות. הודעה אדומה = למה לא (טווח, גובה, אין מטרה).'
Locales.he.h_step5 = 'לחיצה על ירי: עם מטרות מסומנות - חימוש על כל אחת. בלי - על הנקודה. אפשר להזיז את הנקודה בזמן הטיסה.'
Locales.he.h_step6 = 'ליד כל מטרה ובצד: החימוש וזמן הפגיעה. K = נ.צ. ידני / נקודת ציון במפה / קוד לייזר.'
Locales.he.h_foot = 'H סוגר את הדף'
