--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     Server: the authority on ammunition and launches, and the relay that lets everyone nearby see a missile.
       ammo        kept here only (per vehicle); the vehicle state bag `atgm` is a read-only copy for the HUD
       launch      seat / job / ammo / range / rate checks -> missile id (the request id is sent back)
       flight      the shooter simulates; ~8 updates a second are checked (numbers, rate, speed, distance from
                   the launch) and passed on to players near the missile in the same routing bucket
       lasers      sent only to players in the same routing bucket, only while someone lases on purpose
     No loops except a 2 s cleanup of missiles whose shooter went quiet. ]]
local C = Config
local QBCore
local function core()
    if QBCore then return QBCore end
    if GetResourceState('qb-core') == 'started' then
        local ok, c = pcall(function() return exports['qb-core']:GetCoreObject() end)
        if ok and c then QBCore = c end
    end
    return QBCore
end
CreateThread(core)

local STALE = ((C.Limits and C.Limits.StaleTime) or 15.0) * 1000   -- ms without a report before a missile is dropped
local missiles = {}        -- id -> { src, w, pos, launch, t0, last, lastUpd, bucket, seen = { [src] = true }, armourDone }
local nextId = 0
local lastFire = {}        -- vehicle -> GetGameTimer()
local flying = {}          -- src -> count
local lasers = {}          -- src -> { x, y, z, code, t, bucket }
local rearming = {}        -- src -> { veh, t }
local ammoT = {}           -- vehicle -> { model, a = { weapon = count } }   (the only real ammo count)

local function L(k, ...) return Lang(k, ...) end

--- a finite number (not NaN / inf), optionally within +-lim
local function num(v, lim)
    v = tonumber(v)
    if not v or v ~= v or v == math.huge or v == -math.huge then return nil end
    if lim and (v > lim or v < -lim) then return nil end
    return v
end
local WORLD = 60000.0
--- {x,y,z} or {1,2,3} -> vector3 of finite world numbers, or nil
local function vec(t)
    if type(t) ~= 'table' then return nil end
    local x, y, z = num(t.x or t[1], WORLD), num(t.y or t[2], WORLD), num(t.z or t[3], WORLD)
    if not x or not y or not z then return nil end
    return vector3(x + 0.0, y + 0.0, z + 0.0)
end

local bucketCache = {}     -- src -> { b, t }: read at most once a second per player (relay runs ~8x a second)
local function bucketOf(src)
    if not GetPlayerRoutingBucket then return 0 end
    local now = GetGameTimer()
    local c = bucketCache[src]
    if c and now - c[2] < 1000 then return c[1] end
    local ok, b = pcall(GetPlayerRoutingBucket, tostring(src))
    b = ok and tonumber(b) or 0
    bucketCache[src] = { b, now }
    return b
end

--- speed of an entity on the server (velocity is a server native; speed may not be on every build)
local function speedOf(e)
    if GetEntityVelocity then
        local ok, v = pcall(GetEntityVelocity, e)
        if ok and v then return #v end
    end
    if GetEntitySpeed then return GetEntitySpeed(e) end
    return 0.0
end
local function notify(src, msg, typ) TriggerClientEvent('js-atgm:notify', src, msg, typ or 'primary') end

local function armour(model)
    for _, m in ipairs(C.Armour) do if joaat(m) == model then return true end end
    return false
end

-- ---------------------------------------------------------------------
-- who may use it
-- ---------------------------------------------------------------------
local warned = false
--- list: job names, false = anyone, nil = Config.Jobs. With a job list and no framework it says no.
local function jobOk(src, list)
    if list == nil then list = C.Jobs end
    if not list or #list == 0 then return true end
    local Q = core()
    if not Q then
        if not warned then warned = true print('^3[js-atgm] Config.Jobs is set but qb-core is not running: nobody may use the weapons^7') end
        return false
    end
    local p = Q.Functions.GetPlayer(src)
    local job = p and p.PlayerData and p.PlayerData.job
    if not job then return false end
    for _, j in ipairs(list) do
        if job.name == j and ((job.grade and job.grade.level) or 0) >= (C.MinJobGrade or 0) then return true end
    end
    return false
end

--- the platform of the vehicle the player sits in, if the player sits in a weapons seat
local function platformOf(src)
    local ped = GetPlayerPed(src)
    if ped == 0 then return nil end
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return nil end
    local model = GetEntityModel(veh)
    for name, P in pairs(C.Platforms) do
        if joaat(name) == model then
            for _, s in ipairs(P.seats or { -1 }) do
                if GetPedInVehicleSeat(veh, s) == ped then return P, veh, name end
            end
            return nil
        end
    end
    return nil
end

-- ---------------------------------------------------------------------
-- ammunition: counted here; the state bag is only a copy the HUD reads (a client writing it changes nothing)
-- ---------------------------------------------------------------------
local function mirror(veh, a)
    local copy = {}
    for k, v in pairs(a) do copy[k] = v end
    Entity(veh).state:set('atgm', copy, true)
end

local function fullLoad(P)
    local a = {}
    for w, n in pairs(P.loadout or {}) do if C.Weapons[w] then a[w] = n end end
    return a
end

local function ammoOf(veh, P)
    local model = GetEntityModel(veh)
    local e = ammoT[veh]
    if not e or e.model ~= model then
        e = { model = model, a = fullLoad(P) }
        ammoT[veh] = e
        mirror(veh, e.a)
    end
    return e.a
end

AddEventHandler('entityRemoved', function(ent)
    ammoT[ent], lastFire[ent] = nil, nil
end)

-- the HUD asks once when the pod opens: creates the loadout on a fresh aircraft (and corrects the copy)
RegisterNetEvent('js-atgm:hello', function()
    local src = source
    local P, veh = platformOf(src)
    if not P then return end
    if not jobOk(src) then return notify(src, L('n_no_job'), 'error') end
    mirror(veh, ammoOf(veh, P))
end)

-- ---------------------------------------------------------------------
-- launch
-- ---------------------------------------------------------------------
--- @param d { w = weapon key, pos = {x,y,z}, tgt = {x,y,z}|nil, rid = request id }
RegisterNetEvent('js-atgm:launch', function(d)
    local src = source
    if type(d) ~= 'table' or type(d.w) ~= 'string' then return end
    local rid = num(d.rid, 1e9)
    local function no(why) TriggerClientEvent('js-atgm:launchNo', src, why, rid) end
    local W = C.Weapons[d.w]
    local P, veh = platformOf(src)
    if not W or not P then return no('seat') end
    if not jobOk(src) then notify(src, L('n_no_job'), 'error') return no('job') end
    local pos = vec(d.pos)
    if not pos then return no('seat') end
    local a = ammoOf(veh, P)
    if (a[d.w] or 0) <= 0 then return no('empty') end
    local now = GetGameTimer()
    if now - (lastFire[veh] or -1e9) < C.Limits.FireInterval * 1000 then return no('rate') end
    if (flying[src] or 0) >= C.Limits.InFlight then return no('busy') end
    if #(pos - GetEntityCoords(veh)) > 40.0 then return no('seat') end      -- launched from the aircraft
    if d.tgt ~= nil then
        local tp = vec(d.tgt)
        if not tp then return no('range') end
        if #(tp - pos) > (W.maxRange or 10000.0) * 1.15 then return no('range') end
    end
    a[d.w] = a[d.w] - 1
    mirror(veh, a)
    lastFire[veh] = now
    nextId = nextId + 1
    local id = nextId
    missiles[id] = { src = src, w = d.w, pos = pos, launch = pos, t0 = now, last = now, lastUpd = 0,
                     bucket = bucketOf(src), seen = {} }
    flying[src] = (flying[src] or 0) + 1
    TriggerClientEvent('js-atgm:launchOk', src, id, d.w, a[d.w], rid)
end)

-- ---------------------------------------------------------------------
-- flight relay: the shooter sends its missile's state, players near it (same bucket) get it
-- ---------------------------------------------------------------------
local function relay(m, id, payload)
    local range = C.Limits.SyncRange
    for _, s in ipairs(GetPlayers()) do
        s = tonumber(s)
        if s ~= m.src then
            local ped = GetPlayerPed(s)
            if ped ~= 0 and bucketOf(s) == m.bucket and #(GetEntityCoords(ped) - m.pos) < range then
                m.seen[s] = true
                TriggerClientEvent('js-atgm:remote', s, id, m.w, payload)
            elseif m.seen[s] then
                m.seen[s] = nil
                TriggerClientEvent('js-atgm:remoteEnd', s, id, nil)
            end
        end
    end
end

local function round1(v) return math.floor(v * 10 + 0.5) / 10 end

--- @param p { x, y, z, vx, vy, vz }
RegisterNetEvent('js-atgm:upd', function(id, p)
    local src = source
    local m = missiles[num(id) or -1]
    if not m or m.src ~= src or type(p) ~= 'table' then return end
    local now = GetGameTimer()
    if now - m.lastUpd < 50 then return end                               -- at most 20 a second
    local pos = vec(p)
    local vx, vy, vz = num(p[4], 3000.0), num(p[5], 3000.0), num(p[6], 3000.0)
    if not pos or not vx or not vy or not vz then return end
    local W = C.Weapons[m.w]
    local vmax = math.max(W.speed or 0.0, W.diveSpeed or 0.0, 340.0) * 1.5 + 60.0
    -- no teleporting: at most its top speed times the time since the last report, and since the launch
    local dt = math.max(0.05, (now - m.last) / 1000.0)
    if #(pos - m.pos) > vmax * dt + 50.0 then return end
    if #(pos - m.launch) > vmax * ((now - m.t0) / 1000.0) + 200.0 then return end
    m.pos, m.last, m.lastUpd = pos, now, now
    -- only clean numbers are passed on (never the table the client sent)
    relay(m, id, { round1(pos.x), round1(pos.y), round1(pos.z), math.floor(vx), math.floor(vy), math.floor(vz) })
end)

local function finish(id, pos, stale)
    local m = missiles[id]
    if not m then return end
    missiles[id] = nil
    flying[m.src] = math.max(0, (flying[m.src] or 1) - 1)
    local p = pos and { x = pos.x, y = pos.y, z = pos.z } or nil
    for s in pairs(m.seen) do TriggerClientEvent('js-atgm:remoteEnd', s, id, p) end
    -- the shooter is told, so a missile the server gave up on is not flown on unseen by everyone else
    if stale then TriggerClientEvent('js-atgm:cancel', m.src, id) end
end

RegisterNetEvent('js-atgm:done', function(id, p)
    local src = source
    id = num(id) or -1
    local m = missiles[id]
    if not m or m.src ~= src then return end
    local pos = vec(p)
    if pos and #(pos - m.pos) > 2000.0 then pos = nil end              -- a blast far from its last report is not shown
    finish(id, pos)
end)

-- ---------------------------------------------------------------------
-- lasers (shared, so a helicopter can designate for a jet's bomb: "buddy lasing")
-- ---------------------------------------------------------------------
local function sendLaser(src, l, bucket)
    local data = l and { l.x, l.y, l.z, l.code } or false
    for _, s in ipairs(GetPlayers()) do
        s = tonumber(s)
        if s ~= src and bucketOf(s) == bucket then TriggerClientEvent('js-atgm:laser', s, src, data) end
    end
end

local function laserOff(src)
    local l = lasers[src]
    if not l then return end
    lasers[src] = nil
    sendLaser(src, nil, l.bucket)
end

local laserT = {}
RegisterNetEvent('js-atgm:laser', function(p)
    local src = source
    local now = GetGameTimer()
    if type(p) ~= 'table' then return laserOff(src) end
    if now - (laserT[src] or 0) < 150 then return end
    laserT[src] = now
    local P = platformOf(src)
    if not P then return laserOff(src) end
    local pod = C.Pods[P.pod] or C.Pods.tads
    local spot = vec(p)
    if not spot or #(spot - GetEntityCoords(GetPlayerPed(src))) > pod.maxRange * 1.1 then return end
    local code = num(p[4], 99999) or C.Laser.DefaultCode
    local b = bucketOf(src)
    if lasers[src] and lasers[src].bucket ~= b then laserOff(src) end
    lasers[src] = { x = spot.x, y = spot.y, z = spot.z, code = math.floor(code), t = now, bucket = b }
    sendLaser(src, lasers[src], b)
end)

-- a missile whose shooter stopped reporting (crash, disconnect, long freeze) is removed for everyone
CreateThread(function()
    while true do
        Wait(2000)
        local now = GetGameTimer()
        for id, m in pairs(missiles) do
            local W = C.Weapons[m.w]
            -- no time limit on a flight; only a shooter that stopped reporting ends it
            local limit = (W and (W.maxTime or 0) > 0) and (W.maxTime + 10) * 1000 or nil
            if now - m.last > STALE or (limit and now - m.t0 > limit) then finish(id, nil, true) end
        end
        for src, l in pairs(lasers) do
            if now - l.t > 2000 then laserOff(src) end
        end
    end
end)

-- ---------------------------------------------------------------------
-- armour: a direct hit by an anti-armour weapon finishes a tank (the vehicle's owner does it). Once per missile.
-- ---------------------------------------------------------------------
RegisterNetEvent('js-atgm:armourHit', function(netId, id)
    local src = source
    netId = num(netId)
    if not netId then return end
    local veh = NetworkGetEntityFromNetworkId(netId)
    if veh == 0 or not DoesEntityExist(veh) or not armour(GetEntityModel(veh)) then return end
    local m = missiles[num(id) or -1]
    if not m or m.src ~= src or m.armourDone or not (C.Weapons[m.w] or {}).armour then return end
    if #(GetEntityCoords(veh) - m.pos) > 60.0 then return end
    m.armourDone = true
    local owner = NetworkGetEntityOwner(veh)
    if owner and owner > 0 then TriggerClientEvent('js-atgm:killVehicle', owner, netId) end
end)

-- ---------------------------------------------------------------------
-- rearming
-- ---------------------------------------------------------------------
local function rearmPoint(veh)
    local c = GetEntityCoords(veh)
    for _, p in ipairs(C.Rearm.Points) do
        if #(c - p.coords) <= p.radius then return p end
    end
    return nil
end

local function rearmNow(veh, P)
    local e = { model = GetEntityModel(veh), a = fullLoad(P) }
    ammoT[veh] = e
    mirror(veh, e.a)
end

local function rearmJobs()
    if C.Rearm.Jobs == false then return false end    -- anyone who may use the weapons
    return C.Rearm.Jobs                                -- a list, or nil = Config.Jobs
end

RegisterCommand(C.Rearm.Command, function(src)
    if src == 0 then return end
    local P, veh = platformOf(src)
    if not P then return notify(src, L('n_not_platform'), 'error') end
    if not jobOk(src) or not jobOk(src, rearmJobs()) then return notify(src, L('n_no_job'), 'error') end
    if not rearmPoint(veh) then return notify(src, L('n_no_rearm_point'), 'error') end
    if speedOf(veh) > 1.0 then return notify(src, L('n_stop_first'), 'error') end
    rearming[src] = { veh = veh, t = GetGameTimer() }
    TriggerClientEvent('js-atgm:rearmGo', src, C.Rearm.Seconds)
end, false)

RegisterNetEvent('js-atgm:rearmDone', function()
    local src = source
    local r = rearming[src]
    rearming[src] = nil
    if not r or GetGameTimer() - r.t < (C.Rearm.Seconds - 1) * 1000 then return end
    local P, veh = platformOf(src)
    if not P or veh ~= r.veh or not rearmPoint(veh) or speedOf(veh) > 1.0 then return notify(src, L('n_rearm_fail'), 'error') end
    rearmNow(veh, P)
    notify(src, L('n_rearmed'), 'success')
end)

RegisterNetEvent('js-atgm:rearmCancel', function()
    local src = source
    if rearming[src] then rearming[src] = nil notify(src, L('n_rearm_fail'), 'error') end
end)

RegisterCommand(C.Rearm.AdminCommand, function(src)
    if src == 0 then return end
    local P, veh = platformOf(src)
    if not P then return notify(src, L('n_not_platform'), 'error') end
    rearmNow(veh, P)
    notify(src, L('n_rearmed'), 'success')
end, true)

-- ---------------------------------------------------------------------
-- far contacts: an open pod says where it looks; it gets the players and vehicles around that spot that the
-- game does not send it (too far). Only to a player in a weapons seat, only around a point the pod can reach,
-- only a few times a second, nearest first. Nothing runs while no pod is open.
-- ---------------------------------------------------------------------
local looks = {}           -- src -> { pos, r, ids = { key = true }, t, veh, bucket }
local CT = C.Contacts or {}

-- real players / vehicles from further away for an open pod (OneSync sends everything within this radius)
local culled = {}          -- src -> radius set
local function cull(src, on)
    if not SetPlayerCullingRadius then return end
    local R = math.min(CT.NetworkRange or 0.0, 3000.0)
    if on and R > 0 then
        if culled[src] ~= R then culled[src] = R pcall(SetPlayerCullingRadius, tostring(src), R + 0.0) end
    elseif culled[src] then
        culled[src] = nil
        pcall(SetPlayerCullingRadius, tostring(src), 0.0)
    end
end

RegisterNetEvent('js-atgm:look', function(d)
    local src = source
    if type(d) ~= 'table' then looks[src] = nil cull(src, false) return end
    if CT.Enabled == false then return end
    local now = GetGameTimer()
    local cur = looks[src]
    if cur and now - cur.rx < 200 then return end                 -- the client sends at most ~2 a second
    local P, veh = platformOf(src)
    if not P or not jobOk(src) then looks[src] = nil cull(src, false) return end
    local pos = d.p and vec(d.p) or nil
    local r = num(d.r, 100000) or 300.0
    r = math.max(50.0, math.min(r, CT.Radius or 900.0))
    if pos then
        local pod = C.Pods[P.pod] or C.Pods.tads
        if #(pos - GetEntityCoords(veh)) > (pod.maxRange or 9000.0) + 500.0 then pos = nil end
    end
    local ids, n = {}, 0
    if type(d.ids) == 'table' then
        for _, k in ipairs(d.ids) do
            if n >= 10 then break end
            if type(k) == 'string' and #k <= 12 and k:match('^[pv]%d+$') then ids[k] = true n = n + 1 end
        end
    end
    if not pos and n == 0 then looks[src] = nil cull(src, false) return end
    looks[src] = { pos = pos, r = r, ids = ids, t = now, rx = now, veh = veh, bucket = bucketOf(src) }
    cull(src, pos ~= nil)                                         -- the pod is open and looking
end)

local function vtype(v)
    if not GetVehicleType then return 'veh' end
    local ok, t = pcall(GetVehicleType, v)
    if not ok then return 'veh' end
    if t == 'heli' or t == 'plane' or t == 'blimp' then return 'air' end
    if t == 'boat' or t == 'submarine' then return 'boat' end
    return 'veh'
end
local function r1(x) return math.floor(x * 10 + 0.5) / 10 end
local function pack(key, kind, ent, occ)
    local p = GetEntityCoords(ent)
    local v = GetEntityVelocity and GetEntityVelocity(ent) or vector3(0.0, 0.0, 0.0)
    return { key, kind, r1(p.x), r1(p.y), r1(p.z), r1(v.x), r1(v.y), r1(v.z), occ or 0, GetEntityModel(ent),
             math.floor(GetEntityHeading(ent) + 0.5) }
end

local function contactsTick()
    local now = GetGameTimer()
    -- one pass over players and vehicles for all open pods
    local peds, occ = {}, {}
    for _, s in ipairs(GetPlayers()) do
        local id = tonumber(s)
        local ped = GetPlayerPed(id)
        if ped ~= 0 then
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 then occ[veh] = (occ[veh] or 0) + 1
            else peds[#peds + 1] = { id = id, ped = ped, pos = GetEntityCoords(ped), b = bucketOf(id) } end
        end
    end
    local vehs = {}
    for _, v in ipairs(GetAllVehicles()) do
        local b = 0
        if GetEntityRoutingBucket then b = GetEntityRoutingBucket(v) end
        vehs[#vehs + 1] = { v = v, pos = GetEntityCoords(v), b = b }
    end
    local maxN = CT.Max or 24
    for src, L in pairs(looks) do
        if now - L.t > 3000 or not GetPlayerName(src) then
            looks[src] = nil
            cull(src, false)
        else
            local cand, out = {}, {}
            local r2 = L.r * L.r
            local function near(p)
                if not L.pos then return nil end
                local dx, dy = p.x - L.pos.x, p.y - L.pos.y
                local d2 = dx * dx + dy * dy
                return d2 <= r2 and d2 or nil
            end
            for _, p in ipairs(peds) do
                if p.id ~= src and p.b == L.bucket then
                    local key = 'p' .. p.id
                    local d2 = near(p.pos)
                    if L.ids[key] then out[#out + 1] = pack(key, 'ped', p.ped, 0)
                    elseif d2 then cand[#cand + 1] = { d2, key, 'ped', p.ped, 0 } end
                end
            end
            for _, x in ipairs(vehs) do
                if x.v ~= L.veh and x.b == L.bucket then
                    local key = 'v' .. NetworkGetNetworkIdFromEntity(x.v)
                    local d2 = near(x.pos)
                    if L.ids[key] then out[#out + 1] = pack(key, vtype(x.v), x.v, occ[x.v])
                    elseif d2 then cand[#cand + 1] = { d2, key, nil, x.v, occ[x.v] or 0 } end
                end
            end
            table.sort(cand, function(a, b) return a[1] < b[1] end)
            for i = 1, math.min(#cand, maxN) do
                local c = cand[i]
                out[#out + 1] = pack(c[2], c[3] or vtype(c[4]), c[4], c[5])
            end
            if #out > 0 or L.sentAny then
                L.sentAny = #out > 0
                TriggerClientEvent('js-atgm:contacts', src, out)
            end
        end
    end
end

CreateThread(function()
    while true do
        if next(looks) then
            Wait(math.max(100, CT.Rate or 250))
            local ok, err = pcall(contactsTick)
            if not ok then print('^1[js-atgm] contacts: ' .. tostring(err) .. '^7') end
        else
            Wait(500)
        end
    end
end)

-- ---------------------------------------------------------------------
AddEventHandler('playerDropped', function()
    local src = source
    looks[src] = nil
    culled[src] = nil
    for id, m in pairs(missiles) do if m.src == src then finish(id, nil) end end
    laserOff(src)
    flying[src], rearming[src], laserT[src], bucketCache[src] = nil, nil, nil, nil
end)

exports('Rearm', function(veh)
    local model = GetEntityModel(veh)
    for name, P in pairs(C.Platforms) do if joaat(name) == model then rearmNow(veh, P) return true end end
    return false
end)

--- ammunition left on a vehicle (server count), for other resources
exports('GetAmmo', function(veh)
    local e = ammoT[veh]
    if not e then return nil end
    local copy = {}
    for k, v in pairs(e.a) do copy[k] = v end
    return copy
end)

-- ---------------------------------------------------------------------
-- who made it
-- ---------------------------------------------------------------------
local INFO = JSATGM_INFO()
exports('Info', function() return INFO end)
CreateThread(function()
    Wait(500)
    print(('^2[%s]^7 v%s - made by ^3%s^7 (%s)'):format(INFO.name or 'js-atgm', INFO.version or '?', INFO.author or 'JS-STUDIO', INFO.built or ''))
end)
