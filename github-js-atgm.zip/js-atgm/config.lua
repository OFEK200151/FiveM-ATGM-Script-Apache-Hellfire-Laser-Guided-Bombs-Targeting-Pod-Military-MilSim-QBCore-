--[[ js-atgm | made by Jhonny · JS-STUDIO
     build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
     Air-to-ground guided weapons for helicopters and fighter jets: a targeting pod (TADS / LITENING style),
     laser rangefinder / designator, and laser, GPS and electro-optical guided missiles and bombs.
     Numbers are game values modelled on public figures; tune them freely. ]]

Config = {}
Config._id = '4a532d53545544494f7c6a732d6174676d7c322e362e317c323032362d31302d3330'                -- build id (leave as is)
Config.Locale = 'en'                 -- 'en' | 'he'
Config.Debug = false

-- entering / leaving the pod: the camera glides from your view to the pod (ms)
Config.Transition = { In = 1200, Out = 800 }

-- who may use the weapons systems: QBCore job names (false = everyone)
Config.Jobs = false                  -- e.g. { 'iaf', 'idf', 'army' }
Config.MinJobGrade = 0

-- ---------------------------------------------------------------------
-- keys (FiveM key bindings, every player can rebind them in Settings > Key Bindings > FiveM)
-- ---------------------------------------------------------------------
Config.Keys = {
    pod      = 'B',            -- targeting pod view on / off (G is the landing gear in jets)
    fire     = 'MOUSE_LEFT',   -- release / launch the selected weapon
    laser    = 'MOUSE_RIGHT',  -- hold: fire the laser (range + designate)
    laserOn  = 'L',            -- laser continuous on / off (designating for someone else)
    track    = 'SPACE',        -- track: the vehicle under the cross, else geo-stabilise the point
    reset    = 'R',            -- reset the point: camera back to straight ahead, a new point there
    weapon   = 'Q',            -- next weapon
    zoom     = 'Z',            -- next field of view (the mouse wheel zooms too)
    sensor   = 'U',            -- picture: TV (gray) <-> IR (thermal, for night) (N is push-to-talk on most servers)
    coords   = 'K',            -- enter target coordinates / use the map waypoint
    profile  = 'J',            -- missile flight profile: direct / lofted (top attack)
    seeker   = 'V',            -- Spike / HAROP: switch between the pod and the weapon's own camera
    strike   = 'X',            -- HAROP: leave the circle and dive onto the point
    mark     = 'E',            -- mark the target under the point as T1, T2 ... (again on it = unmark)
    nextTarget = 'TAB',        -- the pod looks at the next marked target
    clearTargets = 'DELETE',   -- clear the marked targets (not the ones a weapon is already flying to)
    help     = 'H',            -- the help page in the pod (every key and how to use it)
}

-- ---------------------------------------------------------------------
-- several targets (like a jet's pre-planned targets): mark T1, T2, T3 ... with the pod, then fire.
-- Every weapon gets its own target and goes there by itself - the pod is free to look at the next one.
-- ---------------------------------------------------------------------
Config.Targets = {
    Max = 8,                     -- marked targets at once
    Ripple = true,               -- fire with marked targets = one weapon on EVERY marked target, one after the
                                 -- other (false = one weapon per press, on the next target)
    Interval = 0.6,              -- s between the weapons of a ripple (the server allows Limits.FireInterval)
    ClearOnHit = true,           -- a target leaves the list when its weapon hits (false = it stays, free again)
    Pick = 20.0,                 -- marking within this many metres of a mark takes that mark off
}

-- ---------------------------------------------------------------------
-- targeting pods
-- ---------------------------------------------------------------------
-- aiming the point / laser
Config.Aim = {
    Arrows = true,               -- the arrow keys move the point (and the camera with it)
    Mouse = false,               -- true = the mouse moves it too
    Speed = 0.15,                -- how fast, as a part of the picture per second, when you start pressing ...
    Fast = 0.8,                  -- ... and after holding the key ~1.5 s (fine at first, quick when held)
}

-- launch rules (false / 'off' = no limit)
Config.Rules = {
    ReleaseEnvelope = 'warn',    -- bombs: 'block' = not released if it cannot reach the point,
                                 -- 'warn' = released anyway with a warning on the HUD, 'off' = no check
    MinRange = true,             -- missiles: not closer than the weapon's minRange
    OffAxis = false,             -- missiles: true = only with the target within offAxis of the nose
}

Config.Pods = {
    -- AH-64 TADS: nose turret, +-120 deg azimuth, +30 up, down to straight below
    tads = {
        label = 'TADS',
        az = 120.0, elUp = 30.0, elDown = -90.0,
        fov = { 50.0, 18.0, 6.0, 2.0 },         -- WFOV / MFOV / NFOV / zoom
        slew = 1.0,                             -- mouse sensitivity
        maxRange = 9000.0,                      -- laser rangefinder (m)
    },
    -- LITENING / Sniper pod under a jet: looks almost everywhere below the aircraft
    pod = {
        label = 'LITENING',
        az = 160.0, elUp = 10.0, elDown = -155.0,
        fov = { 24.0, 8.0, 3.0, 1.2 },
        slew = 1.0,
        maxRange = 15000.0,
    },
}

-- ---------------------------------------------------------------------
-- weapons
--   explosion.fx: size of the extra blast effect at the impact (seen from far away)
--   kind:  'sal'  semi-active laser: homes on a laser spot with its code (own or someone else's)
--          'fou'  fire, observe & update: electro-optical seeker, the operator sees and steers it
--          'gps'  goes to a coordinate (no laser, no picture)
--          'lgb'  laser guided bomb: unpowered, falls and glides to the laser spot
--          'gpsb' GPS guided bomb (JDAM / SDB); datalink = true: follows the point after release
--          'loiter' loitering munition: circles above the point, strikes on command
-- ---------------------------------------------------------------------
Config.Weapons = {
    hellfire = {
        label = 'AGM-114R', short = 'HF', kind = 'sal',
        speed = 425.0, accel = 260.0, burn = 2.6,       -- m/s, m/s2, s of motor
        drag = 0.00008,                                 -- after burn-out
        turn = 30.0,                                    -- max g
        maxRate = 70.0,                                 -- max turn (deg/s)
        rail = 0.4,                                     -- s straight off the rail before it turns
        minRange = 60.0, maxRange = 8000.0,
        arm = 80.0,                                     -- arming distance
        offAxis = 60.0,                                 -- target within this of the nose (only with Rules.OffAxis)
        profiles = { 'direct', 'lofted' }, loftAlt = 300.0,
        loal = true,                                    -- lock-on after launch: may fly before the laser starts
        model = 'w_ex_vehiclemissile_3', trail = true,
        explosion = { type = 5, scale = 1.0, extra = 32, fx = 0.45 }, armour = true,
    },
    spike = {
        label = 'SPIKE NLOS', short = 'SPK', kind = 'fou',
        speed = 180.0, accel = 90.0, burn = 3.0,
        drag = 0.0, sustain = true,                     -- sustainer motor: keeps its speed
        turn = 12.0, maxRate = 30.0, rail = 0.6,
        minRange = 400.0, maxRange = 25000.0,
        arm = 300.0, offAxis = 180.0,
        profiles = { 'direct', 'lofted' },
        cruiseAlt = 250.0,                              -- flies over obstacles, dives at the end
        model = 'w_ex_vehiclemissile_4', trail = true,
        explosion = { type = 5, scale = 1.2, extra = 32, fx = 0.55 }, armour = true,
    },
    -- the fighter's air-to-ground missile: TV / IR seeker, goes to the point and follows it when you move it,
    -- or steer it yourself through its own camera (V)
    maverick = {
        label = 'AGM-65 MAVERICK', short = 'AGM', kind = 'fou',
        speed = 320.0, accel = 180.0, burn = 3.5, drag = 0.00006,
        turn = 15.0, maxRate = 45.0, rail = 0.6,          -- dropped off the rail, motor, then it turns
        minRange = 300.0, maxRange = 22000.0, arm = 150.0,
        offAxis = 45.0,
        profiles = { 'direct', 'lofted' }, loftAlt = 400.0,
        seeker = { az = 60.0, up = 20.0, down = -60.0 },
        model = 'w_ex_vehiclemissile_2', trail = true,
        explosion = { type = 5, scale = 1.3, extra = 32, fx = 0.6 }, armour = true,
    },
    -- loitering munition (HAROP-style): flies to the point and circles above it for hours, follows the point
    -- when you move it, sees with its own camera (V), and dives almost vertically onto it when told (X)
    harop = {
        label = 'HAROP', short = 'LM', kind = 'loiter',
        speed = 52.0,                                   -- cruise (m/s, ~185 km/h)
        diveSpeed = 110.0, accel = 15.0,                -- the strike dive
        turn = 1.6, diveTurn = 7.0, climb = 6.0,        -- g in the orbit / in the dive, m/s up / down
        loiterAlt = 450.0, loiterRadius = 350.0,        -- the circle above the point (m)
        endurance = 6 * 3600,                           -- s in the air (0 = no limit); then it strikes the point
        minRange = 0.0, maxRange = 200000.0, arm = 150.0, offAxis = 180.0,
        seeker = { az = 160.0, up = 15.0, down = -110.0 },    -- its camera looks down and around
        model = 'w_ex_vehiclemissile_4', trail = false,
        explosion = { type = 5, scale = 1.2, extra = 32, fx = 0.6 }, armour = true,
    },
    gbu12 = {
        label = 'GBU-12', short = 'G12', kind = 'lgb',
        speed = 0.0, turn = 3.0, glide = 0.30, dragK = 0.00006,   -- glide: lift / weight, dragK: drag
        maxRange = 14000.0, arm = 200.0, offAxis = 180.0,
        model = 'w_smug_bomb_01', trail = false,
        explosion = { type = 50, scale = 1.4, extra = 59, fx = 0.9 }, armour = true,
    },
    gbu39 = {
        label = 'GBU-39 SDB', short = 'G39', kind = 'gpsb',
        speed = 0.0, turn = 4.0, glide = 1.0, dragK = 0.00003,    -- pop-out wings: long glide
        datalink = true,                                -- follows the point if you move it after release (SDB II style)
        maxRange = 30000.0, arm = 200.0, offAxis = 180.0,
        model = 'w_smug_bomb_02', trail = false,
        explosion = { type = 50, scale = 1.0, extra = 32, fx = 0.7 }, armour = true,
    },
    -- JDAM with a laser seeker in the nose (Laser JDAM): GPS kit + fins steer it to the point; if you move the
    -- point after release it follows it (moving targets too). Released only when it can reach (see Pod: reach)
    jdam = {
        label = 'GBU-54 L-JDAM', short = 'JDM', kind = 'gpsb',
        speed = 0.0, turn = 3.0, glide = 0.45, dragK = 0.00005,
        datalink = true,
        maxRange = 24000.0, arm = 250.0, offAxis = 180.0,
        model = 'w_smug_bomb_03', trail = false,
        explosion = { type = 59, scale = 1.0, extra = 50, fx = 1.3 }, armour = true,
    },
    -- bunker buster (GBU-28 / BLU-113 class, 2,100 kg): GPS + laser kit, follows the point. It does not burst
    -- on the surface: it goes through the roof / concrete / ground (penetrate, m) and goes off inside, then the
    -- blast breaks out at the entry hole. One very heavy charge - not a cluster bomb.
    gbu28 = {
        label = 'GBU-28 BUNKER BUSTER', short = 'G28', kind = 'gpsb',
        speed = 0.0, turn = 2.5, glide = 0.35, dragK = 0.000025, rail = 1.0,
        datalink = true,
        maxRange = 18000.0, arm = 300.0, offAxis = 180.0,
        penetrate = 18.0,                               -- m it goes in before the delayed fuze sets it off
        model = 'w_smug_bomb_01', trail = false,
        explosion = { type = 59, scale = 3.0, extra = 60, fx = 2.2, ring = 6, ringType = 50, ringRadius = 12.0 },
        armour = true,
    },
}
Config.FallbackModel = 'w_lr_rpg_rocket'       -- used when a weapon model is not in the game build
-- weapons fly until they hit (no flight time limit). maxTime = n on a weapon would add a self destruct.

-- the other HUDs while the pod is open (B): only the pod's own HUD is on the screen
Config.HideHud = {
    Game = true,                 -- the game HUD and the minimap
    -- other HUD resources: told to hide while the pod is open and to show again when it closes, through
    -- their own export or client event:  ['name'] = { export = 'SetHidden' }  or  { event = 'name:hide' }
    -- (called with true = hide, false = show). A resource that is not running is skipped.
    Resources = {
    },
}
-- Other scripts can also listen: AddEventHandler('js-atgm:pod', function(open) ... end)
-- or read LocalPlayer.state.atgmPod (true while the pod is open).

-- the picture through the pod
Config.Picture = {
    FarClip = 16000.0,           -- how far the pod camera draws (m; at least the pod's own range)
    LodBoost = 1.0,              -- more detail far away, grows with the zoom (x1 at the widest view) ...
    LodMax = 12.0,               -- ... up to this (like a sniper scope: zoomed in = full detail far away; the
                                 -- zoomed picture is narrow, so it costs little)
    -- far targets: the picture is taken from a point on the line of sight this close to the target (m), with a
    -- wider lens showing exactly the same ground - so the game loads and draws the target area in full detail
    -- (buildings, props, people) from any height / distance. 0 = off (the picture from the aircraft itself)
    -- 0 (default) = the picture is always taken from the pod on the aircraft: a real pod, no flying camera.
    -- 300 = from a point on the line of sight 300 m from the target (full detail, but feels like a free camera)
    CloseUp = 0.0,
    CloseFov = 70.0,             -- widest lens it may use for that (more = closer, but more perspective)
    Glide = 3.0,                 -- how fast the picture glides to its new place when you zoom / move (higher = snappier)
    -- the world (map detail, collision, ambient people / cars) loads around the point instead of around you:
    -- 'auto' = while flying (or with the close-up picture), true = always, false = never.
    -- The ground under your own aircraft is always kept solid.
    MoveFocus = 'auto',
    -- with the close-up picture the network also sends you the players around the camera (OneSync), so you
    -- see the real players / vehicles there. false = off (the far contacts below still show them)
    NetworkFocus = true,
    HdRadius = 120.0,            -- sharp (high detail) textures around the point (m); 0 = off (lighter)
    EntityLod = 3000.0,          -- people / vehicles / stand-ins in the picture are drawn up to this far (m)
                                 -- (the game normally stops drawing a person at ~150-300 m)
    DayFilter = false,           -- only with Day = 'color': slight TV filter on the color picture
    -- the day picture (DTV), like a real pod camera: 'gray' = black & white TV picture (default), 'color' = normal
    Day = 'gray',
    GrayFilter = 'CAMERA_BW',    -- the game's black & white camera filter used for the gray picture
    GrayStrength = 1.0,          -- 0..1 (1 = fully gray)
    -- the pictures U goes through, in order. The first one is what the pod opens with.
    -- 'DTV' = day TV (gray), 'IR' = thermal (night). Add 'NVS' for the green night vision too: { 'DTV', 'IR', 'NVS' }
    Sensors = { 'DTV', 'IR' },
    ImpactFx = true,             -- a large blast effect at the impact (seen from far away)
}

-- far contacts: players and vehicles around the point that the game does not have (they are further than the
-- network sends to you) come from the server, only to an open pod, only around where it looks: shown as heat
-- spots, can be locked (SPACE), marked (E) and hit. Light: a few small messages a second to that one pod.
Config.Contacts = {
    Enabled = true,
    Radius = 900.0,              -- the most around the point (m); the real radius follows the picture
    Rate = 250,                  -- ms between updates
    Max = 24,                    -- contacts per update (nearest first)
    -- stand-ins: a far player / vehicle is shown as a real model at its place (only on your screen, no
    -- collision): you see a person / a car through the pod, white-hot in IR. false = heat spots only
    Proxy = true,
    -- REAL players / vehicles from further away: while the pod is open the server sends this player everything
    -- within this distance of his aircraft (m) - real models, real clothes. Costs that one player network and
    -- FPS (a city full of cars); the stand-ins cover everything beyond. 0 = off (only stand-ins)
    NetworkRange = 1500.0,
    PedModel = 's_m_y_blackops_01',  -- the stand-in for players (their clothes are not known that far away)
}

-- ---------------------------------------------------------------------
-- platforms: vehicle model -> who uses the pod, which pod, where it sits, loadout
--   seats: -1 = pilot, 0 = front passenger (co-pilot / gunner) ...
--   mount: pod position in vehicle space (x right, y forward, z up); nil = under the nose (auto)
-- Add-on aircraft: copy a block and put the spawn name (e.g. 'ah64d', 'f16i').
-- ---------------------------------------------------------------------
Config.Platforms = {
    -- helicopters
    hunter   = { label = 'FH-1 Hunter',   pod = 'tads', seats = { 0, -1 }, loadout = { hellfire = 8, spike = 2, harop = 2 } },
    akula    = { label = 'Akula',         pod = 'tads', seats = { 0, -1 }, loadout = { hellfire = 4 } },
    savage   = { label = 'Savage',        pod = 'tads', seats = { 0, -1 }, loadout = { hellfire = 8, harop = 2 } },
    valkyrie = { label = 'Valkyrie',      pod = 'tads', seats = { 0 },     loadout = { hellfire = 4 } },
    -- fighter jets (the pilot works the pod)
    lazer       = { label = 'P-996 Lazer',  pod = 'pod', seats = { -1 }, loadout = { maverick = 4, jdam = 4, gbu12 = 2, gbu39 = 4, gbu28 = 1 } },
    hydra       = { label = 'Hydra',        pod = 'pod', seats = { -1 }, loadout = { maverick = 2, jdam = 2, gbu39 = 4 } },
    strikeforce = { label = 'B-11 Strikeforce', pod = 'pod', seats = { -1 }, loadout = { maverick = 4, gbu12 = 4, jdam = 2, gbu28 = 2 } },
    raiju       = { label = 'F-160 Raiju',  pod = 'pod', seats = { -1 }, loadout = { maverick = 2, gbu39 = 8 } },
    -- add-on examples (uncomment with your own spawn names)
    -- ah64d = { label = 'AH-64D Saraf', pod = 'tads', seats = { 0, -1 }, loadout = { hellfire = 16 }, mount = vector3(0.0, 6.2, -0.9) },
    -- f16i  = { label = 'F-16I Sufa',   pod = 'pod',  seats = { -1 },    loadout = { maverick = 2, gbu12 = 2, gbu39 = 4, jdam = 2 } },
    F15D  = { label = 'F-15I Raam',   pod = 'pod',  seats = { -1, 0 }, loadout = { gbu39 = 8, jdam = 4, gbu28 = 2 } },
    -- f35i  = { label = 'F-35I Adir',   pod = 'pod',  seats = { -1 },    loadout = { gbu39 = 8, jdam = 2 } },
}

-- ---------------------------------------------------------------------
-- laser
-- ---------------------------------------------------------------------
Config.Laser = {
    Auto = true,                 -- the laser is always on the point in the middle of the picture: aim the
                                 -- point, fire, and move the point to steer the weapon. false = hold the laser key
    DefaultCode = 1688,          -- PRF code; weapons home only on a laser with their code
    Codes = { 1111, 1688, 1511, 1712 },
    Publish = 0.25,              -- s between laser spot updates shared with others
    Battery = 0,                 -- 0 = no limit, otherwise seconds of continuous lasing
    Memory = 0,                  -- 0 = a laser weapon never gives up: with no spot it keeps going to the last
                                 -- spot it saw (or the point it was fired at). n = after n s without a spot it
                                 -- flies on unguided (ballistic), like a real seeker - harder
    LoalAcquire = 1500.0,        -- only with Memory > 0: a LOAL Hellfire must see the laser by this distance (m)
}

-- armoured vehicles: a direct hit by a weapon with armour = true destroys them for sure
Config.Armour = { 'rhino', 'khanjali', 'apc', 'halftrack', 'barrage', 'insurgent', 'insurgent3', 'chernobog' }

-- ---------------------------------------------------------------------
-- rearming (on the ground, engine off, near a rearm point)
-- ---------------------------------------------------------------------
Config.Rearm = {
    Seconds = 20,
    Jobs = false,                -- false = whoever may use the weapons
    Points = {
        { label = 'Fort Zancudo', coords = vector3(-2142.0, 3015.0, 32.8), radius = 220.0 },
        { label = 'LSIA',         coords = vector3(-1255.0, -3350.0, 13.9), radius = 260.0 },
        { label = 'Sandy Shores', coords = vector3(1725.0, 3290.0, 41.1), radius = 140.0 },
    },
    Command = 'rearm',           -- players: rearm at a point
    AdminCommand = 'atgmrearm',  -- admins (ace command.atgmrearm): rearm on the spot
}

-- server limits (anti-abuse)
Config.Limits = {
    FireInterval = 0.5,          -- s between launches per aircraft
    InFlight = 8,                -- missiles / bombs in the air per player
    SyncRange = 4000.0,          -- other players this close to a missile see it
    StaleTime = 15.0,            -- s without a report from the shooter before the server drops a missile
}
