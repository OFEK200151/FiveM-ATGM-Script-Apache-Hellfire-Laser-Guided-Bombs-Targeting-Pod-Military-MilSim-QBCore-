# js-atgm — air-to-ground guided weapons | JS-STUDIO
🇮🇱 [עברית](README.he.md)

Guided weapons for helicopters and fighter jets on QBCore. It has a targeting pod in the style of the TADS (Apache) and the LITENING (jets), a laser designator with codes, and guided missiles and bombs that fly in a physics simulation. Every player nearby sees them.

---

## Installation

1. Copy `js-atgm` to resources and add `ensure js-atgm` after `qb-core`.
2. In `config.lua`, set which aircraft are armed, which seats operate the pod and what they carry (`Config.Platforms`).
3. Optional: limit it to jobs (`Config.Jobs`), for example `{ 'iaf' }`.

It also works without QBCore: notifications fall back to GTA notifications and there is no job check.

---

## How to use it

1. **Enter:** sit in the weapons seat of an armed helicopter or jet and press **B**. The camera glides from your view to the pod camera and the system comes up on the screen.
2. **The point:** in the middle of the screen there is a blue point. It is a fixed point on the ground and it does not move by itself. When the aircraft moves, the camera stays on it.
3. **Aim:** with the **arrow keys** the point moves over the ground. A short press moves it a little, for precision. Holding the key moves it faster. The mouse does not move the point (it can be turned on in `Config.Aim.Mouse`). The laser is always on the point: `LASE 1688` at the top left.
4. **Reset:** **R** drops the point, the camera goes back to straight ahead and a new point is made there. Inside the pod R never switches the game's own camera.
5. **Vehicle:** if the point is on a vehicle, **Space** locks it on the vehicle (a ring around the point) and it rides along. **Space** again releases it and it stays where it is.
6. **Fire:** left click. A white circle with the time to impact appears on the HUD - that is the missile.
7. **Redirect:** at any moment of the flight move the point, and the missile turns to it and hits the new point.
8. **Leave:** **B** again, and the camera glides back to you.

### The picture
- **TV (gray):** the default. A black & white picture, like the TV camera of a real pod.
- **IR (thermal):** for the night. Warm things (people, engines) are white.
- **U** switches between them. The green night vision can be added in `Config.Picture.Sensors`.

### Several targets at once (like a fighter jet)
1. **Mark:** move the point to a target and press **E**. The target is marked **T1** and brackets appear around it. Move to the next target and press **E** again, up to 8 targets (T2, T3 ...). A vehicle target is followed even when it moves.
2. **Unmark:** **E** on a marked target removes the mark. **Delete** clears all targets.
3. **Check:** **Tab** moves the pod from target to target.
4. **Release:** one left click releases a weapon on **every** target, one after the other. Each weapon gets its own target.
5. **While they fly:** the pod is free and can look anywhere. Every weapon keeps going to its own target. Next to every target and at the side of the screen the weapon and the time to impact are shown (`T2 GBU39 0:44`). A target that was hit leaves the list.
6. **No marked targets:** everything works as before, on the point in the middle.

### Far targets and high altitude
- **A real pod camera:** the picture always comes from the pod on the aircraft. There is no flying camera.
- **Buildings, objects and added models:** while flying, the world loads around the point the pod looks at instead of around you. With zoom the far detail grows up to x12, like a sniper scope, and sharp textures load around the point (120 m). The ground under your own aircraft is kept, and after a crash or leaving, the world comes back to you at once.
- **People and vehicles in the picture:** the game draws them up to 3 km instead of ~150-300 m (`EntityLod`).
- **Real players far away:** while the pod is open the server sends you all players and vehicles up to 1.5 km from the aircraft, with their real clothes and models (`NetworkRange`). When the pod closes this goes back to normal.
- **Players even further away:** they appear as a figure or a vehicle in their place (only for you, no collision), and in thermal they are white like anything warm. They can be locked (Space), marked (E) and hit, and the weapon follows the real player. When the real player loads, the system switches to him by itself.
- **Lock on people too:** Space locks on a person, not only on a vehicle.
- **Settings:**
  - `Config.Picture`: `LodMax`, `HdRadius`, `EntityLod`, `MoveFocus`, `FarClip`.
  - `Config.Contacts`: `NetworkRange`, `Proxy`, `PedModel`.
  - If the pilot loses FPS over a full city, lower `NetworkRange` or `LodMax`.
- **Close-up camera (option):** `CloseUp = 300` takes the picture from close along the same line of sight. Full detail, but it feels like a free camera. Off by default.

## Keys

Every key can be changed in Settings → Key Bindings → FiveM.

| Key | Action |
|---|---|
| **B** | Enter / leave the system |
| **Arrows** | Move the point and the laser. Tap = small step, hold = faster. The speed goes down with the zoom |
| Wheel / **Z** | Zoom / next field of view |
| **R** | Reset the point: the camera goes back to straight ahead (inside the pod R does not switch the game camera) |
| **Space** | Lock on a vehicle / person / far target (heat spot) / release |
| **E** | Mark a target (T1, T2 ...) / unmark |
| **Tab** | The pod looks at the next marked target |
| **Delete** | Clear the marked targets |
| **H** | Help page inside the pod: every key and how to use it |
| Left click | Launch / release the selected weapon |
| **Q** | Next weapon |
| **J** | Flight profile: direct (DIR) / from above (LOFT) |
| **U** | Picture: TV gray (default, like a real pod camera) / thermal for the night |
| **K** | Target data: X/Y coordinates, the map waypoint, laser code, stored points |
| **V** | Spike / HAROP: look through the weapon's own camera; moving the cross steers it |
| **X** | HAROP: leave the circle and dive onto the point |
| **L** / right click | Laser designation for another player, for example a helicopter lasing for a jet's bomb |

## The weapons

| Weapon | Guidance | How it works |
|---|---|---|
| **AGM-114R Hellfire** | Laser | Flies to the point, and if you move the point it turns after it. In LOFT it climbs and falls onto the target from above. About 14 s to 5 km. |
| **AGM-65 Maverick** | Camera in the nose (day / thermal) | The fighter jets' missile. It has a motor, flies to the point and turns after it when you move it. With **V** you see through its seeker and steer it yourself. Range 22 km. |
| **Spike NLOS** | Fire, observe & update | Flies to the point and is updated when you move it. With **V** you see through the missile and move its cross. Flies at 250 m and dives at the end. Range up to 25 km. |
| **HAROP** | Loitering munition | Flies to the point and circles above it in a 350 m circle at 450 m, up to 6 hours. Move the point and the circle moves with it. With **V** you see through its camera. With **X** it flies over the point and falls on it almost vertically. When its time runs out it strikes the point by itself. |
| **GBU-12** | Laser guided bomb | Released from altitude, it glides to the laser spot and follows it when you move it. If the laser is gone it keeps going to the last spot it saw. |
| **GBU-39 SDB** | GPS + datalink | A winged bomb that glides up to 30 km. Released on the pod's point, it follows the point when you move it. Released on entered coordinates (**K**), it stays on them. |
| **GBU-28 bunker buster** | GPS + laser, penetrating | A heavy bomb (2,100 kg) with one charge, not a cluster bomb. It does not burst on the surface: it goes 18 m through a roof, concrete or ground and bursts inside, and the blast comes out of the hole it went in through with a wide shock wave. Follows the point. On the Lazer (1) and the Strikeforce (2). |
| **GBU-54 L-JDAM** | GPS + laser in the nose | A GPS kit and fins on a bomb. Released, it glides nose first to the point, and if you move the point after release it goes there. Accurate to a metre. |

**Release envelope:** before a bomb is released the system works out its whole fall from the current altitude, speed and position. Default (`Config.Rules.ReleaseEnvelope = 'warn'`): a bomb can be released from any altitude. If it would not reach by itself, `RDY  MAY FALL SHORT` is shown in yellow, and the guidance kit holds it in the air and keeps its speed, so it still reaches the point. With `'block'` a bomb that cannot reach is not released, and with `'off'` there is no check at all.

**Bombs and loitering munitions:** a real guided bomb has no motor. It falls and glides to the target on its fins, and from low altitude it does not get far. What circles in the sky for hours and strikes on command is a loitering munition - that is the HAROP.

**Shared laser:** a laser lased on purpose is sent to the players in the same routing bucket, with its code. A missile or bomb locks on any laser with its code. A helicopter can lase a target for a jet's bomb. The HUD shows `LST` when there is a laser on your code.

**No laser:** laser weapons do not give up. If the laser is gone they keep going to the last spot they saw, or to the point they were launched at. For the harder, real behaviour set `Config.Laser.Memory = 2`: after 2 s without a laser spot the weapon flies unguided. The L-JDAM, the GBU-39 and the GBU-28 keep going on GPS in any case.

**Pod limits:** when the point leaves the angles the pod can look at, the laser is hidden and does not fire there. While you have a weapon in the air the point is not dropped. The jet's LITENING also sees backwards and down, so you can pass over the target and keep lasing.

**Far vehicle:** the game loads vehicles only up to a few hundred metres from you. Locking (**Space**) works on a vehicle the game has loaded. If a locked vehicle leaves that range, the point stays where it was (`VEHICLE OUT OF SIGHT - POINT TRACK`) and you can keep moving it by hand.

**How missiles fly:** a missile leaves the rail straight in the aircraft's direction (about 0.4 s; Maverick and Spike 0.6), and only then starts to turn, gradually and with a limited turn rate (`maxRate`). The normal profile (DIR) is low and flat. The LOFT profile (key **J**) climbs and attacks from above. The default for every missile is DIR.

**Launch conditions:**
- **Range:** a minimum (Hellfire 60 m, Maverick 300 m, Spike 400 m) and a maximum, at launch only. After launch the point can be moved anywhere. `Config.Rules.MinRange = false` removes the minimum.
- **Angle off the nose:** none. The missile turns to the point by itself. `Config.Rules.OffAxis = true` brings the limit back.
- **Altitude:** no limit. A bomb can be released from any altitude, but from low altitude it does not get far.
- **Arming distance:** a missile that hits before this distance does not explode.
- **Flight time:** no limit. A missile flies until it hits.

**Damage:** an explosion credited to the shooter. Armoured vehicles (`Config.Armour`: tanks, APCs) are destroyed by a direct hit.

---

## Platforms

Set up already:
- **Helicopters:** Hunter, Akula, Savage, Valkyrie. Helicopters have the TADS: ±120°, from +30 to straight down.
- **Jets:** Lazer, Hydra, Strikeforce, Raiju. Jets have the LITENING: ±160°, under the aircraft.

**Add-on helicopter or jet:** copy a line in `Config.Platforms` and put in the spawn name. Ready examples are in a comment: AH-64D Saraf, F-16I Sufa, F-15I Ra'am, F-35I Adir.

```lua
ah64d = { label = 'AH-64D Saraf', pod = 'tads', seats = { 0, -1 }, loadout = { hellfire = 16 }, mount = vector3(0.0, 6.2, -0.9) },
```

- `seats`: who operates it. `-1` = pilot, `0` = front seat or gunner.
- `mount`: where the pod is on the model. Without it, it is worked out under the nose.
- `loadout`: how many of each weapon.

---

## The picture in the pod

Settings in `Config.Picture`:
- **`Day`:** the day picture. `'gray'` (default) = black & white like the TV camera of a real pod, `'color'` = color.
- **`Sensors`:** the pictures **U** goes through: `{ 'DTV', 'IR' }` = gray day and thermal. Add `'NVS'` for green night vision.
- **`FarClip`:** how far the camera draws.
- **`LodBoost` / `LodMax`:** far detail that grows with the zoom. Higher is sharper but heavier on the PC.
- **`MoveFocus`:** where the world loads while the pod is open (`'auto'` = around the point while flying). The ground under your own aircraft is always kept.
- **`HdRadius`:** high quality textures around the point. 0 = off, lighter.
- **`DayFilter`:** a "TV" filter on the color picture (only with `Day = 'color'`).
- **`ImpactFx`:** a large blast effect at the impact, seen from far away. The size per weapon is in `explosion.fx`.

## Rearming

- **Players:** `/rearm` near a rearm point (`Config.Rearm.Points`, like Fort Zancudo or LSIA), with the aircraft standing still. Takes 20 seconds with the QBCore progress bar (or a message without QBCore). Moving or leaving the aircraft stops it.
- **Admins:** `/atgmrearm` rearms at once. Needs the ace `command.atgmrearm`.
- **From another script:** `exports['js-atgm']:Rearm(vehicle)`, and what is left: `exports['js-atgm']:GetAmmo(vehicle)` (server side).

---

## Performance and security

**Performance:**
- **Outside an armed aircraft:** one check every 750 ms. With no pod open and no missiles in the air no loop runs.
- **Missile simulation:** runs only for the shooter. Other players get about 8 updates a second, and only within 4 km.
- **Slow frame:** the missile is worked out in steps of at most 50 ms, so it does not slow down even when the game hitches. The model loads in the background and the missile flies from the first frame.
- **The automatic laser:** local only, your own missiles read it directly with no network traffic. A laser is sent to other players only when you lase on purpose for someone else: holding right click or **L**.
- **The release envelope:** worked out twice a second, only when a bomb is selected.

**Server security:**
- **Ammo:** counted only on the server. The state bag `atgm` on the aircraft is only a copy for the HUD. A player who writes to it gets no ammo.
- **Permission to launch:** the player must be in the right seat and have the right job. If `Config.Jobs` is set and qb-core is not running, nobody can launch.
- **Limits:** launch rate (half a second between launches), up to 6 missiles in the air per player, and range. Every launch request has a number, so a late answer never fires the wrong weapon.
- **Flight updates:** only valid numbers (no NaN or infinity), up to 20 a second. Both the jump from the last update and the total distance from the launch point are checked. Other players get numbers the server built, not what the client sent.
- **Armour:** one tank kill per missile.
- **Routing buckets:** missiles and lasers are sent only to players in the same bucket.
- **Missile in the air:** removed only if the shooter has not reported for 15 seconds (`Config.Limits.StaleTime`), for example because he disconnected or the game froze. The shooter gets a message (`MISSILE LOST`).
- **The target data window (K):** closes only when Lua confirms. Bad input keeps it open with a message. Closing the pod always frees the mouse.

---

## What to check on the server

Tested offline:
- **Flight physics:** 32 tests, including the straight rail exit, turn rate, impact angle and release outside the envelope.
- **Server:** 43 tests.
- **Client end to end:** 147 tests, in a simulated world.
- **HUD in a browser:** 38 tests. The symbols on the screen were checked at 16:9, 21:9, 4:3, 5:4 and 4K.

Not tested in the real game:
- **Models:** the missile and bomb models (`w_ex_vehiclemissile_*`, `w_smug_bomb_*`). If a model is missing an RPG rocket is used.
- **Model direction:** the system finds the model's long axis by itself and points it along the path. If the nose is backwards, set `flip = true` on the weapon. For more: `axis = 'x' / 'y' / 'z'` or `rot = vector3(...)` in degrees.
- **Effects:** the trail (`scr_ar_trail_smoke`), the gray picture (`CAMERA_BW`) and the color day filter (`heliGunCam`).
- **The rearm bar:** QBCore's (`QBCore.Functions.Progressbar`).
- **Pod position:** on add-on models.

---
**js-atgm 2.6.1** · made by **JS-STUDIO** · 30.10.2026 · all rights reserved. Do not resell or redistribute.
