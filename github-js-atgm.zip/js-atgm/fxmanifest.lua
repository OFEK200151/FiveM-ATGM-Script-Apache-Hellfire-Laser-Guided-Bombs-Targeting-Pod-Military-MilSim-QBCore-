--[[ js-atgm | made by Jhonny · JS-STUDIO ]]
-- build 2.6.1 · 2026-10-30 · (c) JS-STUDIO - all rights reserved. Do not resell or redistribute.
fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'js-atgm'
author 'Jhonny · JS-STUDIO'
description 'Air-to-ground guided weapons: targeting pod, laser designation, Hellfire / Maverick / Spike NLOS / HAROP / GBU-12 / GBU-39 / L-JDAM / GBU-28 (QBCore)'
version '2.6.1'

shared_scripts {
    'config.lua',
    'shared/locale.lua',
    'locales/*.lua',
    'shared/guidance.lua',
}

client_scripts {
    'client/util.lua',
    'client/contacts.lua',
    'client/pod.lua',
    'client/missile.lua',
    'client/hud.lua',
}

server_scripts {
    'server/main.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/*.css',
    'html/js/*.js',
}

escrow_ignore {
    'config.lua',
    'locales/*.lua',
}
